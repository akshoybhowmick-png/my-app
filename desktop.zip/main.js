// Road Survey Desktop — window, file dialogs and PDF printing.
// Developed by Akshoy Bhowmick
const { app, BrowserWindow, ipcMain, dialog, shell, session, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { pathToFileURL } = require('url');

let win;
let allowClose = false;

function createWindow() {
  win = new BrowserWindow({
    width: 1400,
    height: 880,
    minWidth: 900,
    minHeight: 600,
    title: 'Road Survey Desktop',
    backgroundColor: '#f4f6f8',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
    },
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, 'src', 'index.html'));

  // links open in the normal browser, never inside the app
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file:')) {
      e.preventDefault();
      if (/^https?:\/\//.test(url)) shell.openExternal(url);
    }
  });

  // ask before closing with unsaved changes (the page answers through 'app:close-ok')
  win.on('close', (e) => {
    if (allowClose) return;
    e.preventDefault();
    win.webContents.send('app:close-request');
  });
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F12' && input.control && input.shift) win.webContents.openDevTools({ mode: 'detach' });
  });
}

app.whenReady().then(() => {
  // OpenStreetMap asks every program to identify itself
  session.defaultSession.webRequest.onBeforeSendHeaders(
    { urls: ['https://*.tile.openstreetmap.org/*', 'https://tile.openstreetmap.org/*'] },
    (details, cb) => {
      details.requestHeaders['User-Agent'] = 'RoadSurveyDesktop/' + app.getVersion() + ' (Windows; by Akshoy Bhowmick)';
      details.requestHeaders['Referer'] = 'https://github.com/akshoybhowmick-png/my-app';
      cb({ requestHeaders: details.requestHeaders });
    }
  );
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => app.quit());

ipcMain.on('app:close-ok', () => {
  allowClose = true;
  if (win) win.close();
});

ipcMain.handle('file:open', async (e, opts) => {
  const r = await dialog.showOpenDialog(win, {
    title: opts && opts.title,
    filters: (opts && opts.filters) || [],
    properties: ['openFile'],
  });
  if (r.canceled || !r.filePaths.length) return null;
  const p = r.filePaths[0];
  const st = fs.statSync(p);
  if (st.size > 300 * 1024 * 1024) throw new Error('File too large');
  return { path: p, name: path.basename(p), data: new Uint8Array(fs.readFileSync(p)) };
});

ipcMain.handle('file:read', async (e, p) => {
  if (typeof p !== 'string' || !fs.existsSync(p)) return null;
  return { path: p, name: path.basename(p), data: new Uint8Array(fs.readFileSync(p)) };
});

ipcMain.handle('file:save', async (e, opts) => {
  let target = opts.path;
  if (!target || opts.ask !== false) {
    const r = await dialog.showSaveDialog(win, {
      title: opts.title,
      defaultPath: opts.path || path.join(app.getPath('documents'), opts.name || 'file'),
      filters: opts.filters || [],
    });
    if (r.canceled || !r.filePath) return null;
    target = r.filePath;
  }
  const data = typeof opts.data === 'string' ? Buffer.from(opts.data, 'utf8') : Buffer.from(opts.data);
  fs.writeFileSync(target, data);
  return { path: target, name: path.basename(target) };
});

ipcMain.handle('file:show', async (e, p) => {
  if (typeof p === 'string' && fs.existsSync(p)) shell.showItemInFolder(p);
});

ipcMain.handle('pdf:save', async (e, opts) => {
  const r = await dialog.showSaveDialog(win, {
    title: opts.title,
    defaultPath: path.join(app.getPath('documents'), opts.name || 'report.pdf'),
    filters: [{ name: 'PDF', extensions: ['pdf'] }],
  });
  if (r.canceled || !r.filePath) return null;
  const tmp = path.join(os.tmpdir(), 'roadsurvey_report_' + Date.now() + '.html');
  fs.writeFileSync(tmp, opts.html, 'utf8');
  const pw = new BrowserWindow({ show: false, webPreferences: { sandbox: true, contextIsolation: true, javascript: false } });
  try {
    await pw.loadFile(tmp);
    const pdf = await pw.webContents.printToPDF({
      pageSize: 'A4',
      landscape: !!opts.landscape,
      printBackground: true,
      margins: { marginType: 'custom', top: 0.4, bottom: 0.5, left: 0.4, right: 0.4 },
      displayHeaderFooter: true,
      headerTemplate: '<span></span>',
      footerTemplate: '<div style="font-size:8px;width:100%;text-align:center;color:#666;font-family:Segoe UI,Nirmala UI,sans-serif">'
        + 'Road Survey Desktop • Developed by Akshoy Bhowmick • <span class="pageNumber"></span>/<span class="totalPages"></span></div>',
    });
    fs.writeFileSync(r.filePath, pdf);
  } finally {
    pw.destroy();
    try { fs.unlinkSync(tmp); } catch (err) { /* ignore */ }
  }
  return { path: r.filePath, name: path.basename(r.filePath) };
});

ipcMain.handle('app:info', () => ({ version: app.getVersion(), platform: process.platform }));
ipcMain.handle('app:open-url', (e, url) => {
  if (/^https:\/\//.test(url)) shell.openExternal(url);
});

// ---------- videos copied from the phone ----------
const VIDEO_RE = /\.(mp4|3gp|mkv|mov|webm|jpe?g|png|webp|m4a)$/i; // videos, and photos / voice notes copied from the phone
function videoEntry(p) {
  return { name: path.basename(p), path: p, url: pathToFileURL(p).href };
}
function listVideos(dir, depth) {
  let out = [];
  let items = [];
  try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return out; }
  for (const it of items) {
    const p = path.join(dir, it.name);
    if (it.isDirectory()) { if (depth < 2) out = out.concat(listVideos(p, depth + 1)); }
    else if (VIDEO_RE.test(it.name)) out.push(videoEntry(p));
    if (out.length > 5000) break;
  }
  return out;
}
ipcMain.handle('video:pickFolder', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Video folder', properties: ['openDirectory'] });
  if (r.canceled || !r.filePaths.length) return null;
  return { folder: r.filePaths[0], files: listVideos(r.filePaths[0], 0) };
});
ipcMain.handle('video:scan', async (e, folder) => {
  if (typeof folder !== 'string' || !fs.existsSync(folder)) return null;
  return { folder, files: listVideos(folder, 0) };
});
ipcMain.handle('video:pickFiles', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Video', properties: ['openFile'],
    filters: [{ name: 'Video', extensions: ['mp4', '3gp', 'mkv', 'mov', 'webm'] }],
  });
  if (r.canceled || !r.filePaths.length) return null;
  return r.filePaths.map(videoEntry);
});
