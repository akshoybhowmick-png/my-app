// Safe bridge between the page and the main process.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  openFile: (opts) => ipcRenderer.invoke('file:open', opts),
  readFile: (p) => ipcRenderer.invoke('file:read', p),
  saveFile: (opts) => ipcRenderer.invoke('file:save', opts),
  showInFolder: (p) => ipcRenderer.invoke('file:show', p),
  savePdf: (opts) => ipcRenderer.invoke('pdf:save', opts),
  info: () => ipcRenderer.invoke('app:info'),
  openUrl: (u) => ipcRenderer.invoke('app:open-url', u),
  onCloseRequest: (fn) => ipcRenderer.on('app:close-request', () => fn()),
  closeOk: () => ipcRenderer.send('app:close-ok'),
  pickVideoFolder: () => ipcRenderer.invoke('video:pickFolder'),
  scanVideoFolder: (f) => ipcRenderer.invoke('video:scan', f),
  pickVideoFiles: () => ipcRenderer.invoke('video:pickFiles'),
});
