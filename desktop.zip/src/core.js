/*
 * Road Survey Desktop — core logic (no user interface here).
 * Same file formats and calculations as the Android app, so a backup can go
 * phone → computer → phone without losing anything.
 * Developed by Akshoy Bhowmick
 */
(function (root) {
  'use strict';

  const DEVELOPER = 'Developed by Akshoy Bhowmick';

  // ---------------- language ----------------
  let lang = 'bn';
  function setLang(l) { lang = l === 'en' ? 'en' : 'bn'; }
  function getLang() { return lang; }
  function t(bn, en) { return lang === 'en' ? en : bn; }

  // ---------------- geometry ----------------
  const R = 6371008.8;
  const rad = (d) => d * Math.PI / 180;
  const deg = (r) => r * 180 / Math.PI;

  function distance(lat1, lon1, lat2, lon2) {
    const p1 = rad(lat1), p2 = rad(lat2), dp = rad(lat2 - lat1), dl = rad(lon2 - lon1);
    const a = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
    return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function bearing(lat1, lon1, lat2, lon2) {
    const p1 = rad(lat1), p2 = rad(lat2), dl = rad(lon2 - lon1);
    const y = Math.sin(dl) * Math.cos(p2);
    const x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
    return (deg(Math.atan2(y, x)) + 360) % 360;
  }

  function utm(lat, lon, zone) {
    if (!zone) {
      zone = Math.floor((lon + 180) / 6) + 1;
      zone = Math.max(1, Math.min(60, zone));
    }
    const a = 6378137.0, f = 1 / 298.257223563, k0 = 0.9996;
    const e2 = f * (2 - f), ep2 = e2 / (1 - e2);
    const lon0 = rad((zone - 1) * 6 - 180 + 3);
    const phi = rad(lat), lam = rad(lon);
    const sin = Math.sin(phi), cos = Math.cos(phi), tan = Math.tan(phi);
    const N = a / Math.sqrt(1 - e2 * sin * sin);
    const T = tan * tan, C = ep2 * cos * cos, A = cos * (lam - lon0);
    const e4 = e2 * e2, e6 = e4 * e2;
    const M = a * ((1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi
      - (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * Math.sin(2 * phi)
      + (15 * e4 / 256 + 45 * e6 / 1024) * Math.sin(4 * phi)
      - (35 * e6 / 3072) * Math.sin(6 * phi));
    const x = k0 * N * (A + (1 - T + C) * A ** 3 / 6
      + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * A ** 5 / 120) + 500000.0;
    const y = k0 * (M + N * tan * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A ** 4 / 24
      + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * A ** 6 / 720));
    return { zone, north: lat >= 0, easting: x, northing: lat < 0 ? y + 10000000.0 : y, label: zone + (lat >= 0 ? 'N' : 'S') };
  }

  function fmtCh(metres) {
    let m = Math.round(metres);
    const sign = m < 0 ? '-' : '';
    m = Math.abs(m);
    return sign + Math.floor(m / 1000) + '+' + String(m % 1000).padStart(3, '0');
  }

  function parseCh(s) {
    if (s == null) return NaN;
    s = String(s).trim().replace(/\s/g, '');
    if (s === '') return 0;
    const plus = s.indexOf('+');
    const num = (x) => (x === '' ? 0 : (/^-?\d*\.?\d+$/.test(x) ? parseFloat(x) : NaN));
    if (plus >= 0) return num(s.slice(0, plus)) * 1000 + num(s.slice(plus + 1));
    return num(s);
  }

  /** Planar area (m²) of a lat/lon polygon (small areas, local projection). */
  function polygonArea(ll) {
    if (ll.length < 3) return 0;
    const lat0 = ll[0][0];
    const k = Math.cos(rad(lat0)) * 111320, m = 110540;
    let s = 0;
    for (let i = 0; i < ll.length; i++) {
      const a = ll[i], b = ll[(i + 1) % ll.length];
      s += (a[1] * k) * (b[0] * m) - (b[1] * k) * (a[0] * m);
    }
    return Math.abs(s) / 2;
  }

  function pathLength(ll) {
    let s = 0;
    for (let i = 1; i < ll.length; i++) s += distance(ll[i - 1][0], ll[i - 1][1], ll[i][0], ll[i][1]);
    return s;
  }

  // ---------------- Java-compatible number formatting ----------------
  const fx = (v, d) => (Number.isFinite(v) ? v.toFixed(d) : (Number.isNaN(v) ? 'NaN' : (v > 0 ? 'Infinity' : '-Infinity')));

  function pad2(n) { return String(n).padStart(2, '0'); }
  function localTime(ms) {
    const d = new Date(ms);
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' '
      + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
  }
  function isoTime(ms) { return new Date(ms).toISOString().replace(/\.\d{3}Z$/, 'Z'); }
  function stamp() {
    const d = new Date();
    return d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + '_' + pad2(d.getHours()) + pad2(d.getMinutes());
  }

  // ---------------- survey files ----------------
  function lines(text) { return (text || '').split(/\r?\n/); }

  function parsePoints(text) {
    const out = [];
    for (const line of lines(text)) {
      const a = line.split(',');
      if (a.length < 6) continue;
      const p = { lat: +a[0], lon: +a[1], alt: +a[2], acc: +a[3], time: +a[4], ch: +a[5] };
      if ([p.lat, p.lon, p.time, p.ch].some((v) => !Number.isFinite(v))) continue;
      if (!Number.isFinite(p.alt)) p.alt = 0;
      if (!Number.isFinite(p.acc)) p.acc = 0;
      out.push(p);
    }
    return out;
  }
  function pointLine(p) { return [fx(p.lat, 7), fx(p.lon, 7), fx(p.alt, 1), fx(p.acc, 1), Math.round(p.time), fx(p.ch, 2)].join(','); }
  function writePoints(pts) { return pts.map((p) => pointLine(p) + '\n').join(''); }

  function splitN(line, n) { // like Java split(",", n)
    const out = [];
    let rest = line;
    while (out.length < n - 1) {
      const i = rest.indexOf(',');
      if (i < 0) break;
      out.push(rest.slice(0, i));
      rest = rest.slice(i + 1);
    }
    out.push(rest);
    return out;
  }

  function parseMarks(text) {
    const out = [];
    for (const line of lines(text)) {
      if (!line) continue;
      const a = splitN(line, 7);
      if (a.length < 7) continue;
      const m = { lat: +a[0], lon: +a[1], alt: +a[2], ch: +a[3], time: +a[4], photo: a[5].replace(/%2C/g, ','), name: a[6] };
      if ([m.lat, m.lon, m.ch, m.time].some((v) => !Number.isFinite(v))) continue;
      if (!Number.isFinite(m.alt)) m.alt = 0;
      out.push(m);
    }
    return out;
  }
  function cleanText(s) { return String(s == null ? '' : s).replace(/[\r\n]/g, ' ').trim(); }
  function markLine(m) {
    return [fx(m.lat, 7), fx(m.lon, 7), fx(m.alt, 1), fx(m.ch, 2), Math.round(m.time), (m.photo || '').replace(/,/g, '%2C'), cleanText(m.name)].join(',');
  }
  function writeMarks(marks) { return marks.map((m) => markLine(m) + '\n').join(''); }

  function parseSegments(text) {
    const out = [];
    for (const line of lines(text)) {
      if (!line) continue;
      const a = splitN(line, 5);
      if (a.length < 5) continue;
      const g = { ch: +a[0], time: +a[1], width: a[2] === '' ? NaN : +a[2], surface: a[3], condition: a[4] };
      if (!Number.isFinite(g.ch) || !Number.isFinite(g.time)) continue;
      out.push(g);
    }
    return out;
  }
  function writeSegments(segs) {
    return segs.map((g) => [fx(g.ch, 2), Math.round(g.time), Number.isFinite(g.width) ? fx(g.width, 2) : '',
      cleanText(g.surface).replace(/,/g, ' '), cleanText(g.condition)].join(',') + '\n').join('');
  }

  // videos.csv: start,end,uri,name (phone clock, ms)
  function parseVideos(text) {
    const out = [];
    for (const line of lines(text)) {
      if (!line) continue;
      const a = splitN(line, 4);
      if (a.length < 4) continue;
      const v = { start: +a[0], end: +a[1], uri: a[2].replace(/%2C/g, ','), name: a[3] };
      if (Number.isFinite(v.start) && Number.isFinite(v.end) && v.end > v.start) out.push(v);
    }
    return out;
  }

  /** The stretch of road a video covers: [[lat, lon, ch], ...] */
  function videoPath(pts, v) {
    const out = [];
    const a = positionAt(pts, v.start), z = positionAt(pts, v.end);
    if (!a) return out;
    out.push([a[0], a[1], a[2]]);
    for (const p of pts) if (p.time > v.start && p.time < v.end) out.push([p.lat, p.lon, p.ch]);
    out.push([z[0], z[1], z[2]]);
    return out;
  }

  // Design / reference layer (ref.csv)
  function parseRef(text) {
    const r = { name: '', lines: [], points: [] };
    let cur = null, seg = null;
    for (const line of lines(text)) {
      if (line.startsWith('N,')) r.name = line.slice(2);
      else if (line.startsWith('L,')) {
        const a = splitN(line, 4);
        if (a.length < 4) continue;
        if (a[1] !== cur) { seg = []; r.lines.push(seg); cur = a[1]; }
        seg.push([+a[2], +a[3]]);
      } else if (line.startsWith('P,')) {
        const a = splitN(line, 4);
        if (a.length < 3) continue;
        r.points.push({ lat: +a[1], lon: +a[2], name: a.length > 3 ? a[3] : '' });
      }
    }
    return r;
  }
  function writeRef(r) {
    let s = 'N,' + cleanText(r.name) + '\n';
    r.lines.forEach((ln, i) => ln.forEach((q) => { s += 'L,' + i + ',' + fx(q[0], 8) + ',' + fx(q[1], 8) + '\n'; }));
    r.points.forEach((p) => { s += 'P,' + fx(p.lat, 8) + ',' + fx(p.lon, 8) + ',' + cleanText(p.name) + '\n'; });
    return s;
  }

  // Java .properties (read + write, as Properties.load/store(Writer) do)
  function parseProps(text) {
    const out = {};
    const raw = lines(text);
    for (let i = 0; i < raw.length; i++) {
      let line = raw[i].replace(/^[ \t\f]+/, '');
      if (!line || line[0] === '#' || line[0] === '!') continue;
      while (/(^|[^\\])(\\\\)*\\$/.test(line) && i + 1 < raw.length) line = line.slice(0, -1) + raw[++i].replace(/^[ \t\f]+/, '');
      let k = '', j = 0;
      for (; j < line.length; j++) {
        const c = line[j];
        if (c === '\\') { k += line[j] + (line[j + 1] || ''); j++; continue; }
        if (c === '=' || c === ':' || c === ' ' || c === '\t') break;
        k += c;
      }
      let v = line.slice(j).replace(/^[ \t]*[=:]?[ \t]*/, '');
      out[unesc(k)] = unesc(v);
    }
    return out;
  }
  function unesc(s) {
    return s.replace(/\\(u[0-9a-fA-F]{4}|.)/g, (m, g) => {
      if (g[0] === 'u' && g.length === 5) return String.fromCharCode(parseInt(g.slice(1), 16));
      return { t: '\t', n: '\n', r: '\r', f: '\f' }[g] || g;
    });
  }
  function escProp(s, key) {
    let o = '';
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (c === ' ' && (key || i === 0)) o += '\\ ';
      else if (c === '\\') o += '\\\\';
      else if (c === '\t') o += '\\t';
      else if (c === '\n') o += '\\n';
      else if (c === '\r') o += '\\r';
      else if (c === '\f') o += '\\f';
      else if ('=:#!'.includes(c)) o += '\\' + c;
      else if (c.charCodeAt(0) < 0x20) o += '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0');
      else o += c;
    }
    return o;
  }
  function writeProps(obj) {
    let s = '#' + new Date().toString() + '\n';
    for (const k of Object.keys(obj)) s += escProp(k, true) + '=' + escProp(String(obj[k]), false) + '\n';
    return s;
  }

  // ---------------- survey model ----------------
  /** files: { 'meta.properties': text, 'points.csv': text, ... } */
  function surveyFromFiles(id, files) {
    const meta = parseProps(files['meta.properties'] || '');
    const s = {
      id,
      meta,
      name: meta.name || t('সার্ভে', 'Survey'),
      startCh: Number.isFinite(parseFloat(meta.startCh)) ? parseFloat(meta.startCh) : 0,
      created: Number.isFinite(parseFloat(meta.created)) ? parseFloat(meta.created) : Date.now(),
      points: parsePoints(files['points.csv']),
      original: files['points_original.csv'] != null ? parsePoints(files['points_original.csv']) : null,
      marks: parseMarks(files['marks.csv']),
      segments: parseSegments(files['segments.csv']),
      videosText: files['videos.csv'] || null,
      ref: files['ref.csv'] ? parseRef(files['ref.csv']) : null,
      changed: false,
    };
    if (!s.meta.created) s.meta.created = String(Math.round(s.created));
    return s;
  }

  function surveyToFiles(s) {
    const meta = Object.assign({}, s.meta, { name: s.name, startCh: String(s.startCh), created: String(Math.round(s.created)) });
    const f = {
      'meta.properties': writeProps(meta),
      'points.csv': writePoints(s.points),
      'marks.csv': writeMarks(s.marks),
    };
    if (s.original) f['points_original.csv'] = writePoints(s.original);
    if (s.segments.length) f['segments.csv'] = writeSegments(s.segments);
    if (s.videosText) f['videos.csv'] = s.videosText;
    if (s.ref && (s.ref.lines.length || s.ref.points.length)) f['ref.csv'] = writeRef(s.ref);
    return f;
  }

  function length(pts) { return pts.length ? pts[pts.length - 1].ch : 0; }

  function recomputeCh(pts) {
    for (let i = 0; i < pts.length; i++) {
      pts[i].ch = i === 0 ? 0 : pts[i - 1].ch + distance(pts[i - 1].lat, pts[i - 1].lon, pts[i].lat, pts[i].lon);
    }
    return pts;
  }

  function positionAt(pts, t) {
    if (!pts.length) return null;
    if (t <= pts[0].time) return [pts[0].lat, pts[0].lon, pts[0].ch, 0];
    const last = pts[pts.length - 1];
    if (t >= last.time) return [last.lat, last.lon, last.ch, 0];
    let lo = 0, hi = pts.length - 1;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (pts[mid].time <= t) lo = mid; else hi = mid;
    }
    const a = pts[lo], b = pts[hi];
    const span = Math.max(1, b.time - a.time), f = (t - a.time) / span;
    return [a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f, a.ch + (b.ch - a.ch) * f, 0];
  }

  /** Raw chainage of a location: nearest point ON the line (projection onto segments). */
  function project(pts, lat, lon) {
    if (!pts.length) return { ch: 0, dist: Infinity, lat, lon, index: -1 };
    if (pts.length === 1) return { ch: 0, dist: distance(lat, lon, pts[0].lat, pts[0].lon), lat: pts[0].lat, lon: pts[0].lon, index: 0 };
    const k = Math.cos(rad(lat)) * 111320, m = 110540;
    const px = lon * k, py = lat * m;
    let best = Infinity, out = null;
    for (let i = 0; i + 1 < pts.length; i++) {
      const ax = pts[i].lon * k, ay = pts[i].lat * m, bx = pts[i + 1].lon * k, by = pts[i + 1].lat * m;
      const dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
      const tt = l2 < 1e-9 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l2));
      const qx = ax + tt * dx - px, qy = ay + tt * dy - py, d = qx * qx + qy * qy;
      if (d < best) {
        best = d;
        out = {
          ch: pts[i].ch + (pts[i + 1].ch - pts[i].ch) * tt, dist: Math.sqrt(d), index: i, t: tt,
          lat: pts[i].lat + (pts[i + 1].lat - pts[i].lat) * tt, lon: pts[i].lon + (pts[i + 1].lon - pts[i].lon) * tt,
        };
      }
    }
    return out;
  }

  /** Same rule as the phone: by time when the mark was taken during the recording, else nearest place. */
  function chainageForMark(pts, m) {
    if (pts.length) {
      const a = pts[0], b = pts[pts.length - 1];
      if (m.time >= a.time && m.time <= b.time) {
        const pos = positionAt(pts, m.time);
        if (pos && distance(pos[0], pos[1], m.lat, m.lon) < 40) return pos[2];
      }
    }
    return project(pts, m.lat, m.lon).ch;
  }

  function afterLineChanged(s) {
    for (const m of s.marks) m.ch = chainageForMark(s.points, m);
    const pts = s.points;
    for (const g of s.segments) {
      const pos = positionAt(pts, g.time);
      if (pos && pts.length && g.time >= pts[0].time && g.time <= pts[pts.length - 1].time) g.ch = pos[2];
    }
    s.segments.sort((x, y) => x.ch - y.ch);
  }

  /** Point at a raw chainage along the line: [lat, lon, index]. */
  function pointAtCh(pts, c) {
    if (!pts.length) return null;
    let i = 1;
    while (i < pts.length - 1 && pts[i].ch < c) i++;
    if (pts.length === 1) return [pts[0].lat, pts[0].lon, 0];
    const a = pts[i - 1], b = pts[i];
    const f = b.ch - a.ch < 1e-6 ? 0 : Math.max(0, Math.min(1, (c - a.ch) / (b.ch - a.ch)));
    return [a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f, i];
  }

  // ---------------- cleaning tools ----------------
  /** Moving average (radius points each side); ends stay fixed. */
  function smoothTrack(pts, radius) {
    const n = pts.length;
    if (n < 5 || radius < 1) return pts.map((p) => Object.assign({}, p));
    const out = pts.map((p) => Object.assign({}, p));
    for (let i = 1; i < n - 1; i++) {
      const r = Math.min(radius, i, n - 1 - i);
      let sl = 0, so = 0;
      for (let q = i - r; q <= i + r; q++) { sl += pts[q].lat; so += pts[q].lon; }
      out[i].lat = sl / (2 * r + 1);
      out[i].lon = so / (2 * r + 1);
    }
    return recomputeCh(out);
  }

  /** Removes points closer than minStep to the previous kept point and impossible jumps. */
  function cleanTrack(pts, minStep) {
    if (pts.length < 3) return pts.map((p) => Object.assign({}, p));
    const out = [Object.assign({}, pts[0])];
    for (let i = 1; i < pts.length; i++) {
      const last = out[out.length - 1], p = pts[i];
      const d = distance(last.lat, last.lon, p.lat, p.lon);
      const dt = Math.max(1, (p.time - last.time) / 1000);
      if (d / dt > 70) continue;
      if (d < minStep && i !== pts.length - 1) continue;
      out.push(Object.assign({}, p));
    }
    return recomputeCh(out);
  }

  // ---------------- grip edit (same as the phone) ----------------
  function segDist(px, py, ax, ay, bx, by) {
    const dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
    const tt = l2 < 1e-12 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l2));
    return Math.hypot(ax + tt * dx - px, ay + tt * dy - py);
  }

  function douglasPeucker(pts, tol) {
    const n = pts.length;
    const keep = new Uint8Array(n);
    keep[0] = 1; keep[n - 1] = 1;
    const k = Math.cos(rad(pts[0].lat)) * 111320.0, m = 111320.0;
    const x = pts.map((p) => p.lon * k), y = pts.map((p) => p.lat * m);
    const stack = [0, n - 1];
    while (stack.length) {
      const b = stack.pop(), a = stack.pop();
      if (b - a < 2) continue;
      let best = -1, bi = -1;
      for (let i = a + 1; i < b; i++) {
        const d = segDist(x[i], y[i], x[a], y[a], x[b], y[b]);
        if (d > best) { best = d; bi = i; }
      }
      if (best > tol && bi > 0) { keep[bi] = 1; stack.push(a, bi, bi, b); }
    }
    const out = [];
    for (let i = 0; i < n; i++) if (keep[i]) out.push(i);
    return out;
  }

  function simplify(pts, maxGrips, maxGap) {
    if (pts.length < 2) return pts.map((p, i) => ({ lat: p.lat, lon: p.lon, orig: i }));
    let tol = 1.0, keep;
    for (;;) {
      keep = douglasPeucker(pts, tol);
      if (keep.length <= maxGrips || tol > 200) break;
      tol *= 1.5;
    }
    // straight stretches get a grip at least every maxGap metres, so they can be bent too
    if (maxGap > 0) {
      const extra = [];
      for (let q = 0; q + 1 < keep.length; q++) {
        const a = keep[q], b = keep[q + 1];
        const gap = pts[b].ch - pts[a].ch;
        if (gap <= maxGap * 1.5) continue;
        const n = Math.floor(gap / maxGap);
        let j = a;
        for (let k = 1; k < n; k++) {
          const target = pts[a].ch + gap * k / n;
          while (j < b && pts[j].ch < target) j++;
          if (j > a && j < b) extra.push(j);
        }
      }
      if (keep.length + extra.length <= maxGrips * 1.5) keep = Array.from(new Set(keep.concat(extra))).sort((x, y) => x - y);
    }
    return keep.map((i) => ({ lat: pts[i].lat, lon: pts[i].lon, orig: i }));
  }

  function rebuild(pts, verts) {
    const out = [];
    const anchorPos = [];
    verts.forEach((v, i) => { if (v.orig >= 0) anchorPos.push(i); });
    if (anchorPos.length < 2) return pts.map((p) => Object.assign({}, p));
    const copyAt = (src, lat, lon) => ({ lat, lon, alt: src.alt, acc: src.acc, time: src.time, ch: src.ch });
    const v0 = verts[anchorPos[0]];
    for (let j = 0; j < v0.orig; j++) out.push(copyAt(pts[j], v0.lat, v0.lon));
    for (let a = 0; a + 1 < anchorPos.length; a++) {
      const va = anchorPos[a], vb = anchorPos[a + 1];
      const ia = verts[va].orig, ib = verts[vb].orig;
      if (ib <= ia) continue;
      const path = [];
      for (let q = va; q <= vb; q++) path.push([verts[q].lat, verts[q].lon]);
      const cum = new Array(path.length).fill(0);
      for (let q = 1; q < path.length; q++) cum[q] = cum[q - 1] + distance(path[q - 1][0], path[q - 1][1], path[q][0], path[q][1]);
      const pathLen = cum[cum.length - 1];
      const chA = pts[ia].ch, chB = pts[ib].ch;
      const last = a + 2 === anchorPos.length ? ib : ib - 1;
      for (let j = ia; j <= last; j++) {
        const f = chB - chA < 1e-9 ? (j - ia) / Math.max(1, ib - ia) : (pts[j].ch - chA) / (chB - chA);
        const target = Math.max(0, Math.min(1, f)) * pathLen;
        let q = 1;
        while (q < cum.length - 1 && cum[q] < target) q++;
        const seg = cum[q] - cum[q - 1];
        const tt = seg < 1e-9 ? 0 : (target - cum[q - 1]) / seg;
        out.push(copyAt(pts[j], path[q - 1][0] + (path[q][0] - path[q - 1][0]) * tt, path[q - 1][1] + (path[q][1] - path[q - 1][1]) * tt));
      }
    }
    const lv = verts[anchorPos[anchorPos.length - 1]];
    for (let j = lv.orig + 1; j < pts.length; j++) out.push(copyAt(pts[j], lv.lat, lv.lon));
    return recomputeCh(out);
  }

  // ---------------- curves ----------------
  function angleDiff(b, a) {
    let d = (b - a) % 360;
    if (d > 180) d -= 360;
    if (d < -180) d += 360;
    return d;
  }

  function findCurves(pts) {
    const STEP = 5, CHORD = 20, MAX_RADIUS = 600, MIN_DEFLECTION = 8, MIN_LENGTH = 15, MERGE_GAP = 20;
    const out = [];
    if (pts.length < 4) return out;
    const len = length(pts);
    if (len < 4 * CHORD) return out;
    const n = Math.floor(len / STEP) + 1;
    let lat = new Array(n), lon = new Array(n);
    const ch = new Array(n);
    let j = 1;
    for (let i = 0; i < n; i++) {
      const c = i * STEP;
      while (j < pts.length - 1 && pts[j].ch < c) j++;
      const a = pts[j - 1], b = pts[j];
      const f = b.ch - a.ch < 1e-6 ? 0 : Math.max(0, Math.min(1, (c - a.ch) / (b.ch - a.ch)));
      lat[i] = a.lat + (b.lat - a.lat) * f;
      lon[i] = a.lon + (b.lon - a.lon) * f;
      ch[i] = c;
    }
    for (let pass = 0; pass < 2; pass++) {
      const la2 = new Array(n), lo2 = new Array(n);
      for (let i = 0; i < n; i++) {
        const a0 = Math.max(0, i - 3), a1 = Math.min(n - 1, i + 3);
        let sl = 0, so = 0;
        for (let q = a0; q <= a1; q++) { sl += lat[q]; so += lon[q]; }
        la2[i] = sl / (a1 - a0 + 1);
        lo2[i] = so / (a1 - a0 + 1);
      }
      lat = la2; lon = lo2;
    }
    const k = Math.round(CHORD / STEP);
    const head = new Array(n);
    for (let i = 0; i < n; i++) {
      const i0 = Math.max(0, i - k), i1 = Math.min(n - 1, i + k);
      head[i] = bearing(lat[i0], lon[i0], lat[i1], lon[i1]);
    }
    const curv = new Array(n).fill(0);
    for (let i = 1; i < n - 1; i++) curv[i] = angleDiff(head[i + 1], head[i - 1]) / (2 * STEP);
    const minCurv = deg(1.0 / MAX_RADIUS);
    const pieces = [];
    let i = 1;
    while (i < n - 1) {
      if (Math.abs(curv[i]) < minCurv) { i++; continue; }
      const right = curv[i] > 0;
      const s = i;
      while (i < n - 1 && Math.abs(curv[i]) >= minCurv * 0.6 && (curv[i] > 0) === right) i++;
      pieces.push([s, i - 1, right ? 1 : 0]);
    }
    const merged = [];
    for (const pc of pieces) {
      if (merged.length) {
        const last = merged[merged.length - 1];
        if (last[2] === pc[2] && (pc[0] - last[1]) * STEP <= MERGE_GAP) { last[1] = pc[1]; continue; }
      }
      merged.push(pc.slice());
    }
    const half = Math.floor(k / 2);
    for (const pc of merged) {
      let s = pc[0], e = pc[1];
      const right = pc[2] === 1;
      const defl = Math.abs(angleDiff(head[Math.min(n - 1, e + half)], head[Math.max(0, s - half)]));
      let peak = 0;
      for (let q = s; q <= e; q++) peak = Math.max(peak, Math.abs(curv[q]));
      let cs = e, ce = s;
      for (let q = s; q <= e; q++) if (Math.abs(curv[q]) >= peak * 0.5) { cs = Math.min(cs, q); ce = Math.max(ce, q); }
      if (ce < cs) { cs = s; ce = e; }
      const lc = ch[ce] - ch[cs] + STEP;
      if (defl < MIN_DEFLECTION || lc < MIN_LENGTH) continue;
      s = cs; e = ce;
      const r = rad(defl);
      const radius = lc / r;
      const mid = (s + e) >> 1;
      out.push({
        startCh: ch[s], endCh: ch[e], length: lc, deflection: defl, right, radius,
        tangent: defl < 170 ? radius * Math.tan(r / 2) : NaN, midLat: lat[mid], midLon: lon[mid],
      });
    }
    return out;
  }

  // ---------------- elevation profile ----------------
  function smoothAlt(pts) {
    const n = pts.length, out = new Array(n);
    let lo = 0, hi = 0, sum = 0;
    for (let i = 0; i < n; i++) {
      const c = pts[i].ch;
      while (hi < n && (pts[hi].ch - c <= 40 || hi - i <= 3)) { sum += pts[hi].alt; hi++; }
      while (lo < i && c - pts[lo].ch > 40 && i - lo > 3) { sum -= pts[lo].alt; lo++; }
      out[i] = sum / Math.max(1, hi - lo);
    }
    return out;
  }

  function profileStats(pts) {
    const s = { valid: false };
    if (pts.length < 2) return s;
    const h = smoothAlt(pts);
    s.minAlt = Infinity; s.maxAlt = -Infinity; s.rise = 0; s.fall = 0; s.maxGrade = 0;
    let ref = h[0];
    for (const v of h) {
      s.minAlt = Math.min(s.minAlt, v);
      s.maxAlt = Math.max(s.maxAlt, v);
      if (v - ref >= 3) { s.rise += v - ref; ref = v; } else if (ref - v >= 3) { s.fall += ref - v; ref = v; }
    }
    s.startAlt = h[0];
    s.endAlt = h[h.length - 1];
    const len = length(pts);
    s.avgGrade = len > 0 ? (s.endAlt - s.startAlt) / len * 100 : 0;
    let j = 0;
    for (let i = 0; i < pts.length; i++) {
      if (j < i) j = i;
      while (j < pts.length && pts[j].ch - pts[i].ch < 100) j++;
      if (j >= pts.length) break;
      s.maxGrade = Math.max(s.maxGrade, Math.abs(h[j] - h[i]) / (pts[j].ch - pts[i].ch) * 100);
    }
    s.valid = true;
    return s;
  }

  // ---------------- attachments ----------------
  function attachments(field) { return (field || '').split('|').filter((x) => x); }
  function photosOf(field) { return attachments(field).filter((x) => !x.startsWith('audio:')); }
  function audiosOf(field) { return attachments(field).filter((x) => x.startsWith('audio:')).map((x) => x.slice(6)); }
  function attachmentLabel(uri) {
    try { uri = decodeURIComponent(uri); } catch (e) { /* keep */ }
    const s = uri.lastIndexOf('/');
    return s >= 0 ? uri.slice(s + 1) : uri;
  }

  // ---------------- exports ----------------
  const xml = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
  const csvCell = (s) => (/[",\n]/.test(s) ? '"' + String(s).replace(/"/g, '""') + '"' : String(s));

  /** videoUrls[k] = file:/// address of video k on this computer (or null). */
  function kml(s, photoPaths, videoUrls) {
    const pts = s.points, startCh = s.startCh;
    let o = '<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2">\n<Document>\n'
      + '<name>' + xml(s.name) + '</name>\n<description>' + DEVELOPER + '</description>\n'
      + '<Style id="road"><LineStyle><color>ff0000ff</color><width>4</width></LineStyle></Style>\n'
      + '<Style id="km"><IconStyle><scale>0.6</scale></IconStyle><LabelStyle><scale>0.8</scale></LabelStyle></Style>\n'
      + '<Style id="design"><LineStyle><color>ffff00ff</color><width>2</width></LineStyle></Style>\n'
      + '<Style id="video"><LineStyle><color>ffb0279c</color><width>9</width></LineStyle>'
      + '<IconStyle><color>ffb0279c</color><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/shapes/movies.png</href></Icon></IconStyle></Style>\n';
    if (pts.length) {
      const len = length(pts);
      o += '<Placemark>\n<name>' + xml(s.name) + '</name>\n<description>Chainage ' + fmtCh(startCh) + ' to ' + fmtCh(startCh + len)
        + ', length ' + len.toFixed(1) + ' m</description>\n<styleUrl>#road</styleUrl>\n<LineString>\n<tessellate>1</tessellate>\n<coordinates>\n';
      for (const p of pts) o += fx(p.lon, 7) + ',' + fx(p.lat, 7) + ',' + fx(p.alt, 1) + '\n';
      o += '</coordinates>\n</LineString>\n</Placemark>\n<Folder><name>Km chainage</name>\n';
      let next = Math.ceil(startCh / 1000) * 1000;
      for (let i = 1; i < pts.length; i++) {
        const a = pts[i - 1], b = pts[i], ca = startCh + a.ch, cb = startCh + b.ch;
        while (next <= cb) {
          if (next >= ca) {
            const f = cb - ca < 1e-6 ? 0 : (next - ca) / (cb - ca);
            o += '<Placemark><name>' + fmtCh(next) + '</name><styleUrl>#km</styleUrl><Point><coordinates>'
              + fx(a.lon + (b.lon - a.lon) * f, 7) + ',' + fx(a.lat + (b.lat - a.lat) * f, 7) + ',0</coordinates></Point></Placemark>\n';
          }
          next += 1000;
        }
      }
      o += '</Folder>\n';
    }
    o += '<Folder><name>Points</name>\n';
    s.marks.forEach((m, idx) => {
      const img = photoPaths && photoPaths[idx];
      o += '<Placemark>\n<name>' + (idx + 1) + '. ' + xml(m.name) + '</name>\n';
      if (img) {
        o += '<description><![CDATA[<b>Chainage ' + fmtCh(startCh + m.ch) + '</b><br/>' + localTime(m.time) + '<br/>';
        for (const one of img) o += '<img src="' + one + '" width="480"/><br/>';
        o += ']]>';
      } else {
        o += '<description>Chainage ' + fmtCh(startCh + m.ch) + ' | ' + localTime(m.time);
        const ph = photosOf(m.photo);
        if (ph.length) o += ' | ' + xml(ph.map(attachmentLabel).join('; '));
      }
      o += '</description>\n<Point><coordinates>' + fx(m.lon, 7) + ',' + fx(m.lat, 7) + ',' + fx(m.alt, 1) + '</coordinates></Point>\n</Placemark>\n';
    });
    o += '</Folder>\n';
    const vids = parseVideos(s.videosText);
    if (vids.length && pts.length >= 2) {
      o += '<Folder><name>Videos</name>\n';
      vids.forEach((v, k) => {
        const path = videoPath(pts, v);
        if (path.length < 2) return;
        const sec = Math.round((v.end - v.start) / 1000);
        const url = videoUrls && videoUrls[k];
        let d = '<b>' + xml(v.name) + '</b><br/>Chainage ' + fmtCh(startCh + path[0][2]) + ' – ' + fmtCh(startCh + path[path.length - 1][2])
          + '<br/>' + localTime(v.start) + ' (' + Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0') + ')';
        if (url) d += '<br/><video controls autoplay width="560" src="' + url + '"></video><br/><a href="' + url + '">&#9654; Open the video</a>';
        const desc = '<![CDATA[' + d + ']]>';
        o += '<Placemark><name>Video ' + (k + 1) + '</name><description>' + desc + '</description><styleUrl>#video</styleUrl>'
          + '<Point><coordinates>' + fx(path[0][1], 7) + ',' + fx(path[0][0], 7) + ',0</coordinates></Point></Placemark>\n';
        o += '<Placemark><name>Video ' + (k + 1) + ' stretch</name><description>' + desc
          + '</description><styleUrl>#video</styleUrl><LineString><tessellate>1</tessellate><coordinates>\n';
        o += '</coordinates></LineString></Placemark>\n';
      });
      o += '</Folder>\n';
    }
    if (s.ref && s.ref.lines.length) {
      o += '<Folder><name>Design</name>\n';
      for (const ln of s.ref.lines) {
        o += '<Placemark><styleUrl>#design</styleUrl><LineString><tessellate>1</tessellate><coordinates>\n';
        for (const q of ln) o += fx(q[1], 7) + ',' + fx(q[0], 7) + ',0\n';
        o += '</coordinates></LineString></Placemark>\n';
      }
      o += '</Folder>\n';
    }
    o += '</Document>\n</kml>\n';
    return o;
  }

  function gpx(s) {
    let o = '<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="RoadSurvey Desktop" xmlns="http://www.topografix.com/GPX/1/1">\n';
    s.marks.forEach((m, i) => {
      o += '<wpt lat="' + fx(m.lat, 7) + '" lon="' + fx(m.lon, 7) + '"><ele>' + fx(m.alt, 1) + '</ele><time>' + isoTime(m.time) + '</time>'
        + '<name>' + (i + 1) + '. ' + xml(m.name) + '</name><desc>Chainage ' + fmtCh(s.startCh + m.ch) + '</desc></wpt>\n';
    });
    o += '<trk><name>' + xml(s.name) + '</name><trkseg>\n';
    for (const p of s.points) {
      o += '<trkpt lat="' + fx(p.lat, 7) + '" lon="' + fx(p.lon, 7) + '"><ele>' + fx(p.alt, 1) + '</ele><time>' + isoTime(p.time) + '</time></trkpt>\n';
    }
    return o + '</trkseg></trk>\n</gpx>\n';
  }

  function csv(s) {
    let o = '﻿Type,No,Name,Latitude,Longitude,Easting_m,Northing_m,UTM_zone,Altitude_m,Accuracy_m,Chainage_m,Chainage,Time,Photo\n';
    s.points.forEach((p, i) => {
      const c = s.startCh + p.ch, u = utm(p.lat, p.lon);
      o += ['TRACK', i + 1, '', fx(p.lat, 7), fx(p.lon, 7), fx(u.easting, 2), fx(u.northing, 2), u.label, fx(p.alt, 1), fx(p.acc, 1),
        fx(c, 2), fmtCh(c), localTime(p.time), ''].join(',') + '\n';
    });
    s.marks.forEach((m, i) => {
      const c = s.startCh + m.ch, u = utm(m.lat, m.lon);
      o += ['POINT', i + 1, csvCell(m.name), fx(m.lat, 7), fx(m.lon, 7), fx(u.easting, 2), fx(u.northing, 2), u.label, fx(m.alt, 1), '',
        fx(c, 2), fmtCh(c), localTime(m.time), csvCell(photosOf(m.photo).map(attachmentLabel).join('; '))].join(',') + '\n';
    });
    return o;
  }

  const round = (v, d) => { const p = 10 ** d; return Math.round(v * p) / p; };

  function chainageTable(s, step) {
    const pts = s.points, rows = [];
    if (pts.length < 2) return rows;
    const h = smoothAlt(pts), len = length(pts), startCh = s.startCh;
    const stations = [startCh];
    for (let st = Math.ceil(startCh / step) * step; st < startCh + len - 0.01; st += step) if (st > startCh + 0.01) stations.push(st);
    stations.push(startCh + len);
    let i = 1;
    for (const st of stations) {
      const raw = st - startCh;
      while (i < pts.length - 1 && pts[i].ch < raw) i++;
      const a = pts[i - 1], b = pts[i];
      const f = b.ch - a.ch < 1e-6 ? 0 : Math.max(0, Math.min(1, (raw - a.ch) / (b.ch - a.ch)));
      const lat = a.lat + (b.lat - a.lat) * f, lon = a.lon + (b.lon - a.lon) * f;
      const el = h[i - 1] + (h[i] - h[i - 1]) * f;
      rows.push({ ch: st, lat, lon, utm: utm(lat, lon), elev: el });
    }
    return rows;
  }

  function xlsxSheets(s, step) {
    const sheets = [];
    const t1 = [[t('চেইনেজ', 'Chainage'), t('চেইনেজ (মি)', 'Chainage (m)'), t('অক্ষাংশ', 'Latitude'), t('দ্রাঘিমাংশ', 'Longitude'),
      'Easting (m)', 'Northing (m)', 'UTM zone', t('উচ্চতা (মি, আনুমানিক)', 'Elevation (m, approx.)')]];
    for (const r of chainageTable(s, step)) {
      t1.push([fmtCh(r.ch), round(r.ch, 2), round(r.lat, 7), round(r.lon, 7), round(r.utm.easting, 2), round(r.utm.northing, 2), r.utm.label, round(r.elev, 1)]);
    }
    sheets.push([t('চেইনেজ টেবিল', 'Chainage table'), t1]);
    const t2 = [[t('নং', 'No.'), t('নাম', 'Name'), t('চেইনেজ', 'Chainage'), t('অক্ষাংশ', 'Latitude'), t('দ্রাঘিমাংশ', 'Longitude'),
      'Easting (m)', 'Northing (m)', 'UTM zone', t('উচ্চতা (মি)', 'Elevation (m)'), t('সময়', 'Time'), t('ছবি', 'Photo')]];
    s.marks.forEach((m, i) => {
      const u = utm(m.lat, m.lon);
      t2.push([i + 1, m.name, fmtCh(s.startCh + m.ch), round(m.lat, 7), round(m.lon, 7), round(u.easting, 2), round(u.northing, 2), u.label,
        round(m.alt, 1), localTime(m.time), photosOf(m.photo).map(attachmentLabel).join('; ')]);
    });
    sheets.push([t('চিহ্নিত পয়েন্ট', 'Marked points'), t2]);
    const t3 = [[t('নং', 'No.'), t('শুরু চেইনেজ', 'Start chainage'), t('শেষ চেইনেজ', 'End chainage'), t('দিক', 'Direction'),
      t('কোণ (°)', 'Deflection (°)'), t('ব্যাসার্ধ (মি, আনুমানিক)', 'Radius (m, approx.)'), t('বাঁকের দৈর্ঘ্য (মি)', 'Curve length (m)'),
      t('ট্যানজেন্ট দৈর্ঘ্য (মি)', 'Tangent length (m)'), t('মাঝের অক্ষাংশ', 'Mid latitude'), t('মাঝের দ্রাঘিমাংশ', 'Mid longitude')]];
    findCurves(s.points).forEach((c, i) => {
      t3.push([i + 1, fmtCh(s.startCh + c.startCh), fmtCh(s.startCh + c.endCh), c.right ? t('ডানে', 'Right') : t('বাঁয়ে', 'Left'),
        round(c.deflection, 1), round(c.radius, 0), round(c.length, 0), Number.isFinite(c.tangent) ? round(c.tangent, 0) : null,
        round(c.midLat, 7), round(c.midLon, 7)]);
    });
    sheets.push([t('বাঁক', 'Curves'), t3]);
    const t4 = [[t('থেকে', 'From'), t('পর্যন্ত', 'To'), t('দৈর্ঘ্য (মি)', 'Length (m)'), t('ধরন', 'Surface'), t('অবস্থা', 'Condition'), t('চওড়া (মি)', 'Width (m)')]];
    const total = length(s.points);
    s.segments.forEach((g, q) => {
      const to = q + 1 < s.segments.length ? s.segments[q + 1].ch : total;
      t4.push([fmtCh(s.startCh + g.ch), fmtCh(s.startCh + to), round(Math.max(0, to - g.ch), 1), g.surface, g.condition,
        Number.isFinite(g.width) ? round(g.width, 2) : null]);
    });
    sheets.push([t('রাস্তার অংশ', 'Road segments'), t4]);
    const len = length(s.points);
    sheets.push([t('সারাংশ', 'Summary'), [[t('বিষয়', 'Item'), t('মান', 'Value')],
      [t('সার্ভে', 'Survey'), s.name], [t('শুরুর চেইনেজ', 'Start chainage'), fmtCh(s.startCh)],
      [t('শেষ চেইনেজ', 'End chainage'), fmtCh(s.startCh + len)], [t('মোট দৈর্ঘ্য (মি)', 'Total length (m)'), round(len, 2)],
      [t('টেবিলের ব্যবধান (মি)', 'Table interval (m)'), step], [t('তৈরি', 'Created'), localTime(Date.now())],
      [t('লাইন হাতে সম্পাদিত', 'Line hand-edited'), s.original ? t('হ্যাঁ', 'Yes') : t('না', 'No')], ['', DEVELOPER]]]);
    return sheets;
  }

  function xlsxFiles(sheets) {
    const esc = (v) => String(v).replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const col = (i) => { let s = ''; i++; while (i > 0) { const r = (i - 1) % 26; s = String.fromCharCode(65 + r) + s; i = Math.floor((i - 1) / 26); } return s; };
    const head = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
    const files = {};
    let ct = head + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
      + '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
      + '<Default Extension="xml" ContentType="application/xml"/>'
      + '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
      + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
    sheets.forEach((_, i) => { ct += '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'; });
    files['[Content_Types].xml'] = ct + '</Types>';
    files['_rels/.rels'] = head + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
      + '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    let wb = head + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>';
    let rel = head + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
    const used = new Set();
    sheets.forEach(([name], i) => {
      let n = String(name).replace(/[\\/?*[\]:]/g, ' ').slice(0, 31);
      while (used.has(n)) n = (n.slice(0, 28) + ' ' + (i + 1));
      used.add(n);
      wb += '<sheet name="' + esc(n) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>';
      rel += '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>';
    });
    files['xl/workbook.xml'] = wb + '</sheets></workbook>';
    files['xl/_rels/workbook.xml.rels'] = rel + '<Relationship Id="rId' + (sheets.length + 1)
      + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
    files['xl/styles.xml'] = head + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
      + '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
      + '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
      + '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
      + '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
      + '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>'
      + '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
    sheets.forEach(([, rows], si) => {
      let sh = head + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        + '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetData>';
      rows.forEach((row, r) => {
        sh += '<row r="' + (r + 1) + '">';
        row.forEach((v, c) => {
          if (v == null || v === '') return;
          const ref = col(c) + (r + 1), style = r === 0 ? ' s="1"' : '';
          if (typeof v === 'number') {
            if (!Number.isFinite(v)) return;
            sh += '<c r="' + ref + '"' + style + '><v>' + v + '</v></c>';
          } else {
            sh += '<c r="' + ref + '" t="inlineStr"' + style + '><is><t xml:space="preserve">' + esc(v) + '</t></is></c>';
          }
        });
        sh += '</row>';
      });
      files['xl/worksheets/sheet' + (si + 1) + '.xml'] = sh + '</sheetData></worksheet>';
    });
    return files;
  }

  function dxf(s, step) {
    const pts = s.points, startCh = s.startCh;
    let o = '';
    let zone = 0;
    const g = (c, v) => { o += c + '\n' + (typeof v === 'number' ? v.toFixed(4) : v) + '\n'; };
    const txt = (str) => {
      let b = '';
      for (const ch of String(str)) {
        const c = ch.codePointAt(0);
        if (c >= 32 && c < 127) b += ch;
        else if (c >= 127 && c <= 0xFFFF) b += '\\U+' + c.toString(16).toUpperCase().padStart(4, '0');
      }
      return b;
    };
    const xy = (lat, lon) => {
      const u = utm(lat, lon, zone || undefined);
      if (!zone) zone = u.zone;
      return [u.easting, u.northing];
    };
    const text = (layer, x, y, h, rot, str, color) => {
      g(0, 'TEXT'); g(8, layer); g(62, String(color)); g(10, x); g(20, y); g(30, 0); g(40, h); g(1, txt(str)); g(50, rot);
    };
    const point = (layer, x, y, z, color) => { g(0, 'POINT'); g(8, layer); g(62, String(color)); g(10, x); g(20, y); g(30, z); };
    const poly = (layer, color, list, flag) => {
      g(0, 'POLYLINE'); g(8, layer); g(62, String(color)); g(66, '1'); g(70, flag); g(10, 0); g(20, 0); g(30, 0);
      for (const q of list) { g(0, 'VERTEX'); g(8, layer); g(10, q[0]); g(20, q[1]); g(30, q[2] || 0); if (flag === '8') g(70, '32'); }
      g(0, 'SEQEND'); g(8, layer);
    };
    if (pts.length) xy(pts[0].lat, pts[0].lon);
    g(0, 'SECTION'); g(2, 'HEADER'); g(9, '$ACADVER'); g(1, 'AC1009'); g(0, 'ENDSEC');
    g(0, 'SECTION'); g(2, 'ENTITIES');
    if (pts.length >= 2) {
      const h = smoothAlt(pts);
      poly('ROAD_CENTRELINE', 1, pts.map((p, i) => { const q = xy(p.lat, p.lon); return [q[0], q[1], h[i]]; }), '8');
      const len = length(pts);
      let next = Math.ceil(startCh / step) * step;
      for (let i = 1; i < pts.length; i++) {
        const a = pts[i - 1], b = pts[i], ca = startCh + a.ch, cb = startCh + b.ch;
        while (next <= cb) {
          if (next >= ca) {
            const f = cb - ca < 1e-6 ? 0 : (next - ca) / (cb - ca);
            const p = xy(a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f);
            const brg = bearing(a.lat, a.lon, b.lat, b.lon);
            const km = Math.round(next) % 1000 === 0;
            point('CHAINAGE', p[0], p[1], 0, km ? 5 : 7);
            text('CHAINAGE', p[0] + 1.5, p[1] + 1.5, km ? 4 : 2.5, -brg, fmtCh(next), km ? 5 : 7);
          }
          next += step;
        }
      }
      const s0 = xy(pts[0].lat, pts[0].lon);
      text('ROAD_CENTRELINE', s0[0] + 3, s0[1] - 6, 4, 0, s.name + '  START ' + fmtCh(startCh), 1);
      const e = pts[pts.length - 1], e0 = xy(e.lat, e.lon);
      text('ROAD_CENTRELINE', e0[0] + 3, e0[1] - 6, 4, 0, 'END ' + fmtCh(startCh + len), 1);
      findCurves(pts).forEach((c, i) => {
        const p = xy(c.midLat, c.midLon);
        text('CURVES', p[0] + 4, p[1] + 4, 3, 0, 'C' + (i + 1) + ' ' + (c.right ? 'RH' : 'LH') + ' R=' + c.radius.toFixed(0) + 'm D='
          + c.deflection.toFixed(1) + ' L=' + c.length.toFixed(0) + 'm Ch ' + fmtCh(startCh + c.startCh) + '-' + fmtCh(startCh + c.endCh), 3);
      });
      for (const sg of s.segments) {
        const pos = pointAtCh(pts, sg.ch);
        if (!pos) continue;
        const p = xy(pos[0], pos[1]);
        text('SEGMENTS', p[0] - 4, p[1] - 8, 2.5, 0, fmtCh(startCh + sg.ch) + ' ' + sg.surface + ' / ' + sg.condition
          + (Number.isFinite(sg.width) ? ' / ' + sg.width.toFixed(1) + 'm' : ''), 6);
      }
    }
    s.marks.forEach((m, i) => {
      const p = xy(m.lat, m.lon);
      point('POINTS', p[0], p[1], m.alt, 2);
      text('POINTS', p[0] + 1.5, p[1] - 1.5, 2.5, 0, (i + 1) + '. ' + m.name + '  ' + fmtCh(startCh + m.ch), 2);
    });
    if (s.ref) {
      for (const ln of s.ref.lines) poly('DESIGN', 4, ln.map((q) => xy(q[0], q[1])), '0');
      for (const rp of s.ref.points) {
        const p = xy(rp.lat, rp.lon);
        point('DESIGN', p[0], p[1], 0, 4);
        if (rp.name) text('DESIGN', p[0] + 1.5, p[1] + 1.5, 2, 0, rp.name, 4);
      }
    }
    g(0, 'ENDSEC'); g(0, 'EOF');
    return o;
  }

  // ---------------- KML / GPX import (design or new survey) ----------------
  /** Very small XML reader good enough for KML/GPX (no DOM needed, works in Node too). */
  function parseGeoXml(text, fileName) {
    const r = { name: fileName || '', lines: [], points: [], tracks: [] };
    const strip = (s) => s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/<[^>]+>/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&').trim();
    const tagRe = (tag) => new RegExp('<(?:\\w+:)?' + tag + '\\b[^>]*>([\\s\\S]*?)</(?:\\w+:)?' + tag + '>', 'gi');
    const first = (s, tag) => { const m = tagRe(tag).exec(s); return m ? m[1] : null; };
    const coords = (s) => s.trim().split(/\s+/).map((c) => c.split(',')).filter((a) => a.length >= 2)
      .map((a) => [parseFloat(a[1]), parseFloat(a[0]), a.length > 2 ? parseFloat(a[2]) : NaN]).filter((q) => Number.isFinite(q[0]) && Number.isFinite(q[1]));
    let m;
    // KML placemarks
    const pmRe = tagRe('Placemark');
    while ((m = pmRe.exec(text))) {
      const body = m[1];
      const nm = first(body, 'name');
      const name = nm ? strip(nm) : '';
      let cm;
      const lsRe = tagRe('LineString');
      while ((cm = lsRe.exec(body))) {
        const c = first(cm[1], 'coordinates');
        if (c) { const q = coords(c); if (q.length >= 2) { r.lines.push(q.map((x) => [x[0], x[1]])); r.tracks.push({ name, pts: q.map((x) => ({ lat: x[0], lon: x[1], alt: x[2], time: NaN })) }); } }
      }
      const gxRe = /<gx:Track\b[^>]*>([\s\S]*?)<\/gx:Track>/gi;
      while ((cm = gxRe.exec(body))) {
        const whens = [...cm[1].matchAll(/<when>([^<]*)<\/when>/gi)].map((x) => Date.parse(x[1].trim()));
        const cs = [...cm[1].matchAll(/<gx:coord>([^<]*)<\/gx:coord>/gi)].map((x) => x[1].trim().split(/\s+/).map(parseFloat));
        const q = cs.map((c, i) => ({ lat: c[1], lon: c[0], alt: c.length > 2 ? c[2] : NaN, time: whens[i] }));
        if (q.length >= 2) { r.lines.push(q.map((x) => [x.lat, x.lon])); r.tracks.push({ name, pts: q }); }
      }
      if (!/<(?:\w+:)?LineString/i.test(body) && !/<gx:Track/i.test(body)) {
        const pt = first(body, 'Point');
        if (pt) { const c = first(pt, 'coordinates'); if (c) { const q = coords(c); if (q.length) r.points.push({ lat: q[0][0], lon: q[0][1], name, alt: q[0][2] }); } }
      }
    }
    // GPX
    const trkRe = /<trk\b[^>]*>([\s\S]*?)<\/trk>/gi;
    while ((m = trkRe.exec(text))) {
      const nm = first(m[1], 'name');
      const q = [...m[1].matchAll(/<trkpt\b([^>]*?)(?:\/>|>([\s\S]*?)<\/trkpt>)/gi)].map((x) => gpxPt(x[1], x[2] || ''));
      if (q.length >= 2) { r.lines.push(q.map((x) => [x.lat, x.lon])); r.tracks.push({ name: nm ? strip(nm) : '', pts: q }); }
    }
    const rteRe = /<rte\b[^>]*>([\s\S]*?)<\/rte>/gi;
    while ((m = rteRe.exec(text))) {
      const q = [...m[1].matchAll(/<rtept\b([^>]*?)(?:\/>|>([\s\S]*?)<\/rtept>)/gi)].map((x) => gpxPt(x[1], x[2] || ''));
      if (q.length >= 2) { r.lines.push(q.map((x) => [x.lat, x.lon])); r.tracks.push({ name: '', pts: q }); }
    }
    const wptRe = /<wpt\b([^>]*?)(?:\/>|>([\s\S]*?)<\/wpt>)/gi;
    while ((m = wptRe.exec(text))) {
      const p = gpxPt(m[1], m[2] || '');
      const nm = first(m[2] || '', 'name');
      r.points.push({ lat: p.lat, lon: p.lon, name: nm ? strip(nm) : '', alt: p.alt });
    }
    function gpxPt(attrs, body) {
      const la = /lat\s*=\s*["']([^"']+)/i.exec(attrs), lo = /lon\s*=\s*["']([^"']+)/i.exec(attrs);
      const el = /<ele>([^<]*)<\/ele>/i.exec(body), tm = /<time>([^<]*)<\/time>/i.exec(body);
      return { lat: la ? parseFloat(la[1]) : NaN, lon: lo ? parseFloat(lo[1]) : NaN, alt: el ? parseFloat(el[1]) : NaN, time: tm ? Date.parse(tm[1].trim()) : NaN };
    }
    r.lines = r.lines.map((ln) => ln.filter((q) => Number.isFinite(q[0]) && Number.isFinite(q[1]))).filter((ln) => ln.length >= 2);
    r.points = r.points.filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lon));
    return r;
  }

  /** A new survey built from an imported track (e.g. a GPX from another device). */
  function surveyFromTrack(track, name) {
    const base = Date.now();
    const pts = track.pts.filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lon)).map((p, i) => ({
      lat: p.lat, lon: p.lon, alt: Number.isFinite(p.alt) ? p.alt : 0, acc: 0,
      time: Number.isFinite(p.time) ? p.time : base + i * 1000, ch: 0,
    }));
    for (let i = 1; i < pts.length; i++) if (pts[i].time <= pts[i - 1].time) pts[i].time = pts[i - 1].time + 1;
    recomputeCh(pts);
    const id = 's' + base;
    return {
      id, meta: { name, startCh: '0', created: String(base) }, name, startCh: 0, created: base, points: pts, original: null,
      marks: [], segments: [], videosText: null, ref: null, changed: true,
    };
  }

  // ---------------- ZIP (read + write) ----------------
  const CRC_TABLE = (() => {
    const tb = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
      tb[n] = c >>> 0;
    }
    return tb;
  })();
  function crc32(buf) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }
  const enc = new TextEncoder();
  const dec = new TextDecoder('utf-8');
  function utf8(s) { return enc.encode(s); }
  function fromUtf8(b) { return dec.decode(b).replace(/^﻿/, ''); }

  async function streamBytes(data, stream) {
    const out = new Response(new Blob([data]).stream().pipeThrough(stream));
    return new Uint8Array(await out.arrayBuffer());
  }
  const inflateRaw = (data) => streamBytes(data, new DecompressionStream('deflate-raw'));
  const deflateRaw = (data) => streamBytes(data, new CompressionStream('deflate-raw'));

  /** Returns { name: Uint8Array } using the central directory (works with data descriptors). */
  async function unzip(bytes) {
    const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    let eocd = -1;
    for (let i = b.length - 22; i >= Math.max(0, b.length - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error(t('এটা ZIP ফাইল নয়', 'Not a ZIP file'));
    const count = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const out = {};
    for (let n = 0; n < count; n++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const method = dv.getUint16(p + 10, true);
      const csize = dv.getUint32(p + 20, true);
      const nlen = dv.getUint16(p + 28, true), xlen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
      const lho = dv.getUint32(p + 42, true);
      const name = dec.decode(b.subarray(p + 46, p + 46 + nlen));
      p += 46 + nlen + xlen + clen;
      if (name.endsWith('/')) continue;
      const lnl = dv.getUint16(lho + 26, true), lxl = dv.getUint16(lho + 28, true);
      const start = lho + 30 + lnl + lxl;
      const raw = b.subarray(start, start + csize);
      if (method === 0) out[name] = raw.slice();
      else if (method === 8) out[name] = await inflateRaw(raw);
    }
    return out;
  }

  /** files: { name: string | Uint8Array } → zip bytes (deflated, sizes in local headers). */
  async function zip(files) {
    const parts = [], central = [];
    let offset = 0;
    const now = new Date();
    const dtime = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
    const ddate = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
    for (const name of Object.keys(files)) {
      const data = typeof files[name] === 'string' ? utf8(files[name]) : files[name];
      const nameB = utf8(name);
      const crc = crc32(data);
      let comp = await deflateRaw(data), method = 8;
      if (comp.length >= data.length) { comp = data; method = 0; }
      const lh = new Uint8Array(30 + nameB.length);
      const lv = new DataView(lh.buffer);
      lv.setUint32(0, 0x04034b50, true); lv.setUint16(4, 20, true); lv.setUint16(6, 0x0800, true); lv.setUint16(8, method, true);
      lv.setUint16(10, dtime, true); lv.setUint16(12, ddate, true); lv.setUint32(14, crc, true);
      lv.setUint32(18, comp.length, true); lv.setUint32(22, data.length, true); lv.setUint16(26, nameB.length, true); lv.setUint16(28, 0, true);
      lh.set(nameB, 30);
      const ch = new Uint8Array(46 + nameB.length);
      const cv = new DataView(ch.buffer);
      cv.setUint32(0, 0x02014b50, true); cv.setUint16(4, 20, true); cv.setUint16(6, 20, true); cv.setUint16(8, 0x0800, true);
      cv.setUint16(10, method, true); cv.setUint16(12, dtime, true); cv.setUint16(14, ddate, true); cv.setUint32(16, crc, true);
      cv.setUint32(20, comp.length, true); cv.setUint32(24, data.length, true); cv.setUint16(28, nameB.length, true);
      cv.setUint32(42, offset, true);
      ch.set(nameB, 46);
      parts.push(lh, comp);
      central.push(ch);
      offset += lh.length + comp.length;
    }
    const csize = central.reduce((a, c) => a + c.length, 0);
    const end = new Uint8Array(22);
    const ev = new DataView(end.buffer);
    ev.setUint32(0, 0x06054b50, true); ev.setUint16(8, central.length, true); ev.setUint16(10, central.length, true);
    ev.setUint32(12, csize, true); ev.setUint32(16, offset, true);
    const all = [...parts, ...central, end];
    const total = all.reduce((a, c) => a + c.length, 0);
    const out = new Uint8Array(total);
    let o = 0;
    for (const c of all) { out.set(c, o); o += c.length; }
    return out;
  }

  // ---------------- backup (phone format) ----------------
  /** Reads a phone backup zip → { surveys: [...], tags: [...] } */
  async function readBackup(bytes) {
    const entries = await unzip(bytes);
    const groups = {};
    let tags = [];
    for (const name of Object.keys(entries)) {
      if (name === 'tags.txt') { tags = fromUtf8(entries[name]).split(/\r?\n/).map((x) => x.trim()).filter((x) => x); continue; }
      const parts = name.split('/');
      if (parts.length !== 3 || parts[0] !== 'surveys' || !/^[A-Za-z0-9_]+$/.test(parts[1])) continue;
      (groups[parts[1]] = groups[parts[1]] || {})[parts[2]] = fromUtf8(entries[name]);
    }
    const surveys = Object.keys(groups).map((id) => surveyFromFiles(id, groups[id])).sort((a, b) => a.created - b.created);
    return { surveys, tags };
  }

  async function writeBackup(surveys, tags) {
    const files = {};
    for (const s of surveys) {
      const f = surveyToFiles(s);
      for (const n of Object.keys(f)) files['surveys/' + s.id + '/' + n] = f[n];
    }
    files['tags.txt'] = (tags || []).map((x) => x + '\n').join('');
    return zip(files);
  }

  const api = {
    DEVELOPER, t, setLang, getLang, distance, bearing, utm, fmtCh, parseCh, polygonArea, pathLength, localTime, isoTime, stamp,
    parsePoints, writePoints, parseMarks, writeMarks, parseSegments, writeSegments, parseRef, writeRef, parseVideos, videoPath, parseProps, writeProps,
    surveyFromFiles, surveyToFiles, length, recomputeCh, positionAt, project, chainageForMark, afterLineChanged, pointAtCh,
    smoothTrack, cleanTrack, simplify, rebuild, findCurves, smoothAlt, profileStats, photosOf, audiosOf, attachmentLabel,
    kml, gpx, csv, dxf, chainageTable, xlsxSheets, xlsxFiles, parseGeoXml, surveyFromTrack,
    crc32, utf8, fromUtf8, unzip, zip, readBackup, writeBackup, round,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Core = api;
})(typeof window !== 'undefined' ? window : globalThis);
