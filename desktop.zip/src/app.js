/* Road Survey Desktop — user interface. Developed by Akshoy Bhowmick */
(function () {
  'use strict';
  const C = window.Core;
  const t = C.t;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : v; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } },
  };

  // ------------------------------------------------------------------ state
  const S = {
    surveys: [],
    tags: [],
    filePath: null,
    fileName: null,
    cur: -1,
    dirty: false,
    mode: 'view',
    tab: 'info',
    undo: [],          // snapshots of the current survey (for Ctrl+Z)
    grip: null,        // { verts, undo, selected, markers, line }
    measure: [],
    profileOn: false,
  };
  const cur = () => (S.cur >= 0 ? S.surveys[S.cur] : null);

  // ------------------------------------------------------------------ language
  C.setLang(store.get('lang', 'bn'));
  function applyLang() {
    const en = C.getLang() === 'en';
    document.documentElement.lang = en ? 'en' : 'bn';
    document.querySelectorAll('[data-bn]').forEach((el) => { el.textContent = en ? el.dataset.en : el.dataset.bn; });
    document.querySelectorAll('[data-tip-bn]').forEach((el) => { el.title = en ? el.dataset.tipEn : el.dataset.tipBn; });
    $('btnLang').textContent = en ? 'বাংলা' : 'English';
  }

  // ------------------------------------------------------------------ small UI helpers
  let toastTimer = 0;
  function toast(msg, ms) {
    const el = $('toast');
    el.textContent = msg;
    el.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.add('hidden'), ms || 3200);
  }

  /** modal({title, html, buttons:[{label, value, cls}], onOpen}) → Promise(value or null) */
  function modal(o) {
    return new Promise((resolve) => {
      const back = $('modalBack'), m = $('modal');
      m.innerHTML = '<h2>' + esc(o.title || '') + '</h2><div class="mb">' + (o.html || '') + '</div><div class="mf"></div>';
      const mf = m.querySelector('.mf');
      const close = (v) => {
        back.classList.add('hidden');
        document.removeEventListener('keydown', onKey, true);
        resolve(v);
      };
      (o.buttons || [{ label: t('ঠিক আছে', 'OK'), value: true, cls: 'primary' }]).forEach((b) => {
        const el = document.createElement('button');
        el.textContent = b.label;
        el.className = b.cls || 'btn';
        el.onclick = () => {
          if (b.value === null || !o.validate || o.validate(b.value, m) !== false) close(b.value === undefined ? true : b.value);
        };
        mf.appendChild(el);
      });
      function onKey(e) {
        if (e.key === 'Escape') { e.stopPropagation(); close(null); }
        if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
          const p = mf.querySelector('.primary');
          if (p) { e.preventDefault(); e.stopPropagation(); p.click(); }
        }
      }
      document.addEventListener('keydown', onKey, true);
      back.classList.remove('hidden');
      if (o.onOpen) o.onOpen(m);
      const first = m.querySelector('input,select,textarea');
      if (first) { first.focus(); if (first.select) first.select(); }
    });
  }
  const alertBox = (title, text) => modal({ title, html: '<p>' + esc(text).replace(/\n/g, '<br>') + '</p>' });
  const confirmBox = (title, text, yes, danger) => modal({
    title, html: '<p>' + esc(text).replace(/\n/g, '<br>') + '</p>',
    buttons: [{ label: t('বাতিল', 'Cancel'), value: null }, { label: yes || t('হ্যাঁ', 'Yes'), value: true, cls: danger ? 'danger' : 'primary' }],
  });

  function setDirty(v) {
    S.dirty = v;
    updateHeader();
  }
  function updateHeader() {
    $('fileLabel').textContent = (S.fileName || '') + (S.dirty ? ' • ' + t('সেভ হয়নি', 'not saved') : '');
    document.title = 'Road Survey Desktop' + (S.fileName ? ' — ' + S.fileName : '') + (S.dirty ? ' *' : '');
    $('btnSave').disabled = !S.surveys.length;
    $('btnUndo').disabled = !(S.grip ? S.grip.undo.length : S.undo.length);
  }

  // ------------------------------------------------------------------ map
  const map = L.map('map', { zoomControl: true, preferCanvas: false, doubleClickZoom: true, boxZoom: true }).setView([23.0, 88.0], 7);
  const street = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '© OpenStreetMap contributors',
  });
  const sat = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19, maxNativeZoom: 19, attribution: 'Imagery © Esri',
  });
  const labels = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19, attribution: '',
  });
  const satLabels = L.layerGroup([sat, labels]);
  const baseName = store.get('base', 'street');
  ({ street, sat, satLabels }[baseName] || street).addTo(map);

  const L_track = L.layerGroup().addTo(map);
  const L_orig = L.layerGroup();
  const L_ch = L.layerGroup().addTo(map);
  const L_marks = L.layerGroup().addTo(map);
  const L_curves = L.layerGroup().addTo(map);
  const L_segs = L.layerGroup().addTo(map);
  const L_design = L.layerGroup().addTo(map);
  const L_tools = L.layerGroup().addTo(map);  // measure, hover
  const L_grip = L.layerGroup().addTo(map);
  let layerCtl = null;
  function buildLayerControl() {
    if (layerCtl) map.removeControl(layerCtl);
    const bases = {};
    bases[t('রাস্তার ম্যাপ', 'Street map')] = street;
    bases[t('স্যাটেলাইট', 'Satellite')] = sat;
    bases[t('স্যাটেলাইট + নাম', 'Satellite + labels')] = satLabels;
    const ov = {};
    ov[t('চেইনেজ', 'Chainage')] = L_ch;
    ov[t('পয়েন্ট', 'Points')] = L_marks;
    ov[t('বাঁক', 'Curves')] = L_curves;
    ov[t('রাস্তার অংশ', 'Road segments')] = L_segs;
    ov[t('ডিজাইন', 'Design')] = L_design;
    ov[t('আসল GPS লাইন (এডিটের আগে)', 'Original GPS line (before edit)')] = L_orig;
    layerCtl = L.control.layers(bases, ov, { position: 'topright', collapsed: true }).addTo(map);
  }
  map.on('baselayerchange', (e) => {
    store.set('base', e.layer === sat ? 'sat' : e.layer === satLabels ? 'satLabels' : 'street');
  });
  L.control.scale({ imperial: false }).addTo(map);

  // ------------------------------------------------------------------ drawing a survey
  let trackLine = null;
  function drawSurvey(fit) {
    L_track.clearLayers(); L_orig.clearLayers(); L_marks.clearLayers(); L_curves.clearLayers(); L_segs.clearLayers(); L_design.clearLayers();
    trackLine = null;
    const s = cur();
    if (!s) { drawChainage(); return; }
    const ll = s.points.map((p) => [p.lat, p.lon]);
    if (s.original) L.polyline(s.original.map((p) => [p.lat, p.lon]), { color: '#546e7a', weight: 2, dashArray: '5 6', opacity: 0.9 }).addTo(L_orig);
    if (ll.length) {
      trackLine = L.polyline(ll, { color: '#e53935', weight: 5, opacity: S.grip ? 0.25 : 0.9 }).addTo(L_track);
      L.circleMarker(ll[0], { radius: 7, color: '#fff', weight: 2, fillColor: '#2e7d32', fillOpacity: 1 })
        .bindTooltip(t('শুরু ', 'Start ') + C.fmtCh(s.startCh)).addTo(L_track);
      L.circleMarker(ll[ll.length - 1], { radius: 7, color: '#fff', weight: 2, fillColor: '#b71c1c', fillOpacity: 1 })
        .bindTooltip(t('শেষ ', 'End ') + C.fmtCh(s.startCh + C.length(s.points))).addTo(L_track);
    }
    drawMarks();
    C.findCurves(s.points).forEach((c, i) => {
      L.marker([c.midLat, c.midLon], { icon: L.divIcon({ className: '', html: '<div class="curve-icon"></div>', iconSize: [14, 14], iconAnchor: [7, 7] }), keyboard: false })
        .bindTooltip('C' + (i + 1) + ' • ' + (c.right ? t('ডানে', 'Right') : t('বাঁয়ে', 'Left')) + ' ' + c.deflection.toFixed(0) + '° • R≈' + c.radius.toFixed(0)
          + ' m<br>' + C.fmtCh(s.startCh + c.startCh) + ' – ' + C.fmtCh(s.startCh + c.endCh))
        .addTo(L_curves);
    });
    s.segments.forEach((g) => {
      const p = C.pointAtCh(s.points, g.ch);
      if (!p) return;
      L.marker([p[0], p[1]], { icon: L.divIcon({ className: '', html: '<div class="seg-icon"></div>', iconSize: [12, 12], iconAnchor: [6, 6] }), keyboard: false })
        .bindTooltip(C.fmtCh(s.startCh + g.ch) + ' • ' + esc(g.surface) + ' / ' + esc(g.condition) + (Number.isFinite(g.width) ? ' / ' + g.width.toFixed(1) + ' m' : ''))
        .addTo(L_segs);
    });
    if (s.ref) {
      s.ref.lines.forEach((ln) => L.polyline(ln, { color: '#8e24aa', weight: 3, dashArray: '8 6', opacity: 0.9 }).bindTooltip(esc(s.ref.name || t('ডিজাইন', 'Design'))).addTo(L_design));
      s.ref.points.forEach((p) => L.circleMarker([p.lat, p.lon], { radius: 4, color: '#8e24aa', fillOpacity: 1 }).bindTooltip(esc(p.name || '')).addTo(L_design));
    }
    drawChainage();
    if (fit) fitSurvey();
  }

  function fitSurvey() {
    const s = cur();
    if (!s) return;
    const all = s.points.map((p) => [p.lat, p.lon]).concat(s.marks.map((m) => [m.lat, m.lon]));
    if (all.length === 1) map.setView(all[0], 17);
    else if (all.length) map.fitBounds(L.latLngBounds(all), { padding: [40, 40] });
  }

  function markIcon(m, i) {
    const hasPhoto = C.photosOf(m.photo).length > 0;
    return L.divIcon({
      className: '',
      html: '<div class="pin' + (S.mode === 'marks' ? ' move' : hasPhoto ? ' photo' : '') + '"><span>' + (i + 1) + '</span></div>',
      iconSize: [22, 22], iconAnchor: [11, 26], popupAnchor: [0, -24],
    });
  }

  function markPopup(i) {
    const s = cur(), m = s.marks[i];
    const ph = C.photosOf(m.photo), au = C.audiosOf(m.photo);
    const u = C.utm(m.lat, m.lon);
    let h = '<b>' + (i + 1) + '. ' + esc(m.name) + '</b><br>' + t('চেইনেজ ', 'Chainage ') + '<b>' + C.fmtCh(s.startCh + m.ch) + '</b>'
      + '<br>' + m.lat.toFixed(7) + ', ' + m.lon.toFixed(7)
      + '<br>UTM ' + u.label + ' ' + u.easting.toFixed(2) + ' E, ' + u.northing.toFixed(2) + ' N'
      + '<br>' + t('উচ্চতা ', 'Elevation ') + m.alt.toFixed(1) + ' m • ' + C.localTime(m.time);
    if (ph.length) h += '<br>📷 ' + ph.length + t('টা ছবি (ফোনে আছে)', ' photo(s) (on the phone)');
    if (au.length) h += '<br>🎙 ' + au.length + t('টা ভয়েস নোট (ফোনে আছে)', ' voice note(s) (on the phone)');
    h += '<div class="popup-actions"><button class="small" data-act="rename" data-i="' + i + '">✏ ' + t('নাম', 'Name')
      + '</button><button class="small danger" data-act="delmark" data-i="' + i + '">🗑 ' + t('মুছুন', 'Delete') + '</button></div>';
    return h;
  }

  let markMarkers = [];
  function drawMarks() {
    L_marks.clearLayers();
    markMarkers = [];
    const s = cur();
    if (!s) return;
    s.marks.forEach((m, i) => {
      const mk = L.marker([m.lat, m.lon], { icon: markIcon(m, i), draggable: S.mode === 'marks', riseOnHover: true, autoPan: true });
      mk.bindPopup(() => markPopup(i), { minWidth: 230 });
      mk.bindTooltip((i + 1) + '. ' + esc(m.name) + ' • ' + C.fmtCh(s.startCh + m.ch), { direction: 'top', offset: [0, -24] });
      mk.on('dragstart', () => pushUndo());
      mk.on('dragend', () => {
        const ll = mk.getLatLng();
        m.lat = ll.lat; m.lon = ll.lng;
        m.ch = C.chainageForMark(s.points, m);
        changed(false);
        toast(t('পয়েন্ট সরানো হলো • চেইনেজ ', 'Point moved • chainage ') + C.fmtCh(s.startCh + m.ch));
      });
      mk.addTo(L_marks);
      markMarkers.push(mk);
    });
  }

  // chainage labels: every km always, finer steps when zoomed in
  function drawChainage() {
    L_ch.clearLayers();
    const s = cur();
    if (!s || s.points.length < 2) return;
    const z = map.getZoom();
    const step = z >= 18 ? 20 : z >= 17 ? 50 : z >= 16 ? 100 : z >= 14 ? 500 : 1000;
    const bounds = map.getBounds().pad(0.2);
    const pts = s.points, startCh = s.startCh;
    let next = Math.ceil(startCh / step) * step;
    let count = 0;
    for (let i = 1; i < pts.length && count < 400; i++) {
      const a = pts[i - 1], b = pts[i], ca = startCh + a.ch, cb = startCh + b.ch;
      while (next <= cb) {
        if (next >= ca) {
          const f = cb - ca < 1e-6 ? 0 : (next - ca) / (cb - ca);
          const ll = [a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f];
          if (bounds.contains(ll)) {
            const km = Math.round(next) % 1000 === 0;
            L.marker(ll, {
              icon: L.divIcon({ className: '', html: '<span class="ch-label' + (km ? ' km' : '') + '">' + C.fmtCh(next) + '</span>', iconSize: null, iconAnchor: [-6, 8] }),
              interactive: false, keyboard: false,
            }).addTo(L_ch);
            L.circleMarker(ll, { radius: km ? 4 : 2.5, color: km ? '#0d47a1' : '#37474f', weight: 1, fillOpacity: 1, interactive: false }).addTo(L_ch);
            count++;
          }
        }
        next += step;
      }
    }
  }
  map.on('zoomend moveend', () => drawChainage());

  // ------------------------------------------------------------------ hover: position, UTM, chainage, offset
  let hoverMarker = null;
  let hoverPending = null;
  map.on('mousemove', (e) => {
    hoverPending = e.latlng;
    requestAnimationFrame(() => {
      if (!hoverPending) return;
      const ll = hoverPending;
      hoverPending = null;
      $('stPos').textContent = ll.lat.toFixed(7) + ', ' + ll.lng.toFixed(7);
      const u = C.utm(ll.lat, ll.lng);
      $('stUtm').textContent = 'UTM ' + u.label + ' ' + u.easting.toFixed(1) + ' E ' + u.northing.toFixed(1) + ' N';
      const s = cur();
      if (s && s.points.length > 1) {
        const pr = C.project(s.points, ll.lat, ll.lng);
        const a = s.points[pr.index], b = s.points[pr.index + 1];
        const k = Math.cos(ll.lat * Math.PI / 180);
        const cross = (b.lon - a.lon) * k * (ll.lat - a.lat) - (b.lat - a.lat) * (ll.lng - a.lon) * k;
        const side = pr.dist < 0.05 ? '' : cross > 0 ? t(' বাঁয়ে', ' left') : t(' ডানে', ' right');
        $('stCh').textContent = t('চেইনেজ ', 'Chainage ') + C.fmtCh(s.startCh + pr.ch) + ' • ' + t('লাইন থেকে ', 'off line ') + pr.dist.toFixed(1) + ' m' + side;
      } else $('stCh').textContent = '';
    });
  });

  // ------------------------------------------------------------------ survey list + panel
  function renderList() {
    const el = $('surveyList');
    el.innerHTML = '';
    S.surveys.forEach((s, i) => {
      const d = document.createElement('div');
      d.className = 'sv' + (i === S.cur ? ' on' : '');
      const len = C.length(s.points);
      d.innerHTML = '<div class="t">' + esc(s.name) + (s.original ? '<span class="badge">' + t('এডিটেড', 'edited') + '</span>' : '')
        + (s.changed ? '<span class="badge blue">' + t('পরিবর্তিত', 'changed') + '</span>' : '') + '</div>'
        + '<div class="s">' + C.fmtCh(s.startCh) + ' → ' + C.fmtCh(s.startCh + len) + ' • ' + (len / 1000).toFixed(2) + ' km • '
        + s.marks.length + t(' পয়েন্ট • ', ' points • ') + new Date(s.created).toLocaleDateString() + '</div>';
      d.onclick = () => selectSurvey(i, true);
      el.appendChild(d);
    });
    $('welcome').classList.toggle('hidden', S.surveys.length > 0);
    $('surveyPanel').classList.toggle('hidden', !cur());
  }

  function selectSurvey(i, fit) {
    if (S.grip) endGrip(false);
    if (S.mode === 'grip') setModeNow('view');
    S.cur = i;
    S.undo = [];
    S.measure = [];
    L_tools.clearLayers();
    const s = cur();
    if (s) {
      $('svName').value = s.name;
      $('svStart').value = C.fmtCh(s.startCh);
    }
    renderList();
    drawSurvey(fit);
    renderTab();
    drawProfile();
    updateHeader();
  }

  function renderTab() {
    document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === S.tab));
    const s = cur(), el = $('tabBody');
    if (!s) { el.innerHTML = ''; return; }
    $('svOriginal').disabled = !s.original;
    if (S.tab === 'info') el.innerHTML = infoHtml(s);
    else if (S.tab === 'marks') el.innerHTML = marksHtml(s);
    else if (S.tab === 'curves') el.innerHTML = curvesHtml(s);
    else el.innerHTML = segsHtml(s);
  }

  function infoHtml(s) {
    const len = C.length(s.points), st = C.profileStats(s.points);
    const dur = s.points.length > 1 ? (s.points[s.points.length - 1].time - s.points[0].time) / 60000 : 0;
    const rows = [
      [t('মোট দৈর্ঘ্য', 'Total length'), len.toFixed(1) + ' m (' + (len / 1000).toFixed(3) + ' km)'],
      [t('শুরু → শেষ চেইনেজ', 'Start → end chainage'), C.fmtCh(s.startCh) + ' → ' + C.fmtCh(s.startCh + len)],
      [t('GPS পয়েন্ট', 'GPS points'), s.points.length],
      [t('চিহ্নিত পয়েন্ট', 'Marked points'), s.marks.length],
      [t('বাঁক', 'Curves'), C.findCurves(s.points).length],
      [t('রাস্তার অংশ', 'Road segments'), s.segments.length],
      [t('রেকর্ডের সময়', 'Recording time'), s.points.length ? C.localTime(s.points[0].time) + ' (' + dur.toFixed(0) + t(' মিনিট)', ' min)') : '—'],
      [t('লাইন হাতে এডিট', 'Line hand-edited'), s.original ? t('হ্যাঁ (আসল লাইন রাখা আছে)', 'Yes (original kept)') : t('না', 'No')],
      [t('ডিজাইন', 'Design'), s.ref ? esc(s.ref.name || t('আছে', 'yes')) : '—'],
      [t('ভিডিও', 'Videos'), s.videosText ? s.videosText.split('\n').filter((x) => x).length + t('টা (ফোনে আছে)', ' (on the phone)') : '—'],
    ];
    if (st.valid) {
      rows.push([t('উচ্চতা (কম–বেশি)', 'Elevation (min–max)'), st.minAlt.toFixed(1) + ' – ' + st.maxAlt.toFixed(1) + ' m']);
      rows.push([t('মোট ওঠা / নামা', 'Total rise / fall'), st.rise.toFixed(0) + ' / ' + st.fall.toFixed(0) + ' m']);
      rows.push([t('গড় / সর্বোচ্চ ঢাল', 'Average / max grade'), st.avgGrade.toFixed(2) + ' % / ' + st.maxGrade.toFixed(1) + ' %']);
    }
    return '<table class="grid kv">' + rows.map((r) => '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>').join('') + '</table>'
      + '<p class="muted small">' + t('দ্রষ্টব্য: ফোনের GPS উচ্চতা আনুমানিক (±৫–১০ মি)।', 'Note: phone GPS height is approximate (±5–10 m).') + '</p>';
  }

  function marksHtml(s) {
    if (!s.marks.length) return '<p class="muted">' + t('কোনো পয়েন্ট নেই। "📍 পয়েন্ট যোগ/সরান" দিয়ে ম্যাপে ক্লিক করে যোগ করুন।', 'No points. Use "📍 Add/move points" and click the map.') + '</p>';
    let h = '<div class="row"><button class="small" data-act="sortmarks">↕ ' + t('চেইনেজ অনুযায়ী সাজান', 'Sort by chainage') + '</button></div>'
      + '<table class="grid"><tr><th>#</th><th>' + t('নাম', 'Name') + '</th><th>' + t('চেইনেজ', 'Chainage') + '</th><th></th></tr>';
    s.marks.forEach((m, i) => {
      const n = C.photosOf(m.photo).length;
      h += '<tr class="click" data-act="gomark" data-i="' + i + '"><td>' + (i + 1) + '</td><td>' + esc(m.name) + (n ? ' 📷' : '') + '</td><td class="num">'
        + C.fmtCh(s.startCh + m.ch) + '</td><td class="num"><button class="icon-btn" title="' + t('নাম বদলান', 'Rename') + '" data-act="rename" data-i="' + i
        + '">✏</button><button class="icon-btn" title="' + t('মুছুন', 'Delete') + '" data-act="delmark" data-i="' + i + '">🗑</button></td></tr>';
    });
    return h + '</table>';
  }

  function curvesHtml(s) {
    const cs = C.findCurves(s.points);
    if (!cs.length) return '<p class="muted">' + t('উল্লেখযোগ্য কোনো বাঁক পাওয়া যায়নি।', 'No significant curves found.') + '</p>';
    let h = '<table class="grid"><tr><th>#</th><th>' + t('চেইনেজ', 'Chainage') + '</th><th>' + t('দিক', 'Dir') + '</th><th>' + t('কোণ', 'Angle')
      + '</th><th>R (m)</th><th>L (m)</th></tr>';
    cs.forEach((c, i) => {
      h += '<tr class="click" data-act="gocurve" data-i="' + i + '"><td>C' + (i + 1) + '</td><td>' + C.fmtCh(s.startCh + c.startCh) + '–' + C.fmtCh(s.startCh + c.endCh)
        + '</td><td>' + (c.right ? t('ডানে', 'R') : t('বাঁয়ে', 'L')) + '</td><td class="num">' + c.deflection.toFixed(0) + '°</td><td class="num">'
        + c.radius.toFixed(0) + '</td><td class="num">' + c.length.toFixed(0) + '</td></tr>';
    });
    return h + '</table><p class="muted small">' + t('ব্যাসার্ধ GPS থেকে আনুমানিক।', 'Radius is approximate (from GPS).') + '</p>';
  }

  function segsHtml(s) {
    if (!s.segments.length) return '<p class="muted">' + t('এই সার্ভেতে রাস্তার অংশ (ধরন/অবস্থা) রেকর্ড করা হয়নি।', 'No road segments (surface/condition) recorded in this survey.') + '</p>';
    const total = C.length(s.points);
    let h = '<table class="grid"><tr><th>' + t('থেকে–পর্যন্ত', 'From–to') + '</th><th>' + t('ধরন', 'Surface') + '</th><th>' + t('অবস্থা', 'Condition')
      + '</th><th>' + t('চওড়া', 'Width') + '</th><th></th></tr>';
    s.segments.forEach((g, i) => {
      const to = i + 1 < s.segments.length ? s.segments[i + 1].ch : total;
      h += '<tr class="click" data-act="goseg" data-i="' + i + '"><td>' + C.fmtCh(s.startCh + g.ch) + '–' + C.fmtCh(s.startCh + to) + '</td><td>' + esc(g.surface)
        + '</td><td>' + esc(g.condition) + '</td><td class="num">' + (Number.isFinite(g.width) ? g.width.toFixed(1) : '') + '</td><td class="num">'
        + '<button class="icon-btn" data-act="editseg" data-i="' + i + '">✏</button><button class="icon-btn" data-act="delseg" data-i="' + i + '">🗑</button></td></tr>';
    });
    return h + '</table>';
  }

  // clicks inside the side panel and popups
  document.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const s = cur();
    if (!s) return;
    const i = +b.dataset.i;
    const act = b.dataset.act;
    if (b.tagName === 'BUTTON') e.stopPropagation();
    if (act === 'gomark') {
      const m = s.marks[i];
      map.setView([m.lat, m.lon], Math.max(map.getZoom(), 18));
      if (markMarkers[i]) markMarkers[i].openPopup();
    } else if (act === 'gocurve') {
      const c = C.findCurves(s.points)[i];
      if (c) map.setView([c.midLat, c.midLon], Math.max(map.getZoom(), 17));
    } else if (act === 'goseg') {
      const p = C.pointAtCh(s.points, s.segments[i].ch);
      if (p) map.setView([p[0], p[1]], Math.max(map.getZoom(), 17));
    } else if (act === 'rename') {
      map.closePopup();
      const name = await askName(t('পয়েন্টের নাম', 'Point name'), s.marks[i].name);
      if (name == null) return;
      pushUndo();
      s.marks[i].name = name;
      changed(false);
    } else if (act === 'delmark') {
      map.closePopup();
      const ok = await confirmBox(t('পয়েন্ট মুছবেন?', 'Delete point?'), (i + 1) + '. ' + s.marks[i].name, t('মুছুন', 'Delete'), true);
      if (!ok) return;
      pushUndo();
      s.marks.splice(i, 1);
      changed(false);
    } else if (act === 'sortmarks') {
      pushUndo();
      s.marks.sort((a, b2) => a.ch - b2.ch);
      changed(false);
    } else if (act === 'delseg') {
      const ok = await confirmBox(t('অংশ মুছবেন?', 'Delete segment?'), C.fmtCh(s.startCh + s.segments[i].ch) + ' ' + s.segments[i].surface, t('মুছুন', 'Delete'), true);
      if (!ok) return;
      pushUndo();
      s.segments.splice(i, 1);
      changed(false);
    } else if (act === 'editseg') {
      const g = s.segments[i];
      const r = await modal({
        title: t('রাস্তার অংশ', 'Road segment') + ' ' + C.fmtCh(s.startCh + g.ch),
        html: '<div class="row"><label>' + t('ধরন', 'Surface') + '</label><input id="sgS" type="text" value="' + esc(g.surface) + '"></div>'
          + '<div class="row"><label>' + t('অবস্থা', 'Condition') + '</label><input id="sgC" type="text" value="' + esc(g.condition) + '"></div>'
          + '<div class="row"><label>' + t('চওড়া (মি)', 'Width (m)') + '</label><input id="sgW" type="number" step="0.1" value="' + (Number.isFinite(g.width) ? g.width : '') + '"></div>',
        buttons: [{ label: t('বাতিল', 'Cancel'), value: null }, { label: t('সেভ', 'Save'), value: 'ok', cls: 'primary' }],
        validate: (v, m) => {
          if (v !== 'ok') return true;
          g._new = { surface: m.querySelector('#sgS').value, condition: m.querySelector('#sgC').value, width: m.querySelector('#sgW').value };
          return true;
        },
      });
      if (r !== 'ok') return;
      pushUndo();
      g.surface = g._new.surface.replace(/,/g, ' ').trim();
      g.condition = g._new.condition.trim();
      g.width = g._new.width === '' ? NaN : parseFloat(g._new.width);
      delete g._new;
      changed(false);
    }
  });

  async function askName(title, value) {
    const tags = S.tags.slice(0, 40);
    let result = null;
    const r = await modal({
      title,
      html: '<input id="nmIn" type="text" style="width:100%" value="' + esc(value || '') + '">'
        + (tags.length ? '<div class="muted small" style="margin-top:8px">' + t('ট্যাগ বেছে নিন:', 'Pick a tag:') + '</div><div class="chips">'
          + tags.map((x) => '<span class="chip">' + esc(x) + '</span>').join('') + '</div>' : ''),
      buttons: [{ label: t('বাতিল', 'Cancel'), value: null }, { label: t('ঠিক আছে', 'OK'), value: 'ok', cls: 'primary' }],
      onOpen: (m) => m.querySelectorAll('.chip').forEach((c) => { c.onclick = () => { m.querySelector('#nmIn').value = c.textContent; m.querySelector('#nmIn').focus(); }; }),
      validate: (v, m) => {
        if (v !== 'ok') return true;
        const x = m.querySelector('#nmIn').value.replace(/[\r\n]/g, ' ').trim();
        if (!x) { toast(t('নাম লিখুন', 'Enter a name')); return false; }
        result = x;
        return true;
      },
    });
    return r === 'ok' ? result : null;
  }

  // ------------------------------------------------------------------ change tracking + undo
  function snapshot(s) {
    return JSON.stringify({ name: s.name, startCh: s.startCh, points: s.points, original: s.original, marks: s.marks, segments: s.segments, ref: s.ref });
  }
  function pushUndo() {
    const s = cur();
    if (!s) return;
    S.undo.push(snapshot(s));
    if (S.undo.length > 40) S.undo.shift();
    updateHeader();
  }
  function restoreSnap(s, json) {
    const o = JSON.parse(json, (k, v) => (v === null && (k === 'width') ? NaN : v));
    Object.assign(s, o);
    s.segments.forEach((g) => { if (g.width == null) g.width = NaN; });
  }
  function undo() {
    if (S.grip) { gripUndo(); return; }
    const s = cur();
    if (!s || !S.undo.length) { toast(t('আনডু করার কিছু নেই', 'Nothing to undo')); return; }
    restoreSnap(s, S.undo.pop());
    $('svName').value = s.name;
    $('svStart').value = C.fmtCh(s.startCh);
    changed(false, true);
    toast(t('আনডু হলো', 'Undone'));
  }
  /** Call after any change to the current survey. */
  function changed(fit, keepUndo) {
    const s = cur();
    if (s) s.changed = true;
    setDirty(true);
    renderList();
    drawSurvey(fit);
    renderTab();
    drawProfile();
    updateHeader();
  }

  // ------------------------------------------------------------------ survey panel buttons
  $('svApply').onclick = () => {
    const s = cur();
    if (!s) return;
    const name = $('svName').value.replace(/[\r\n]/g, ' ').trim();
    const st = C.parseCh($('svStart').value);
    if (!name) { toast(t('নাম লিখুন', 'Enter a name')); return; }
    if (!Number.isFinite(st)) { toast(t('শুরুর চেইনেজ ঠিক নয় (যেমন 2+500 বা 2500)', 'Start chainage not valid (e.g. 2+500 or 2500)')); return; }
    pushUndo();
    s.name = name;
    s.startCh = st;
    $('svStart').value = C.fmtCh(st);
    changed(false);
    toast(t('সার্ভের তথ্য বদলানো হলো', 'Survey details updated'));
  };
  $('svName').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('svApply').click(); });
  $('svStart').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('svApply').click(); });

  $('svDelete').onclick = async () => {
    const s = cur();
    if (!s) return;
    const ok = await confirmBox(t('সার্ভে মুছবেন?', 'Delete survey?'),
      s.name + '\n\n' + t('শুধু এই ফাইল থেকে মুছবে। ফোনে রিস্টোর করলে ফোনের সার্ভে নিজে থেকে মুছবে না।', 'Removed from this file only. Restoring on the phone does not delete the phone\'s copy.'),
      t('মুছুন', 'Delete'), true);
    if (!ok) return;
    S.surveys.splice(S.cur, 1);
    setDirty(true);
    selectSurvey(S.surveys.length ? 0 : -1, true);
  };

  $('svOriginal').onclick = async () => {
    const s = cur();
    if (!s || !s.original) return;
    const ok = await confirmBox(t('আসল GPS লাইনে ফিরবেন?', 'Back to the original GPS line?'),
      t('হাতে করা সব লাইন-এডিট বাদ যাবে।', 'All hand edits of the line will be discarded.'), t('ফিরে যান', 'Restore'), true);
    if (!ok) return;
    pushUndo();
    s.points = s.original.map((p) => Object.assign({}, p));
    s.original = null;
    C.afterLineChanged(s);
    changed(false);
    toast(t('আসল GPS লাইন ফেরত আনা হলো', 'Original GPS line restored'));
  };

  $('svClean').onclick = async () => {
    const s = cur();
    if (!s || s.points.length < 5) return;
    let res = null;
    const r = await modal({
      title: t('জিগজ্যাগ ঠিক করুন', 'Fix zig-zag'),
      html: '<p>' + t('দাঁড়িয়ে থাকার সময়ের এলোমেলো দাগ আর জিগজ্যাগ কমাতে:', 'To reduce the scribbles while standing still and the zig-zag:') + '</p>'
        + '<div class="row"><label>' + t('কাছাকাছি পয়েন্ট বাদ', 'Drop points closer than') + '</label><select id="clMin"><option value="0">' + t('না', 'No')
        + '</option><option value="2">2 m</option><option value="3" selected>3 m</option><option value="5">5 m</option></select></div>'
        + '<div class="row"><label>' + t('মসৃণ করা', 'Smoothing') + '</label><select id="clSm"><option value="0">' + t('না', 'No')
        + '</option><option value="1">' + t('হালকা', 'Light') + '</option><option value="2" selected>' + t('মাঝারি', 'Medium') + '</option><option value="4">'
        + t('বেশি', 'Strong') + '</option></select></div>'
        + '<p class="muted small">' + t('আসল GPS লাইন রাখা থাকবে, পরে "⟲ আসল GPS লাইন" দিয়ে ফেরত আনা যাবে।', 'The original GPS line is kept; "⟲ Original GPS line" brings it back.') + '</p>',
      buttons: [{ label: t('বাতিল', 'Cancel'), value: null }, { label: t('ঠিক করুন', 'Apply'), value: 'ok', cls: 'primary' }],
      validate: (v, m) => { res = { min: +m.querySelector('#clMin').value, sm: +m.querySelector('#clSm').value }; return true; },
    });
    if (r !== 'ok') return;
    pushUndo();
    const before = s.points.length;
    if (!s.original) s.original = s.points.map((p) => Object.assign({}, p));
    let pts = s.points;
    if (res.min > 0) pts = C.cleanTrack(pts, res.min);
    if (res.sm > 0) pts = C.smoothTrack(pts, res.sm);
    s.points = pts;
    C.afterLineChanged(s);
    changed(false);
    toast(t('ঠিক করা হলো • পয়েন্ট ', 'Done • points ') + before + ' → ' + pts.length);
  };

  document.querySelectorAll('.tabs button').forEach((b) => { b.onclick = () => { S.tab = b.dataset.tab; renderTab(); }; });

  // ------------------------------------------------------------------ modes
  function setMode(m) {
    if (S.mode === 'grip' && m !== 'grip' && S.grip) {
      endGrip(false, true).then((ok) => { if (ok) setModeNow(m); });
      return;
    }
    setModeNow(m);
  }
  function setModeNow(m) {
    if ((m === 'grip' || m === 'marks') && !cur()) { toast(t('আগে একটা সার্ভে খুলুন', 'Open a survey first')); m = 'view'; }
    S.mode = m;
    document.querySelectorAll('#tools button').forEach((b) => b.classList.toggle('on', b.dataset.mode === m));
    map.getContainer().style.cursor = m === 'view' || m === 'grip' ? '' : 'crosshair';
    if (m === 'dist' || m === 'area') { map.doubleClickZoom.disable(); S.measure = []; drawMeasure(); } else { map.doubleClickZoom.enable(); $('measureBox').classList.add('hidden'); L_tools.clearLayers(); }
    if (m === 'grip') startGrip();
    drawMarks();
    modeHint();
  }
  function modeHint() {
    const m = S.mode;
    const hints = {
      marks: t('ম্যাপে ক্লিক করুন = নতুন পয়েন্ট • পয়েন্ট টেনে সরান • Esc = শেষ', 'Click the map = new point • drag a point to move it • Esc = done'),
      dist: t('ক্লিক করে দাগ দিন • ডাবল-ক্লিক / Esc = শেষ', 'Click to draw • double-click / Esc = finish'),
      area: t('ক্লিক করে সীমানা আঁকুন • ডাবল-ক্লিক / Esc = শেষ', 'Click around the boundary • double-click / Esc = finish'),
    };
    $('hint').textContent = hints[m] || '';
    $('hint').classList.toggle('hidden', !hints[m]);
  }
  document.querySelectorAll('#tools button').forEach((b) => { b.onclick = () => setMode(b.dataset.mode); });

  map.on('click', async (e) => {
    if (S.mode === 'marks') {
      const s = cur();
      if (!s) return;
      const name = await askName(t('নতুন পয়েন্টের নাম', 'New point name'), '');
      if (name == null) return;
      pushUndo();
      const pr = C.project(s.points, e.latlng.lat, e.latlng.lng);
      let alt = 0, time = Date.now();
      if (pr.index >= 0 && s.points.length > 1) {
        const a = s.points[pr.index], b = s.points[pr.index + 1];
        alt = a.alt + (b.alt - a.alt) * pr.t;
        time = Math.round(a.time + (b.time - a.time) * pr.t);
      } else if (s.points.length) { alt = s.points[0].alt; time = s.points[0].time; }
      const m = { lat: e.latlng.lat, lon: e.latlng.lng, alt, ch: 0, time, photo: '', name };
      m.ch = C.chainageForMark(s.points, m);
      s.marks.push(m);
      changed(false);
      toast(t('পয়েন্ট যোগ হলো • চেইনেজ ', 'Point added • chainage ') + C.fmtCh(s.startCh + m.ch));
    } else if (S.mode === 'dist' || S.mode === 'area') {
      if (S.measureDone) { S.measure = []; S.measureDone = false; }
      S.measure.push([e.latlng.lat, e.latlng.lng]);
      drawMeasure();
    }
  });
  map.on('dblclick', () => {
    if (S.mode === 'dist' || S.mode === 'area') { S.measureDone = true; drawMeasure(); }
  });

  function drawMeasure() {
    L_tools.clearLayers();
    const pts = S.measure, box = $('measureBox');
    box.classList.remove('hidden');
    const area = S.mode === 'area';
    if (pts.length) {
      if (area && pts.length >= 3) L.polygon(pts, { color: '#6a1b9a', weight: 2, fillOpacity: 0.2 }).addTo(L_tools);
      else L.polyline(pts, { color: '#6a1b9a', weight: 3, dashArray: '6 4' }).addTo(L_tools);
      pts.forEach((p) => L.circleMarker(p, { radius: 4, color: '#6a1b9a', fillColor: '#fff', fillOpacity: 1, weight: 2 }).addTo(L_tools));
    }
    let h;
    if (area) {
      const a = C.polygonArea(pts), per = pts.length >= 3 ? C.pathLength(pts.concat([pts[0]])) : C.pathLength(pts);
      h = '<div class="muted">' + t('ক্ষেত্রফল', 'Area') + '</div><b>' + a.toFixed(1) + ' m²</b><br>'
        + (a / 40.4686).toFixed(2) + t(' শতক (ডেসিমেল)', ' decimal (shatak)') + '<br>'
        + (a / 66.8902).toFixed(2) + t(' কাঠা', ' katha') + ' • ' + (a / 1337.8).toFixed(3) + t(' বিঘা', ' bigha') + '<br>'
        + (a / 4046.86).toFixed(4) + t(' একর', ' acre') + ' • ' + (a / 10000).toFixed(4) + t(' হেক্টর', ' ha') + '<br>'
        + '<span class="muted">' + t('পরিসীমা ', 'Perimeter ') + per.toFixed(1) + ' m</span>';
    } else {
      const d = C.pathLength(pts);
      h = '<div class="muted">' + t('দূরত্ব', 'Distance') + '</div><b>' + d.toFixed(2) + ' m</b>' + (d >= 1000 ? ' (' + (d / 1000).toFixed(3) + ' km)' : '');
      if (pts.length === 2) h += '<br><span class="muted">' + t('দিক ', 'Bearing ') + C.bearing(pts[0][0], pts[0][1], pts[1][0], pts[1][1]).toFixed(1) + '°</span>';
    }
    h += '<div class="popup-actions"><button class="small" id="msClear">' + t('মুছুন', 'Clear') + '</button><button class="small" id="msClose">'
      + t('বন্ধ', 'Close') + '</button></div><div class="muted small">' + t('(কাঠা/বিঘা: পশ্চিমবঙ্গের মাপ)', '(katha/bigha: West Bengal units)') + '</div>';
    box.innerHTML = h;
    $('msClear').onclick = () => { S.measure = []; S.measureDone = false; drawMeasure(); };
    $('msClose').onclick = () => setMode('view');
  }

  // ------------------------------------------------------------------ grip edit
  function gripIcon(i, n, sel) {
    const end = i === 0 || i === n - 1;
    return L.divIcon({ className: '', html: '<div class="grip-icon' + (end ? ' end' : '') + (sel ? ' sel' : '') + '" style="width:12px;height:12px"></div>', iconSize: [12, 12], iconAnchor: [6, 6] });
  }

  async function startGrip() {
    const s = cur();
    if (!s || s.points.length < 3) { toast(t('এডিট করার মতো লাইন নেই', 'No line to edit')); setModeNow('view'); return; }
    const max = +store.get('maxGrips', '200');
    const gap = Math.max(25, Math.min(200, C.length(s.points) / Math.max(10, max * 0.6)));
    S.grip = { verts: C.simplify(s.points, max, gap), undo: [], selected: -1, max };
    if (trackLine) trackLine.setStyle({ opacity: 0.25 });
    renderGrip();
    renderEditBar();
    updateHeader();
  }

  function renderGrip() {
    const g = S.grip;
    L_grip.clearLayers();
    if (!g) return;
    g.line = L.polyline(g.verts.map((v) => [v.lat, v.lon]), { color: '#ff6f00', weight: 4, bubblingMouseEvents: false }).addTo(L_grip);
    g.line.on('click', (e) => {
      L.DomEvent.stop(e);
      insertGrip(e.latlng);
    });
    g.markers = g.verts.map((v, i) => {
      const mk = L.marker([v.lat, v.lon], { icon: gripIcon(i, g.verts.length, i === g.selected), draggable: true, keyboard: false, zIndexOffset: 1000 });
      mk.on('dragstart', () => { gripPushUndo(); selectGrip(i); });
      mk.on('drag', (e) => {
        const ll = e.target.getLatLng();
        v.lat = ll.lat; v.lon = ll.lng;
        const lls = g.line.getLatLngs();
        lls[i] = ll;
        g.line.setLatLngs(lls);
      });
      mk.on('dragend', () => renderEditBar());
      mk.on('click', (e) => { L.DomEvent.stop(e); selectGrip(g.selected === i ? -1 : i); });
      mk.on('contextmenu', (e) => { L.DomEvent.stop(e); deleteGrip(i); });
      mk.addTo(L_grip);
      return mk;
    });
  }

  function selectGrip(i) {
    const g = S.grip;
    const old = g.selected;
    g.selected = i;
    if (old >= 0 && g.markers[old]) g.markers[old].setIcon(gripIcon(old, g.verts.length, false));
    if (i >= 0 && g.markers[i]) g.markers[i].setIcon(gripIcon(i, g.verts.length, true));
    renderEditBar();
  }

  function gripPushUndo() {
    S.grip.undo.push(JSON.stringify(S.grip.verts));
    if (S.grip.undo.length > 100) S.grip.undo.shift();
    S.grip.edited = true;
    updateHeader();
  }
  function gripUndo() {
    const g = S.grip;
    if (!g.undo.length) { toast(t('আনডু করার কিছু নেই', 'Nothing to undo')); return; }
    g.verts = JSON.parse(g.undo.pop());
    g.selected = -1;
    renderGrip();
    renderEditBar();
    updateHeader();
  }

  function insertGrip(latlng) {
    const g = S.grip;
    const p = map.latLngToLayerPoint(latlng);
    let best = Infinity, bi = 0;
    for (let i = 0; i + 1 < g.verts.length; i++) {
      const a = map.latLngToLayerPoint([g.verts[i].lat, g.verts[i].lon]), b = map.latLngToLayerPoint([g.verts[i + 1].lat, g.verts[i + 1].lon]);
      const d = L.LineUtil.pointToSegmentDistance(p, a, b);
      if (d < best) { best = d; bi = i; }
    }
    gripPushUndo();
    g.verts.splice(bi + 1, 0, { lat: latlng.lat, lon: latlng.lng, orig: -1 });
    g.selected = bi + 1;
    renderGrip();
    renderEditBar();
  }

  function deleteGrip(i) {
    const g = S.grip;
    if (i == null) i = g.selected;
    if (i < 0) { toast(t('আগে একটা গ্রিপে ক্লিক করে বেছে নিন', 'Click a grip to select it first')); return; }
    if (i === 0 || i === g.verts.length - 1) { toast(t('শুরু/শেষের গ্রিপ মোছা যায় না', 'Start/end grips cannot be deleted')); return; }
    gripPushUndo();
    g.verts.splice(i, 1);
    g.selected = -1;
    renderGrip();
    renderEditBar();
  }

  function renderEditBar() {
    const g = S.grip, bar = $('editBar');
    if (!g) { bar.classList.add('hidden'); return; }
    bar.classList.remove('hidden');
    bar.innerHTML = '<span class="info">' + g.verts.length + t(' গ্রিপ • টেনে সরান • লাইনে ক্লিক = নতুন গ্রিপ • ডান-ক্লিক = মুছুন', ' grips • drag to move • click line = add grip • right-click = delete') + '</span>'
      + '<label class="small muted">' + t('গ্রিপ সংখ্যা', 'Grips') + ' <select id="gpMax">' + [50, 100, 200, 300, 500].map((n) => '<option' + (n === g.max ? ' selected' : '') + '>' + n + '</option>').join('') + '</select></label>'
      + '<button class="small" id="gpUndo"' + (g.undo.length ? '' : ' disabled') + '>↩ ' + t('আনডু', 'Undo') + '</button>'
      + '<button class="small danger" id="gpDel"' + (g.selected > 0 && g.selected < g.verts.length - 1 ? '' : ' disabled') + '>🗑 ' + t('গ্রিপ', 'Grip') + '</button>'
      + '<button class="small primary" id="gpSave">✓ ' + t('সেভ', 'Save') + '</button>'
      + '<button class="small" id="gpCancel">✕ ' + t('বাতিল', 'Cancel') + '</button>';
    $('gpUndo').onclick = gripUndo;
    $('gpDel').onclick = () => deleteGrip();
    $('gpSave').onclick = () => endGrip(true).then(() => setModeNow('view'));
    $('gpCancel').onclick = () => endGrip(false).then(() => setModeNow('view'));
    $('gpMax').onchange = async (e) => {
      const n = +e.target.value;
      if (g.edited) {
        const ok = await confirmBox(t('গ্রিপ সংখ্যা বদলাবেন?', 'Change grip count?'), t('এখনকার না-সেভ করা গ্রিপ-এডিট বাদ যাবে।', 'Unsaved grip edits will be lost.'));
        if (!ok) { e.target.value = String(g.max); return; }
      }
      store.set('maxGrips', String(n));
      S.grip = null;
      startGrip();
    };
  }

  /** save=true applies the edit. ask=true asks what to do when there are unsaved grip edits. Resolves true when grip mode ended. */
  async function endGrip(save, ask) {
    const g = S.grip;
    if (!g) return true;
    if (ask && g.edited) {
      const r = await modal({
        title: t('গ্রিপ এডিট', 'Grip edit'),
        html: '<p>' + t('লাইনের পরিবর্তন সেভ করবেন?', 'Save the changes to the line?') + '</p>',
        buttons: [{ label: t('ফিরে যান', 'Go back'), value: null }, { label: t('বাদ দিন', 'Discard'), value: 'no', cls: 'danger' }, { label: t('সেভ', 'Save'), value: 'yes', cls: 'primary' }],
      });
      if (r == null) return false;
      save = r === 'yes';
    }
    const s = cur();
    if (save && g.edited && s) {
      S.undo.push(snapshot(s));
      if (!s.original) s.original = s.points.map((p) => Object.assign({}, p));
      s.points = C.rebuild(s.points, g.verts);
      C.afterLineChanged(s);
      S.grip = null;
      L_grip.clearLayers();
      $('editBar').classList.add('hidden');
      changed(false);
      toast(t('লাইন সেভ হলো • নতুন দৈর্ঘ্য ', 'Line saved • new length ') + C.length(s.points).toFixed(1) + ' m');
    } else {
      S.grip = null;
      L_grip.clearLayers();
      $('editBar').classList.add('hidden');
      if (trackLine) trackLine.setStyle({ opacity: 0.9 });
      updateHeader();
    }
    return true;
  }

  // ------------------------------------------------------------------ profile
  let profData = null;
  function drawProfile() {
    const box = $('profile');
    box.classList.toggle('hidden', !S.profileOn);
    if (!S.profileOn) return;
    const cv = $('profileCanvas'), s = cur();
    const dpr = window.devicePixelRatio || 1;
    const W = cv.clientWidth, H = cv.clientHeight;
    cv.width = W * dpr; cv.height = H * dpr;
    const g = cv.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, W, H);
    g.font = '11px Segoe UI, Nirmala UI, sans-serif';
    if (!s || s.points.length < 2) {
      g.fillStyle = '#6b7785';
      g.fillText(t('প্রোফাইলের জন্যে যথেষ্ট পয়েন্ট নেই', 'Not enough points for a profile'), 20, 30);
      $('profileInfo').textContent = '';
      profData = null;
      return;
    }
    const h = C.smoothAlt(s.points), len = C.length(s.points);
    let lo = Infinity, hi = -Infinity;
    for (const v of h) { if (v < lo) lo = v; if (v > hi) hi = v; }
    if (hi - lo < 4) { const m = (hi + lo) / 2; lo = m - 2; hi = m + 2; }
    const pad = (hi - lo) * 0.15; lo -= pad; hi += pad;
    const L0 = 52, R0 = 14, T0 = 14, B0 = 24;
    const X = (c) => L0 + (c / len) * (W - L0 - R0), Y = (a) => T0 + (1 - (a - lo) / (hi - lo)) * (H - T0 - B0);
    // grid
    g.strokeStyle = '#eef1f4'; g.fillStyle = '#6b7785'; g.lineWidth = 1;
    for (let k = 0; k <= 4; k++) {
      const a = lo + (hi - lo) * k / 4, y = Y(a);
      g.beginPath(); g.moveTo(L0, y); g.lineTo(W - R0, y); g.stroke();
      g.fillText(a.toFixed(1) + ' m', 4, y + 4);
    }
    const stepCh = [50, 100, 200, 500, 1000, 2000, 5000].find((st) => len / st <= 12) || 10000;
    for (let c = Math.ceil(s.startCh / stepCh) * stepCh - s.startCh; c <= len; c += stepCh) {
      const x = X(c);
      g.beginPath(); g.moveTo(x, T0); g.lineTo(x, H - B0); g.stroke();
      g.fillText(C.fmtCh(s.startCh + c), x - 18, H - 8);
    }
    // raw
    g.strokeStyle = 'rgba(120,144,156,.45)';
    g.beginPath();
    s.points.forEach((p, i) => { const x = X(p.ch), y = Y(Math.max(lo, Math.min(hi, p.alt))); if (i) g.lineTo(x, y); else g.moveTo(x, y); });
    g.stroke();
    // smoothed + fill
    g.beginPath();
    s.points.forEach((p, i) => { const x = X(p.ch), y = Y(h[i]); if (i) g.lineTo(x, y); else g.moveTo(x, y); });
    g.strokeStyle = '#1565c0'; g.lineWidth = 2; g.stroke();
    g.lineTo(X(len), H - B0); g.lineTo(X(0), H - B0); g.closePath();
    g.fillStyle = 'rgba(21,101,192,.08)'; g.fill();
    // marks
    g.fillStyle = '#6a1b9a';
    s.marks.forEach((m, i) => { const x = X(m.ch); g.fillRect(x - 1, T0, 2, 8); g.fillText(String(i + 1), x + 3, T0 + 8); });
    const st = C.profileStats(s.points);
    $('profileInfo').textContent = t('উচ্চতা ', 'Elevation ') + st.minAlt.toFixed(1) + '–' + st.maxAlt.toFixed(1) + ' m • ' + t('ওঠা/নামা ', 'rise/fall ')
      + st.rise.toFixed(0) + '/' + st.fall.toFixed(0) + ' m • ' + t('সর্বোচ্চ ঢাল ', 'max grade ') + st.maxGrade.toFixed(1) + '% • ' + t('(আনুমানিক)', '(approx.)');
    profData = { X, Y, len, h, L0, R0, W, H, T0, B0 };
  }
  $('profileCanvas').addEventListener('mousemove', (e) => {
    const s = cur();
    if (!profData || !s) return;
    const r = e.target.getBoundingClientRect();
    const x = e.clientX - r.left;
    const c = Math.max(0, Math.min(profData.len, (x - profData.L0) / (profData.W - profData.L0 - profData.R0) * profData.len));
    drawProfile();
    const p = C.pointAtCh(s.points, c);
    const i = p ? Math.max(1, p[2]) : 1;
    const a = s.points[i - 1], b = s.points[i];
    const f = b.ch - a.ch < 1e-6 ? 0 : Math.max(0, Math.min(1, (c - a.ch) / (b.ch - a.ch)));
    const el = profData.h[i - 1] + (profData.h[i] - profData.h[i - 1]) * f;
    const g = e.target.getContext('2d');
    g.strokeStyle = '#e53935'; g.lineWidth = 1;
    g.beginPath(); g.moveTo(profData.X(c), profData.T0); g.lineTo(profData.X(c), profData.H - profData.B0); g.stroke();
    g.fillStyle = '#b71c1c';
    g.fillText(C.fmtCh(s.startCh + c) + ' • ' + el.toFixed(1) + ' m', Math.min(profData.X(c) + 5, profData.W - 130), profData.T0 + 22);
    if (p) {
      if (!hoverMarker) hoverMarker = L.circleMarker([p[0], p[1]], { radius: 7, color: '#b71c1c', weight: 3, fillOpacity: 0.3, interactive: false });
      hoverMarker.setLatLng([p[0], p[1]]).addTo(map);
    }
  });
  $('profileCanvas').addEventListener('mouseleave', () => { if (hoverMarker) hoverMarker.remove(); drawProfile(); });
  $('profileCanvas').addEventListener('click', (e) => {
    const s = cur();
    if (!profData || !s) return;
    const r = e.target.getBoundingClientRect();
    const c = Math.max(0, Math.min(profData.len, (e.clientX - r.left - profData.L0) / (profData.W - profData.L0 - profData.R0) * profData.len));
    const p = C.pointAtCh(s.points, c);
    if (p) map.panTo([p[0], p[1]]);
  });
  window.addEventListener('resize', () => { if (S.profileOn) drawProfile(); });
  $('btnProfile').onclick = () => {
    S.profileOn = !S.profileOn;
    $('profile').classList.toggle('hidden', !S.profileOn);
    $('mainArea').classList.toggle('with-profile', S.profileOn);
    map.invalidateSize();
    drawProfile();
  };

  // ------------------------------------------------------------------ open / save
  const ZIP_FILTER = [{ name: t('রোড সার্ভে ব্যাকআপ', 'Road Survey backup'), extensions: ['zip'] }];

  async function openBackup() {
    const f = await window.api.openFile({ title: t('ফোনের ব্যাকআপ ZIP খুলুন', 'Open the phone backup ZIP'), filters: ZIP_FILTER });
    if (f) await loadBackupBytes(f.data, f.name, f.path);
  }

  async function loadBackupBytes(data, name, path) {
    let res;
    try {
      res = await C.readBackup(data);
    } catch (err) {
      alertBox(t('খোলা যায়নি', 'Could not open'), String(err && err.message || err));
      return;
    }
    if (!res.surveys.length) {
      alertBox(t('কোনো সার্ভে নেই', 'No surveys'), t('এই ফাইলে কোনো সার্ভে পাওয়া যায়নি। এটা কি রোড সার্ভে অ্যাপের ব্যাকআপ ZIP?', 'No surveys found. Is this a Road Survey app backup ZIP?'));
      return;
    }
    let add = false;
    if (S.surveys.length) {
      const r = await modal({
        title: t('আরেকটা ব্যাকআপ', 'Another backup'),
        html: '<p>' + t('এখন খোলা সার্ভেগুলোর সাথে যোগ করবেন, নাকি শুধু নতুন ফাইলটা খুলবেন?', 'Add to the surveys already open, or open only the new file?') + '</p>'
          + (S.dirty ? '<p class="muted">' + t('সতর্কতা: এখনকার পরিবর্তন সেভ হয়নি।', 'Warning: current changes are not saved.') + '</p>' : ''),
        buttons: [{ label: t('বাতিল', 'Cancel'), value: null }, { label: t('যোগ করুন', 'Add'), value: 'add' }, { label: t('শুধু নতুনটা', 'Only the new one'), value: 'new', cls: 'primary' }],
      });
      if (!r) return;
      add = r === 'add';
    }
    if (S.grip) await endGrip(false);
    if (add) {
      for (const s of res.surveys) {
        const clash = S.surveys.findIndex((x) => x.id === s.id);
        if (clash >= 0) {
          const keep = await modal({
            title: t('একই সার্ভে দুবার', 'Same survey twice'),
            html: '<p><b>' + esc(s.name) + '</b> ' + t('আগে থেকেই খোলা আছে।', 'is already open.') + '</p>',
            buttons: [{ label: t('দুটোই রাখুন', 'Keep both'), value: 'both' }, { label: t('নতুনটা দিয়ে বদলান', 'Replace with new'), value: 'rep', cls: 'primary' }],
          });
          if (keep === 'rep') { S.surveys[clash] = s; continue; }
          s.id = s.id + 'd' + (Date.now() % 100000);
          s.changed = true;
        }
        S.surveys.push(s);
      }
      res.tags.forEach((x) => { if (!S.tags.includes(x)) S.tags.push(x); });
      S.fileName = S.fileName + ' + ' + name;
      setDirty(true);
    } else {
      S.surveys = res.surveys;
      S.tags = res.tags;
      S.filePath = path || null;
      S.fileName = name;
      setDirty(false);
    }
    selectSurvey(S.surveys.length - 1 >= 0 ? (add ? S.cur : S.surveys.length - 1) : -1, true);
    toast(res.surveys.length + t('টা সার্ভে খোলা হলো', ' survey(s) opened'));
  }

  async function saveBackup() {
    if (!S.surveys.length) return false;
    if (S.grip && !(await endGrip(false, true))) return false;
    const data = await C.writeBackup(S.surveys, S.tags);
    let def = 'RoadSurvey_backup_desktop_' + C.stamp() + '.zip';
    if (S.filePath) def = S.filePath.replace(/(_edited)?(_\d{8}_\d{4})?\.zip$/i, '') + '_edited.zip';
    const r = await window.api.saveFile({ title: t('ব্যাকআপ সেভ করুন', 'Save backup'), path: def, name: def, filters: ZIP_FILTER, data });
    if (!r) return false;
    S.filePath = r.path;
    S.fileName = r.name;
    S.surveys.forEach((s) => { s.changed = false; });
    setDirty(false);
    renderList();
    await modal({
      title: t('সেভ হয়েছে', 'Saved'),
      html: '<p><b>' + esc(r.name) + '</b></p><p>' + t('ফোনে ফেরত নিতে: ফাইলটা ফোনে পাঠান (USB, WhatsApp, Google Drive…) → অ্যাপে ⚙ সেটিংস → ব্যাকআপ / রিস্টোর → রিস্টোর → ফাইলটা বেছে নিন → "বদলে দিন"।',
        'To put it back on the phone: send the file to the phone (USB, WhatsApp, Google Drive…) → in the app ⚙ Settings → Backup / restore → Restore → pick the file → "Replace".') + '</p>',
      buttons: [{ label: t('ফোল্ডারে দেখুন', 'Show in folder'), value: 'show' }, { label: t('ঠিক আছে', 'OK'), value: true, cls: 'primary' }],
    }).then((v) => { if (v === 'show') window.api.showInFolder(r.path); });
    return true;
  }

  // ------------------------------------------------------------------ import
  async function readGeoFile(data, name) {
    let bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    if (bytes[0] === 0x50 && bytes[1] === 0x4B) {
      const files = await C.unzip(bytes);
      const k = Object.keys(files).find((n) => /\.kml$/i.test(n));
      if (!k) throw new Error(t('KMZ-এর ভেতরে KML নেই', 'No KML inside the KMZ'));
      bytes = files[k];
    }
    return C.parseGeoXml(C.fromUtf8(bytes), name);
  }
  const GEO_FILTER = [{ name: 'KML / KMZ / GPX', extensions: ['kml', 'kmz', 'gpx'] }];

  async function importDesign(file) {
    const s = cur();
    if (!s) { toast(t('আগে একটা সার্ভে খুলুন বা বেছে নিন', 'Open or select a survey first')); return; }
    const f = file || await window.api.openFile({ title: t('ডিজাইন ফাইল', 'Design file'), filters: GEO_FILTER });
    if (!f) return;
    try {
      const g = await readGeoFile(f.data, f.name);
      if (!g.lines.length && !g.points.length) { alertBox(t('কিছু পাওয়া যায়নি', 'Nothing found'), t('ফাইলে কোনো লাইন বা পয়েন্ট নেই।', 'The file has no lines or points.')); return; }
      pushUndo();
      s.ref = { name: f.name, lines: g.lines, points: g.points.map((p) => ({ lat: p.lat, lon: p.lon, name: p.name || '' })) };
      changed(false);
      const all = [].concat(...g.lines, g.points.map((p) => [p.lat, p.lon]));
      if (all.length) map.fitBounds(L.latLngBounds(all).extend(s.points.map((p) => [p.lat, p.lon])), { padding: [30, 30] });
      toast(t('ডিজাইন যোগ হলো: ', 'Design added: ') + g.lines.length + t(' লাইন, ', ' lines, ') + g.points.length + t(' পয়েন্ট', ' points'));
    } catch (err) {
      alertBox(t('খোলা যায়নি', 'Could not open'), String(err && err.message || err));
    }
  }

  async function importTrack(file) {
    const f = file || await window.api.openFile({ title: t('KML / GPX ট্র্যাক', 'KML / GPX track'), filters: GEO_FILTER });
    if (!f) return;
    try {
      const g = await readGeoFile(f.data, f.name);
      if (!g.tracks.length) { alertBox(t('ট্র্যাক নেই', 'No track'), t('এই ফাইলে কোনো লাইন/ট্র্যাক নেই।', 'This file has no line/track.')); return; }
      let tr = g.tracks.reduce((a, b) => (b.pts.length > a.pts.length ? b : a));
      const s = C.surveyFromTrack(tr, (tr.name || f.name.replace(/\.\w+$/, '')).slice(0, 60));
      g.points.forEach((p) => {
        const m = { lat: p.lat, lon: p.lon, alt: Number.isFinite(p.alt) ? p.alt : 0, ch: 0, time: s.points.length ? s.points[0].time : Date.now(), photo: '', name: p.name || t('পয়েন্ট', 'Point') };
        const pr = C.project(s.points, m.lat, m.lon);
        if (pr.dist < 200) { m.ch = pr.ch; s.marks.push(m); }
      });
      S.surveys.push(s);
      if (!S.fileName) S.fileName = t('নতুন', 'New');
      setDirty(true);
      selectSurvey(S.surveys.length - 1, true);
      toast(t('নতুন সার্ভে: ', 'New survey: ') + s.name + ' • ' + (C.length(s.points) / 1000).toFixed(2) + ' km');
    } catch (err) {
      alertBox(t('খোলা যায়নি', 'Could not open'), String(err && err.message || err));
    }
  }

  // ------------------------------------------------------------------ export
  function safeName(s) { return String(s).replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, '_').slice(0, 60) || 'survey'; }

  async function askInterval(title) {
    let v = null;
    const last = store.get('interval', '20');
    const r = await modal({
      title,
      html: '<div class="row"><label>' + t('চেইনেজ ব্যবধান', 'Chainage interval') + '</label><select id="ivSel">'
        + [5, 10, 20, 25, 50, 100, 200, 500, 1000].map((n) => '<option value="' + n + '"' + (String(n) === last ? ' selected' : '') + '>' + n + ' m</option>').join('')
        + '</select></div>',
      buttons: [{ label: t('বাতিল', 'Cancel'), value: null }, { label: t('তৈরি করুন', 'Create'), value: 'ok', cls: 'primary' }],
      validate: (x, m) => { v = +m.querySelector('#ivSel').value; return true; },
    });
    if (r !== 'ok') return null;
    store.set('interval', String(v));
    return v;
  }

  async function doExport(kind) {
    const s = cur();
    if (!s) { toast(t('আগে একটা সার্ভে খুলুন', 'Open a survey first')); return; }
    if (S.grip && !(await endGrip(false, true))) return;
    const base = safeName(s.name) + '_' + C.stamp();
    let data, name, filters;
    try {
      if (kind === 'kml') { data = C.kml(s); name = base + '.kml'; filters = [{ name: 'KML', extensions: ['kml'] }]; }
      else if (kind === 'kmz') { data = await C.zip({ 'doc.kml': C.kml(s) }); name = base + '.kmz'; filters = [{ name: 'KMZ', extensions: ['kmz'] }]; }
      else if (kind === 'gpx') { data = C.gpx(s); name = base + '.gpx'; filters = [{ name: 'GPX', extensions: ['gpx'] }]; }
      else if (kind === 'csv') { data = C.csv(s); name = base + '.csv'; filters = [{ name: 'CSV', extensions: ['csv'] }]; }
      else if (kind === 'xlsx') {
        const step = await askInterval(t('Excel ফাইল', 'Excel file'));
        if (!step) return;
        data = await C.zip(C.xlsxFiles(C.xlsxSheets(s, step)));
        name = base + '.xlsx'; filters = [{ name: 'Excel', extensions: ['xlsx'] }];
      } else if (kind === 'dxf') {
        const step = await askInterval(t('AutoCAD DXF', 'AutoCAD DXF'));
        if (!step) return;
        data = C.dxf(s, step); name = base + '.dxf'; filters = [{ name: 'DXF', extensions: ['dxf'] }];
      } else if (kind === 'pdf') {
        const step = await askInterval(t('PDF রিপোর্ট', 'PDF report'));
        if (!step) return;
        const html = window.Report.build(s, step);
        const r = await window.api.savePdf({ title: t('PDF রিপোর্ট সেভ', 'Save PDF report'), name: base + '.pdf', html });
        if (r) savedToast(r);
        return;
      }
      const r = await window.api.saveFile({ title: t('এক্সপোর্ট', 'Export'), name, filters, data });
      if (r) savedToast(r);
    } catch (err) {
      alertBox(t('এক্সপোর্ট হয়নি', 'Export failed'), String(err && err.message || err));
    }
  }
  function savedToast(r) {
    toast(t('সেভ হয়েছে: ', 'Saved: ') + r.name, 4000);
    $('stMsg').innerHTML = '';
    const a = document.createElement('a');
    a.href = '#';
    a.textContent = '📁 ' + r.name;
    a.onclick = (e) => { e.preventDefault(); window.api.showInFolder(r.path); };
    $('stMsg').appendChild(a);
  }

  // ------------------------------------------------------------------ toolbar wiring
  $('btnOpen').onclick = openBackup;
  $('btnOpen2').onclick = openBackup;
  $('btnSave').onclick = saveBackup;
  $('btnUndo').onclick = undo;
  $('impDesign').onclick = () => importDesign();
  $('impTrack').onclick = () => importTrack();
  $('impClearDesign').onclick = () => {
    const s = cur();
    if (!s || !s.ref) { toast(t('এই সার্ভেতে কোনো ডিজাইন নেই', 'This survey has no design')); return; }
    pushUndo();
    s.ref = null;
    changed(false);
  };
  document.querySelectorAll('[data-exp]').forEach((b) => { b.onclick = () => doExport(b.dataset.exp); });
  document.querySelectorAll('.dd > .tb').forEach((b) => {
    b.onclick = (e) => {
      e.stopPropagation();
      const dd = b.parentElement, open = dd.classList.contains('open');
      document.querySelectorAll('.dd.open').forEach((x) => x.classList.remove('open'));
      if (!open) dd.classList.add('open');
    };
  });
  document.addEventListener('click', () => document.querySelectorAll('.dd.open').forEach((x) => x.classList.remove('open')));

  $('btnLang').onclick = () => {
    C.setLang(C.getLang() === 'en' ? 'bn' : 'en');
    store.set('lang', C.getLang());
    applyLang();
    buildLayerControl();
    renderList();
    renderTab();
    drawSurvey(false);
    drawProfile();
    if (S.grip) renderEditBar();
    if (S.mode === 'dist' || S.mode === 'area') drawMeasure();
    modeHint();
    updateHeader();
  };

  $('btnAbout').onclick = async () => {
    const info = await window.api.info();
    modal({
      title: 'Road Survey Desktop ' + info.version,
      html: '<p><b>Developed by Akshoy Bhowmick</b></p>'
        + '<p>' + t('ফোনের "রোড সার্ভে" অ্যাপের ব্যাকআপ কম্পিউটারে খুলে দেখা, এডিট (গ্রিপ এডিট সহ), মাপ, রিপোর্ট আর এক্সপোর্ট করার প্রোগ্রাম। সেভ করা ZIP আবার ফোনে রিস্টোর করা যায়।',
          'Open the phone "Road Survey" app backup on the computer: view, edit (including grip edit), measure, report and export. The saved ZIP can be restored on the phone again.') + '</p>'
        + '<p class="muted small">' + t('শর্টকাট: Ctrl+O খুলুন • Ctrl+S সেভ • Ctrl+Z আনডু • Delete গ্রিপ মুছুন • Esc শেষ', 'Shortcuts: Ctrl+O open • Ctrl+S save • Ctrl+Z undo • Delete remove grip • Esc finish') + '</p>'
        + '<p class="muted small">' + t('ম্যাপ: © OpenStreetMap contributors, Esri। ফোনের ছবি/ভিডিও/ভয়েস নোট ব্যাকআপে থাকে না, শুধু তাদের তালিকা থাকে।',
          'Maps: © OpenStreetMap contributors, Esri. Phone photos/videos/voice notes are not inside the backup, only their list.') + '</p>',
    });
  };

  // keyboard
  document.addEventListener('keydown', (e) => {
    if (!$('modalBack').classList.contains('hidden')) return;
    const typing = /INPUT|TEXTAREA|SELECT/.test(e.target.tagName);
    if (e.ctrlKey && e.key.toLowerCase() === 'o') { e.preventDefault(); openBackup(); }
    else if (e.ctrlKey && e.key.toLowerCase() === 's') { e.preventDefault(); saveBackup(); }
    else if (e.ctrlKey && e.key.toLowerCase() === 'z' && !typing) { e.preventDefault(); undo(); }
    else if (e.key === 'Escape' && !typing) {
      if (S.mode === 'dist' || S.mode === 'area') {
        if (S.measure.length && !S.measureDone) { S.measureDone = true; drawMeasure(); } else setMode('view');
      } else if (S.mode !== 'view') setMode('view');
    } else if ((e.key === 'Delete' || e.key === 'Backspace') && !typing && S.grip) { e.preventDefault(); deleteGrip(); }
  });

  // drag & drop files
  let dragDepth = 0;
  window.addEventListener('dragenter', (e) => { e.preventDefault(); dragDepth++; $('dropHint').classList.remove('hidden'); });
  window.addEventListener('dragleave', () => { if (--dragDepth <= 0) { dragDepth = 0; $('dropHint').classList.add('hidden'); } });
  window.addEventListener('dragover', (e) => e.preventDefault());
  window.addEventListener('drop', async (e) => {
    e.preventDefault();
    dragDepth = 0;
    $('dropHint').classList.add('hidden');
    const file = e.dataTransfer.files[0];
    if (!file) return;
    const data = new Uint8Array(await file.arrayBuffer());
    const n = file.name.toLowerCase();
    if (n.endsWith('.zip')) loadBackupBytes(data, file.name, null);
    else if (/\.(kml|kmz|gpx)$/.test(n)) {
      if (!cur()) { importTrack({ data, name: file.name }); return; }
      const r = await modal({
        title: file.name,
        html: '<p>' + t('এই ফাইল দিয়ে কী করবেন?', 'What to do with this file?') + '</p>',
        buttons: [{ label: t('বাতিল', 'Cancel'), value: null }, { label: t('নতুন সার্ভে', 'New survey'), value: 'track' }, { label: t('ডিজাইন হিসেবে', 'As design'), value: 'design', cls: 'primary' }],
      });
      if (r === 'design') importDesign({ data, name: file.name });
      else if (r === 'track') importTrack({ data, name: file.name });
    } else toast(t('শুধু ZIP, KML, KMZ, GPX খোলা যায়', 'Only ZIP, KML, KMZ, GPX can be opened'));
  });

  // closing with unsaved changes
  window.api.onCloseRequest(async () => {
    if (!S.dirty && !(S.grip && S.grip.edited)) { window.api.closeOk(); return; }
    const r = await modal({
      title: t('পরিবর্তন সেভ হয়নি', 'Changes not saved'),
      html: '<p>' + t('বন্ধ করার আগে সেভ করবেন?', 'Save before closing?') + '</p>',
      buttons: [{ label: t('ফিরে যান', 'Go back'), value: null }, { label: t('সেভ না করে বন্ধ', 'Close without saving'), value: 'no', cls: 'danger' }, { label: t('সেভ', 'Save'), value: 'yes', cls: 'primary' }],
    });
    if (r === 'no') window.api.closeOk();
    else if (r === 'yes' && (await saveBackup())) window.api.closeOk();
  });

  // ------------------------------------------------------------------ start
  applyLang();
  buildLayerControl();
  renderList();
  updateHeader();
})();
