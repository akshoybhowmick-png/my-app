/* PDF report (HTML that Electron prints to PDF). Developed by Akshoy Bhowmick */
(function (root) {
  'use strict';
  const C = root.Core || (typeof require !== 'undefined' ? require('./core.js') : null);
  const t = (a, b) => C.t(a, b);
  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  function table(head, rows, cls) {
    return '<table class="' + (cls || '') + '"><thead><tr>' + head.map((h) => '<th>' + esc(h) + '</th>').join('') + '</tr></thead><tbody>'
      + rows.map((r) => '<tr>' + r.map((c) => '<td>' + (c == null ? '' : esc(c)) + '</td>').join('') + '</tr>').join('') + '</tbody></table>';
  }

  /** Plan of the alignment in UTM metres, north up. */
  function planSvg(s, step) {
    const W = 760, H = 520, pad = 40;
    const pts = s.points;
    if (pts.length < 2) return '';
    const zone = C.utm(pts[0].lat, pts[0].lon).zone;
    const xy = (lat, lon) => { const u = C.utm(lat, lon, zone); return [u.easting, u.northing]; };
    const P = pts.map((p) => xy(p.lat, p.lon));
    const M = s.marks.map((m) => xy(m.lat, m.lon));
    const D = s.ref ? s.ref.lines.map((ln) => ln.map((q) => xy(q[0], q[1]))) : [];
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const q of P.concat(M)) { minX = Math.min(minX, q[0]); maxX = Math.max(maxX, q[0]); minY = Math.min(minY, q[1]); maxY = Math.max(maxY, q[1]); }
    const span = Math.max(maxX - minX, maxY - minY, 20);
    const k = Math.min((W - 2 * pad) / Math.max(maxX - minX, 1), (H - 2 * pad) / Math.max(maxY - minY, 1), (W - 2 * pad) / span * 4);
    const ox = (W - (maxX - minX) * k) / 2, oy = (H - (maxY - minY) * k) / 2;
    const X = (x) => ox + (x - minX) * k, Y = (y) => H - (oy + (y - minY) * k);
    const path = (arr) => arr.map((q, i) => (i ? 'L' : 'M') + X(q[0]).toFixed(1) + ' ' + Y(q[1]).toFixed(1)).join(' ');
    let o = '<svg xmlns="http://www.w3.org/2000/svg" width="100%" viewBox="0 0 ' + W + ' ' + H + '" style="border:1px solid #ccd;background:#fbfcfd">';
    for (const d of D) o += '<path d="' + path(d) + '" fill="none" stroke="#8e24aa" stroke-width="1.5" stroke-dasharray="6 4"/>';
    o += '<path d="' + path(P) + '" fill="none" stroke="#d32f2f" stroke-width="2.5" stroke-linejoin="round"/>';
    // chainage ticks (not too many)
    const len = C.length(pts);
    let st = step;
    while (len / st > 40) st *= 2;
    for (let c = Math.ceil(s.startCh / st) * st; c <= s.startCh + len; c += st) {
      const p = C.pointAtCh(pts, c - s.startCh);
      if (!p) continue;
      const q = xy(p[0], p[1]);
      const km = Math.round(c) % 1000 === 0;
      o += '<circle cx="' + X(q[0]).toFixed(1) + '" cy="' + Y(q[1]).toFixed(1) + '" r="' + (km ? 3 : 2) + '" fill="' + (km ? '#0d47a1' : '#455a64') + '"/>'
        + '<text x="' + (X(q[0]) + 5).toFixed(1) + '" y="' + (Y(q[1]) - 4).toFixed(1) + '" font-size="' + (km ? 10 : 8) + '" fill="' + (km ? '#0d47a1' : '#455a64') + '">' + C.fmtCh(c) + '</text>';
    }
    M.forEach((q, i) => {
      o += '<circle cx="' + X(q[0]).toFixed(1) + '" cy="' + Y(q[1]).toFixed(1) + '" r="6" fill="#1565c0" stroke="#fff" stroke-width="1.5"/>'
        + '<text x="' + X(q[0]).toFixed(1) + '" y="' + (Y(q[1]) + 3).toFixed(1) + '" font-size="7" fill="#fff" text-anchor="middle" font-weight="bold">' + (i + 1) + '</text>';
    });
    const s0 = P[0], e0 = P[P.length - 1];
    o += '<circle cx="' + X(s0[0]) + '" cy="' + Y(s0[1]) + '" r="5" fill="#2e7d32"/><circle cx="' + X(e0[0]) + '" cy="' + Y(e0[1]) + '" r="5" fill="#b71c1c"/>';
    // north arrow + scale bar
    o += '<g transform="translate(' + (W - 30) + ',40)"><path d="M0 -18 L7 6 L0 1 L-7 6 Z" fill="#263238"/><text y="20" font-size="11" text-anchor="middle">N</text></g>';
    const target = (W - 2 * pad) / 4 / k;
    const nice = [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000, 10000].reduce((a, b) => (Math.abs(b - target) < Math.abs(a - target) ? b : a));
    o += '<g transform="translate(20,' + (H - 18) + ')"><rect width="' + (nice * k).toFixed(1) + '" height="5" fill="#263238"/>'
      + '<text y="-4" font-size="10">' + (nice >= 1000 ? nice / 1000 + ' km' : nice + ' m') + '</text></g>';
    o += '<text x="' + (W - 8) + '" y="' + (H - 8) + '" font-size="9" text-anchor="end" fill="#78909c">UTM ' + zone + (pts[0].lat >= 0 ? 'N' : 'S') + ' (WGS84)</text>';
    return o + '</svg>';
  }

  function profileSvg(s) {
    const pts = s.points;
    if (pts.length < 2) return '';
    const W = 760, H = 240, L0 = 50, R0 = 10, T0 = 12, B0 = 26;
    const h = C.smoothAlt(pts), len = C.length(pts);
    let lo = Infinity, hi = -Infinity;
    for (const v of h) { lo = Math.min(lo, v); hi = Math.max(hi, v); }
    if (hi - lo < 4) { const m = (hi + lo) / 2; lo = m - 2; hi = m + 2; }
    const pad = (hi - lo) * 0.15; lo -= pad; hi += pad;
    const X = (c) => L0 + c / len * (W - L0 - R0), Y = (a) => T0 + (1 - (a - lo) / (hi - lo)) * (H - T0 - B0);
    let o = '<svg xmlns="http://www.w3.org/2000/svg" width="100%" viewBox="0 0 ' + W + ' ' + H + '" style="border:1px solid #ccd">';
    for (let k = 0; k <= 4; k++) {
      const a = lo + (hi - lo) * k / 4;
      o += '<line x1="' + L0 + '" x2="' + (W - R0) + '" y1="' + Y(a) + '" y2="' + Y(a) + '" stroke="#e8ecf0"/><text x="4" y="' + (Y(a) + 3) + '" font-size="9" fill="#555">' + a.toFixed(1) + ' m</text>';
    }
    const stepCh = [50, 100, 200, 500, 1000, 2000, 5000].find((st) => len / st <= 12) || 10000;
    for (let c = Math.ceil(s.startCh / stepCh) * stepCh - s.startCh; c <= len; c += stepCh) {
      o += '<line x1="' + X(c) + '" x2="' + X(c) + '" y1="' + T0 + '" y2="' + (H - B0) + '" stroke="#e8ecf0"/><text x="' + (X(c) - 16) + '" y="' + (H - 10) + '" font-size="9" fill="#555">' + C.fmtCh(s.startCh + c) + '</text>';
    }
    const every = Math.max(1, Math.floor(pts.length / 1500));
    let d = '';
    for (let i = 0; i < pts.length; i += every) d += (d ? 'L' : 'M') + X(pts[i].ch).toFixed(1) + ' ' + Y(h[i]).toFixed(1);
    o += '<path d="' + d + '" fill="none" stroke="#1565c0" stroke-width="2"/>';
    s.marks.forEach((m, i) => { o += '<line x1="' + X(m.ch) + '" x2="' + X(m.ch) + '" y1="' + T0 + '" y2="' + (T0 + 8) + '" stroke="#6a1b9a" stroke-width="2"/><text x="' + (X(m.ch) + 2) + '" y="' + (T0 + 8) + '" font-size="8" fill="#6a1b9a">' + (i + 1) + '</text>'; });
    return o + '</svg>';
  }

  function build(s, step) {
    const len = C.length(s.points), st = C.profileStats(s.points), curves = C.findCurves(s.points);
    const css = '@page{size:A4;margin:12mm 10mm 14mm}body{font-family:"Segoe UI","Nirmala UI","Vrinda",sans-serif;font-size:10.5px;color:#1d2733;margin:0}'
      + 'h1{font-size:19px;margin:0 0 2px;color:#0d47a1}h2{font-size:13.5px;margin:16px 0 6px;color:#0d47a1;border-bottom:1.5px solid #0d47a1;padding-bottom:2px}'
      + 'table{border-collapse:collapse;width:100%;margin:4px 0}th,td{border:1px solid #c9d2db;padding:3px 5px;text-align:left}th{background:#e8f0fa}'
      + 'tr{page-break-inside:avoid}thead{display:table-header-group}.kv td:first-child{width:38%;background:#f6f8fa}.muted{color:#6b7785}.head{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:3px solid #0d47a1;padding-bottom:6px}'
      + '.block{page-break-inside:avoid}';
    let o = '<!DOCTYPE html><html><head><meta charset="utf-8"><style>' + css + '</style></head><body>';
    o += '<div class="head"><div><h1>' + esc(s.name) + '</h1><div class="muted">' + t('রাস্তার অ্যালাইনমেন্ট সার্ভে রিপোর্ট', 'Road alignment survey report') + '</div></div>'
      + '<div class="muted" style="text-align:right">' + C.localTime(Date.now()) + '<br>Developed by Akshoy Bhowmick</div></div>';
    const rows = [
      [t('শুরুর চেইনেজ', 'Start chainage'), C.fmtCh(s.startCh)],
      [t('শেষ চেইনেজ', 'End chainage'), C.fmtCh(s.startCh + len)],
      [t('মোট দৈর্ঘ্য', 'Total length'), len.toFixed(1) + ' m (' + (len / 1000).toFixed(3) + ' km)'],
      [t('রেকর্ডের তারিখ', 'Recorded'), s.points.length ? C.localTime(s.points[0].time) : '—'],
      [t('GPS পয়েন্ট / চিহ্নিত পয়েন্ট', 'GPS points / marked points'), s.points.length + ' / ' + s.marks.length],
      [t('বাঁক / রাস্তার অংশ', 'Curves / road segments'), curves.length + ' / ' + s.segments.length],
      [t('লাইন হাতে এডিট', 'Line hand-edited'), s.original ? t('হ্যাঁ', 'Yes') : t('না', 'No')],
    ];
    if (st.valid) {
      rows.push([t('উচ্চতা (কম–বেশি, আনুমানিক)', 'Elevation (min–max, approx.)'), st.minAlt.toFixed(1) + ' – ' + st.maxAlt.toFixed(1) + ' m']);
      rows.push([t('মোট ওঠা / নামা', 'Total rise / fall'), st.rise.toFixed(0) + ' / ' + st.fall.toFixed(0) + ' m']);
      rows.push([t('গড় / সর্বোচ্চ ঢাল', 'Average / max grade'), st.avgGrade.toFixed(2) + ' % / ' + st.maxGrade.toFixed(1) + ' %']);
    }
    if (s.points.length) {
      const u0 = C.utm(s.points[0].lat, s.points[0].lon), p0 = s.points[0], pe = s.points[s.points.length - 1], ue = C.utm(pe.lat, pe.lon);
      rows.push([t('শুরুর স্থানাঙ্ক', 'Start coordinates'), p0.lat.toFixed(7) + ', ' + p0.lon.toFixed(7) + ' • UTM ' + u0.label + ' ' + u0.easting.toFixed(2) + ' E ' + u0.northing.toFixed(2) + ' N']);
      rows.push([t('শেষের স্থানাঙ্ক', 'End coordinates'), pe.lat.toFixed(7) + ', ' + pe.lon.toFixed(7) + ' • UTM ' + ue.label + ' ' + ue.easting.toFixed(2) + ' E ' + ue.northing.toFixed(2) + ' N']);
    }
    o += '<h2>' + t('সারাংশ', 'Summary') + '</h2>' + table([t('বিষয়', 'Item'), t('মান', 'Value')], rows, 'kv');
    o += '<div class="block"><h2>' + t('অ্যালাইনমেন্টের নকশা', 'Alignment plan') + '</h2>' + planSvg(s, step) + '</div>';
    o += '<div class="block"><h2>' + t('উচ্চতার প্রোফাইল (আনুমানিক)', 'Elevation profile (approx.)') + '</h2>' + profileSvg(s) + '</div>';
    if (s.marks.length) {
      o += '<h2>' + t('চিহ্নিত পয়েন্ট', 'Marked points') + '</h2>' + table(
        [t('নং', 'No.'), t('নাম', 'Name'), t('চেইনেজ', 'Chainage'), t('অক্ষাংশ, দ্রাঘিমাংশ', 'Lat, Lon'), 'UTM E / N', t('উচ্চতা', 'Elev.'), t('ছবি', 'Photos')],
        s.marks.map((m, i) => { const u = C.utm(m.lat, m.lon); return [i + 1, m.name, C.fmtCh(s.startCh + m.ch), m.lat.toFixed(7) + ', ' + m.lon.toFixed(7), u.easting.toFixed(2) + ' / ' + u.northing.toFixed(2), m.alt.toFixed(1), C.photosOf(m.photo).length || '']; }));
    }
    if (curves.length) {
      o += '<h2>' + t('বাঁক (হরাইজন্টাল কার্ভ)', 'Horizontal curves') + '</h2>' + table(
        [t('নং', 'No.'), t('শুরু', 'Start'), t('শেষ', 'End'), t('দিক', 'Direction'), t('কোণ', 'Deflection'), t('ব্যাসার্ধ (মি)', 'Radius (m)'), t('দৈর্ঘ্য (মি)', 'Length (m)'), t('ট্যানজেন্ট (মি)', 'Tangent (m)')],
        curves.map((c, i) => ['C' + (i + 1), C.fmtCh(s.startCh + c.startCh), C.fmtCh(s.startCh + c.endCh), c.right ? t('ডানে', 'Right') : t('বাঁয়ে', 'Left'),
          c.deflection.toFixed(1) + '°', c.radius.toFixed(0), c.length.toFixed(0), Number.isFinite(c.tangent) ? c.tangent.toFixed(0) : '—']));
    }
    if (s.segments.length) {
      o += '<h2>' + t('রাস্তার অংশ', 'Road segments') + '</h2>' + table(
        [t('থেকে', 'From'), t('পর্যন্ত', 'To'), t('দৈর্ঘ্য (মি)', 'Length (m)'), t('ধরন', 'Surface'), t('অবস্থা', 'Condition'), t('চওড়া (মি)', 'Width (m)')],
        s.segments.map((g, i) => { const to = i + 1 < s.segments.length ? s.segments[i + 1].ch : len; return [C.fmtCh(s.startCh + g.ch), C.fmtCh(s.startCh + to), Math.max(0, to - g.ch).toFixed(1), g.surface, g.condition, Number.isFinite(g.width) ? g.width.toFixed(1) : '']; }));
    }
    const ct = C.chainageTable(s, step);
    if (ct.length) {
      o += '<h2>' + t('চেইনেজ টেবিল', 'Chainage table') + ' (' + step + ' m)</h2>' + table(
        [t('চেইনেজ', 'Chainage'), t('অক্ষাংশ', 'Latitude'), t('দ্রাঘিমাংশ', 'Longitude'), 'Easting (m)', 'Northing (m)', t('উচ্চতা (মি)', 'Elev. (m)')],
        ct.map((r) => [C.fmtCh(r.ch), r.lat.toFixed(7), r.lon.toFixed(7), r.utm.easting.toFixed(2), r.utm.northing.toFixed(2), r.elev.toFixed(1)]));
    }
    o += '<p class="muted" style="margin-top:14px">' + t('দ্রষ্টব্য: ফোনের GPS অবস্থান সাধারণত ±৩–৫ মি এবং উচ্চতা ±৫–১০ মি নির্ভুল। ব্যাসার্ধ ও ঢাল আনুমানিক।',
      'Note: phone GPS positions are typically ±3–5 m and heights ±5–10 m. Radii and grades are approximate.') + '</p>';
    return o + '</body></html>';
  }

  const api = { build, planSvg, profileSvg };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Report = api;
})(typeof window !== 'undefined' ? window : globalThis);
