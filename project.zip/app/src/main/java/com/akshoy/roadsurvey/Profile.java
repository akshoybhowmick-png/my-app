package com.akshoy.roadsurvey;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

import java.util.List;
import java.util.Locale;

/** Elevation (height) profile of the road: smoothing, statistics and drawing. */
public class Profile {

    public static class Stats {
        public double minAlt, maxAlt, startAlt, endAlt, rise, fall, avgGrade, maxGrade;
        public boolean valid;
    }

    /** Moving-average smoothing of GPS height (phone GPS height jumps a lot). */
    public static double[] smooth(List<TrackStore.Pt> pts) {
        int n = pts.size();
        double[] out = new double[n];
        int w = 7;
        for (int i = 0; i < n; i++) {
            double s = 0;
            int c = 0;
            for (int j = Math.max(0, i - w); j <= Math.min(n - 1, i + w); j++) {
                s += pts.get(j).alt;
                c++;
            }
            out[i] = s / c;
        }
        return out;
    }

    public static Stats stats(List<TrackStore.Pt> pts) {
        Stats s = new Stats();
        if (pts.size() < 2) return s;
        double[] h = smooth(pts);
        s.minAlt = Double.MAX_VALUE;
        s.maxAlt = -Double.MAX_VALUE;
        for (int i = 0; i < h.length; i++) {
            s.minAlt = Math.min(s.minAlt, h[i]);
            s.maxAlt = Math.max(s.maxAlt, h[i]);
            if (i > 0) {
                double d = h[i] - h[i - 1];
                if (d > 0) s.rise += d;
                else s.fall -= d;
            }
        }
        s.startAlt = h[0];
        s.endAlt = h[h.length - 1];
        double len = pts.get(pts.size() - 1).ch;
        s.avgGrade = len > 0 ? (s.endAlt - s.startAlt) / len * 100 : 0;
        // steepest grade over stretches of at least 50 m
        int j = 0;
        for (int i = 0; i < pts.size(); i++) {
            while (j < pts.size() && pts.get(j).ch - pts.get(i).ch < 50) j++;
            if (j >= pts.size()) break;
            double g = Math.abs(h[j] - h[i]) / (pts.get(j).ch - pts.get(i).ch) * 100;
            s.maxGrade = Math.max(s.maxGrade, g);
        }
        s.valid = true;
        return s;
    }

    /** Draws the profile chart inside the given rectangle. Used both on screen and in the PDF. */
    public static void draw(Canvas c, RectF r, List<TrackStore.Pt> pts, double startCh, float textSize) {
        Paint axis = new Paint(Paint.ANTI_ALIAS_FLAG);
        axis.setColor(Color.rgb(120, 120, 120));
        axis.setStrokeWidth(Math.max(1f, textSize / 12f));
        Paint grid = new Paint(axis);
        grid.setColor(Color.rgb(225, 225, 225));
        Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
        label.setColor(Color.rgb(70, 70, 70));
        label.setTextSize(textSize);
        Paint lineP = new Paint(Paint.ANTI_ALIAS_FLAG);
        lineP.setColor(Color.rgb(21, 101, 192));
        lineP.setStyle(Paint.Style.STROKE);
        lineP.setStrokeWidth(textSize / 4f);
        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setColor(Color.argb(50, 21, 101, 192));
        fill.setStyle(Paint.Style.FILL);

        if (pts.size() < 2) {
            label.setTextAlign(Paint.Align.CENTER);
            c.drawText(L.t("উচ্চতা দেখাতে আগে কিছুটা রাস্তা রেকর্ড করুন", "Record some road first to see the elevation"), r.centerX(), r.centerY(), label);
            return;
        }

        double[] h = smooth(pts);
        double minH = Double.MAX_VALUE, maxH = -Double.MAX_VALUE;
        for (double v : h) {
            minH = Math.min(minH, v);
            maxH = Math.max(maxH, v);
        }
        if (maxH - minH < 10) { // keep at least 10 m range so tiny noise doesn't look like hills
            double mid = (maxH + minH) / 2;
            minH = mid - 5;
            maxH = mid + 5;
        }
        double pad = (maxH - minH) * 0.1;
        minH -= pad;
        maxH += pad;
        double len = pts.get(pts.size() - 1).ch;
        if (len <= 0) len = 1;

        float left = r.left + textSize * 3.2f, bottom = r.bottom - textSize * 1.8f;
        float right = r.right - textSize * 0.5f, top = r.top + textSize * 0.5f;
        float w = right - left, hgt = bottom - top;

        // horizontal grid + height labels
        label.setTextAlign(Paint.Align.RIGHT);
        for (int i = 0; i <= 4; i++) {
            double v = minH + (maxH - minH) * i / 4.0;
            float y = (float) (bottom - hgt * i / 4.0);
            c.drawLine(left, y, right, y, grid);
            c.drawText(String.format(Locale.US, L.t("%.0f মি", "%.0f m"), v), left - textSize * 0.3f, y + textSize * 0.35f, label);
        }
        // chainage labels
        label.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i <= 4; i++) {
            float x = left + w * i / 4f;
            c.drawLine(x, top, x, bottom, grid);
            c.drawText(TrackStore.fmtCh(startCh + len * i / 4.0), x, bottom + textSize * 1.3f, label);
        }
        c.drawLine(left, bottom, right, bottom, axis);
        c.drawLine(left, top, left, bottom, axis);

        Path path = new Path();
        Path area = new Path();
        for (int i = 0; i < pts.size(); i++) {
            float x = (float) (left + w * pts.get(i).ch / len);
            float y = (float) (bottom - hgt * (h[i] - minH) / (maxH - minH));
            if (i == 0) {
                path.moveTo(x, y);
                area.moveTo(x, bottom);
                area.lineTo(x, y);
            } else {
                path.lineTo(x, y);
                area.lineTo(x, y);
            }
        }
        area.lineTo(right, bottom);
        area.close();
        c.drawPath(area, fill);
        c.drawPath(path, lineP);
    }

    /** On-screen chart view. */
    public static class ChartView extends View {
        private final List<TrackStore.Pt> pts;
        private final double startCh;

        public ChartView(Context ctx, List<TrackStore.Pt> pts, double startCh) {
            super(ctx);
            this.pts = pts;
            this.startCh = startCh;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float ts = 11 * getResources().getDisplayMetrics().scaledDensity;
            Profile.draw(canvas, new RectF(0, 0, getWidth(), getHeight()), pts, startCh, ts);
        }
    }
}
