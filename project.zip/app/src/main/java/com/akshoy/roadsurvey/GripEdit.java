package com.akshoy.roadsurvey;

import java.util.ArrayList;
import java.util.List;

/**
 * Grip editing of the recorded alignment.
 * 1) simplify(): picks a manageable set of "grips" that keep the line's shape (Douglas–Peucker).
 * 2) rebuild(): after grips are moved / added / removed, every original GPS point is placed on the
 *    edited line at the same relative position, so time, height, video sync and chainage stay consistent.
 */
public class GripEdit {

    public static class Vertex {
        public double lat, lon;
        public int orig; // index of the original GPS point, -1 for a grip added by the user

        public Vertex(double lat, double lon, int orig) {
            this.lat = lat;
            this.lon = lon;
            this.orig = orig;
        }

        public Vertex copy() {
            return new Vertex(lat, lon, orig);
        }
    }

    /** Grips for a track: few on straights, more on bends. At most maxGrips. */
    public static List<Vertex> simplify(List<TrackStore.Pt> pts, int maxGrips) {
        double tol = 1.0;
        List<Integer> keep;
        while (true) {
            keep = douglasPeucker(pts, tol);
            if (keep.size() <= maxGrips || tol > 200) break;
            tol *= 1.5;
        }
        List<Vertex> out = new ArrayList<>();
        for (int i : keep) out.add(new Vertex(pts.get(i).lat, pts.get(i).lon, i));
        return out;
    }

    private static List<Integer> douglasPeucker(List<TrackStore.Pt> pts, double tol) {
        int n = pts.size();
        boolean[] keep = new boolean[n];
        keep[0] = true;
        keep[n - 1] = true;
        double lat0 = pts.get(0).lat;
        double k = Math.cos(Math.toRadians(lat0)) * 111320.0, m = 111320.0;
        double[] x = new double[n], y = new double[n];
        for (int i = 0; i < n; i++) {
            x[i] = pts.get(i).lon * k;
            y[i] = pts.get(i).lat * m;
        }
        int[] stack = new int[2 * n + 4];
        int sp = 0;
        stack[sp++] = 0;
        stack[sp++] = n - 1;
        while (sp > 0) {
            int b = stack[--sp], a = stack[--sp];
            if (b - a < 2) continue;
            double best = -1;
            int bi = -1;
            for (int i = a + 1; i < b; i++) {
                double d = segDist(x[i], y[i], x[a], y[a], x[b], y[b]);
                if (d > best) {
                    best = d;
                    bi = i;
                }
            }
            if (best > tol && bi > 0) {
                keep[bi] = true;
                stack[sp++] = a;
                stack[sp++] = bi;
                stack[sp++] = bi;
                stack[sp++] = b;
            }
        }
        List<Integer> out = new ArrayList<>();
        for (int i = 0; i < n; i++) if (keep[i]) out.add(i);
        return out;
    }

    private static double segDist(double px, double py, double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
        double t = l2 < 1e-12 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l2));
        double qx = ax + t * dx - px, qy = ay + t * dy - py;
        return Math.sqrt(qx * qx + qy * qy);
    }

    /** Index of the segment (between vertex i and i+1) nearest to a tapped point. */
    public static int nearestSegment(List<Vertex> v, double lat, double lon) {
        double k = Math.cos(Math.toRadians(lat)) * 111320.0, m = 111320.0;
        double best = Double.MAX_VALUE;
        int bi = 0;
        for (int i = 0; i + 1 < v.size(); i++) {
            double d = segDist(lon * k, lat * m, v.get(i).lon * k, v.get(i).lat * m,
                    v.get(i + 1).lon * k, v.get(i + 1).lat * m);
            if (d < best) {
                best = d;
                bi = i;
            }
        }
        return bi;
    }

    /**
     * Rebuilds the dense track on the edited line. Each original point keeps its time, height and
     * accuracy; its position moves along the edited path between its neighbouring anchor grips.
     */
    public static List<TrackStore.Pt> rebuild(List<TrackStore.Pt> pts, List<Vertex> verts) {
        List<TrackStore.Pt> out = new ArrayList<>();
        // anchors = grips that came from an original point, in order
        List<Integer> anchorPos = new ArrayList<>();
        for (int i = 0; i < verts.size(); i++) if (verts.get(i).orig >= 0) anchorPos.add(i);
        if (anchorPos.size() < 2) return new ArrayList<>(pts);
        // points before the first anchor / after the last (only if first/last grip was deleted)
        int firstIdx = verts.get(anchorPos.get(0)).orig;
        for (int j = 0; j < firstIdx; j++) out.add(copyAt(pts.get(j), verts.get(anchorPos.get(0)).lat, verts.get(anchorPos.get(0)).lon));

        for (int a = 0; a + 1 < anchorPos.size(); a++) {
            int va = anchorPos.get(a), vb = anchorPos.get(a + 1);
            int ia = verts.get(va).orig, ib = verts.get(vb).orig;
            if (ib <= ia) continue;
            // the edited path from anchor A to anchor B through any user-added grips
            List<double[]> path = new ArrayList<>();
            for (int q = va; q <= vb; q++) path.add(new double[]{verts.get(q).lat, verts.get(q).lon});
            double[] cum = new double[path.size()];
            for (int q = 1; q < path.size(); q++) {
                cum[q] = cum[q - 1] + TrackStore.distance(path.get(q - 1)[0], path.get(q - 1)[1], path.get(q)[0], path.get(q)[1]);
            }
            double pathLen = cum[cum.length - 1];
            double chA = pts.get(ia).ch, chB = pts.get(ib).ch;
            int last = (a + 2 == anchorPos.size()) ? ib : ib - 1; // B itself is written by the next span
            for (int j = ia; j <= last; j++) {
                double f = chB - chA < 1e-9 ? (double) (j - ia) / Math.max(1, ib - ia) : (pts.get(j).ch - chA) / (chB - chA);
                double target = Math.max(0, Math.min(1, f)) * pathLen;
                int q = 1;
                while (q < cum.length - 1 && cum[q] < target) q++;
                double seg = cum[q] - cum[q - 1];
                double t = seg < 1e-9 ? 0 : (target - cum[q - 1]) / seg;
                double lat = path.get(q - 1)[0] + (path.get(q)[0] - path.get(q - 1)[0]) * t;
                double lon = path.get(q - 1)[1] + (path.get(q)[1] - path.get(q - 1)[1]) * t;
                out.add(copyAt(pts.get(j), lat, lon));
            }
        }
        int lastIdx = verts.get(anchorPos.get(anchorPos.size() - 1)).orig;
        Vertex lv = verts.get(anchorPos.get(anchorPos.size() - 1));
        for (int j = lastIdx + 1; j < pts.size(); j++) out.add(copyAt(pts.get(j), lv.lat, lv.lon));

        // chainage along the edited line
        for (int i = 0; i < out.size(); i++) {
            TrackStore.Pt p = out.get(i);
            p.ch = i == 0 ? 0 : out.get(i - 1).ch + TrackStore.distance(out.get(i - 1).lat, out.get(i - 1).lon, p.lat, p.lon);
        }
        return out;
    }

    private static TrackStore.Pt copyAt(TrackStore.Pt src, double lat, double lon) {
        TrackStore.Pt p = new TrackStore.Pt();
        p.lat = lat;
        p.lon = lon;
        p.alt = src.alt;
        p.acc = src.acc;
        p.time = src.time;
        p.ch = src.ch;
        return p;
    }
}
