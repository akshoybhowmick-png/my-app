package com.akshoy.roadsurvey;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** User-adjustable settings, stored on the phone. */
public class AppSettings {

    public static final String DEVELOPER = "Developed by Akshoy Bhowmick";

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    // ----- values with defaults -----
    public static int maxAccuracy(Context c) { return p(c).getInt("maxAcc", 25); }
    public static int minStep(Context c) { return p(c).getInt("minStep", 3); }
    public static int tickStep(Context c) { return p(c).getInt("tickStep", 100); }
    public static int videoQuality(Context c) { return p(c).getInt("videoQ", 720); }
    public static boolean videoAudio(Context c) { return p(c).getBoolean("videoAudio", true); }
    public static boolean videoLandscape(Context c) { return p(c).getBoolean("videoLand", true); }
    public static boolean askPhoto(Context c) { return p(c).getBoolean("askPhoto", true); }
    public static boolean keepScreenOn(Context c) { return p(c).getBoolean("screenOn", false); }
    public static boolean satelliteDefault(Context c) { return p(c).getBoolean("satDefault", false); }
    public static boolean driftFilter(Context c) { return p(c).getBoolean("driftFilter", true); }
    /** 0 = off, 1 = light, 2 = medium, 3 = strong */
    public static int smoothing(Context c) { return p(c).getInt("smoothing", 2); }
    private static final String[] SMOOTH_LABELS = {"বন্ধ", "হালকা", "মাঝারি", "বেশি"};

    private static void putInt(Context c, String k, int v) { p(c).edit().putInt(k, v).apply(); }
    private static void putBool(Context c, String k, boolean v) { p(c).edit().putBoolean(k, v).apply(); }

    public interface OnChanged {
        void onSettingsChanged();
    }

    /** Main settings dialog. */
    public static void show(final Activity a, final OnChanged cb) {
        String[] items = {
                "📶  GPS নির্ভুলতার সীমা: " + maxAccuracy(a) + " মি",
                "📏  পয়েন্টের মাঝে কম দূরত্ব: " + minStep(a) + " মি",
                "🧍  দাঁড়িয়ে থাকলে জিগজ্যাগ আটকানো: " + (driftFilter(a) ? "চালু" : "বন্ধ"),
                "〰  চলার সময় লাইন মসৃণ করা: " + SMOOTH_LABELS[Math.max(0, Math.min(3, smoothing(a)))],
                "🏷  ম্যাপে চেইনেজ দাগ: প্রতি " + tickStep(a) + " মি",
                "🎥  ভিডিও কোয়ালিটি: " + videoQuality(a) + "p",
                "🎤  ভিডিওতে শব্দ: " + (videoAudio(a) ? "চালু" : "বন্ধ"),
                "🔄  ভিডিওর দিক: " + (videoLandscape(a) ? "আড়াআড়ি (Landscape)" : "খাড়া (Portrait)"),
                "📷  পয়েন্টের পর ছবির কথা জিজ্ঞেস: " + (askPhoto(a) ? "হ্যাঁ" : "না"),
                "💡  রেকর্ডের সময় স্ক্রিন জ্বালিয়ে রাখা: " + (keepScreenOn(a) ? "হ্যাঁ" : "না"),
                "🛰  শুরুতে স্যাটেলাইট ম্যাপ: " + (satelliteDefault(a) ? "হ্যাঁ" : "না"),
                "🏷  ট্যাগ তালিকা সাজান",
                "ℹ  অ্যাপ সম্পর্কে",
        };
        new AlertDialog.Builder(a)
                .setTitle("⚙ সেটিংস")
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            choose(a, "GPS নির্ভুলতার সীমা", new int[]{10, 15, 25, 50}, " মি",
                                    "এর চেয়ে খারাপ GPS রিডিং বাদ যাবে। কম রাখলে লাইন পরিষ্কার, কিন্তু গাছপালার নিচে পয়েন্ট কম আসতে পারে।",
                                    maxAccuracy(a), v -> { putInt(a, "maxAcc", v); reopen(a, cb); });
                            break;
                        case 1:
                            choose(a, "পয়েন্টের মাঝে কম দূরত্ব", new int[]{1, 2, 3, 5, 10}, " মি",
                                    "এতটা না সরলে নতুন পয়েন্ট সেভ হবে না (দাঁড়িয়ে থাকলে লাইন কাঁপবে না)।",
                                    minStep(a), v -> { putInt(a, "minStep", v); reopen(a, cb); });
                            break;
                        case 2:
                            putBool(a, "driftFilter", !driftFilter(a));
                            reopen(a, cb);
                            break;
                        case 3:
                            new AlertDialog.Builder(a)
                                    .setTitle("লাইন মসৃণ করা")
                                    .setSingleChoiceItems(SMOOTH_LABELS, smoothing(a), (d2, w2) -> {
                                        d2.dismiss();
                                        putInt(a, "smoothing", w2);
                                        reopen(a, cb);
                                    })
                                    .setNegativeButton("বাতিল", null)
                                    .show();
                            break;
                        case 4:
                            choose(a, "ম্যাপে চেইনেজ দাগ", new int[]{50, 100, 200, 500}, " মি",
                                    "কাছে জুম করলে এই দূরত্ব পরপর চেইনেজ লেখা দেখাবে। প্রতি কিমি সবসময় দেখাবে।",
                                    tickStep(a), v -> { putInt(a, "tickStep", v); reopen(a, cb); });
                            break;
                        case 5:
                            choose(a, "ভিডিও কোয়ালিটি", new int[]{480, 720, 1080}, "p",
                                    "480p ≈ ৩০ MB/মিনিট, 720p ≈ ৬০ MB/মিনিট, 1080p ≈ ১২০ MB/মিনিট।",
                                    videoQuality(a), v -> { putInt(a, "videoQ", v); reopen(a, cb); });
                            break;
                        case 6:
                            putBool(a, "videoAudio", !videoAudio(a));
                            reopen(a, cb);
                            break;
                        case 7:
                            putBool(a, "videoLand", !videoLandscape(a));
                            reopen(a, cb);
                            break;
                        case 8:
                            putBool(a, "askPhoto", !askPhoto(a));
                            reopen(a, cb);
                            break;
                        case 9:
                            putBool(a, "screenOn", !keepScreenOn(a));
                            reopen(a, cb);
                            break;
                        case 10:
                            putBool(a, "satDefault", !satelliteDefault(a));
                            reopen(a, cb);
                            break;
                        case 11:
                            Tags.manage(a);
                            break;
                        default:
                            about(a);
                    }
                })
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    private static void reopen(Activity a, OnChanged cb) {
        if (cb != null) cb.onSettingsChanged();
        show(a, cb);
    }

    private interface IntPicked {
        void picked(int v);
    }

    private static void choose(Activity a, String title, final int[] values, String unit, String help,
                               int current, final IntPicked cb) {
        String[] labels = new String[values.length];
        int checked = 0;
        for (int i = 0; i < values.length; i++) {
            labels[i] = values[i] + unit;
            if (values[i] == current) checked = i;
        }
        TextView helpView = new TextView(a);
        helpView.setText(help);
        int pad = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, a.getResources().getDisplayMetrics());
        helpView.setPadding(pad, pad / 2, pad, 0);
        new AlertDialog.Builder(a)
                .setTitle(title)
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    d.dismiss();
                    cb.picked(values[which]);
                })
                .setView(helpView)
                .setNegativeButton("বাতিল", null)
                .show();
    }

    public static void about(Activity a) {
        String version = "";
        try {
            version = a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        int pad = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 24, a.getResources().getDisplayMetrics());
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(pad, pad, pad, pad / 2);

        TextView t1 = new TextView(a);
        t1.setText("রোড সার্ভে");
        t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        t1.setTypeface(Typeface.DEFAULT_BOLD);
        t1.setGravity(Gravity.CENTER);
        TextView t2 = new TextView(a);
        t2.setText("GPS Road Alignment Survey\nসংস্করণ " + version);
        t2.setGravity(Gravity.CENTER);
        t2.setPadding(0, pad / 3, 0, pad / 2);
        TextView t3 = new TextView(a);
        t3.setText(DEVELOPER);
        t3.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        t3.setTypeface(Typeface.DEFAULT_BOLD);
        t3.setTextColor(0xFF1565C0);
        t3.setGravity(Gravity.CENTER);
        TextView t4 = new TextView(a);
        t4.setText("\nম্যাপ: © OpenStreetMap contributors\nস্যাটেলাইট: Esri World Imagery");
        t4.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t4.setGravity(Gravity.CENTER);
        box.addView(t1);
        box.addView(t2);
        box.addView(t3);
        box.addView(t4);
        new AlertDialog.Builder(a).setView(box).setPositiveButton("ঠিক আছে", null).show();
    }
}
