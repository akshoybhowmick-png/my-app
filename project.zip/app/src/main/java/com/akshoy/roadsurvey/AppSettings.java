package com.akshoy.roadsurvey;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** User-adjustable settings, stored on the phone. */
public class AppSettings {

    public static final String DEVELOPER = "Developed by Akshoy Bhowmick";

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    // ----- values with defaults -----
    public static int maxAccuracy(Context c) { return p(c).getInt("maxAcc", 25); }
    public static int minStep(Context c) { return p(c).getInt("minStep", 3); }
    public static int tickStep(Context c) { return p(c).getInt("tickStep", 100); }
    public static int videoQuality(Context c) { return p(c).getInt("videoQ", 720); }
    public static boolean videoAudio(Context c) { return p(c).getBoolean("videoAudio", true); }
    public static boolean videoLandscape(Context c) { return p(c).getBoolean("videoLand", true); }
    public static boolean askPhoto(Context c) { return p(c).getBoolean("askPhoto", true); }
    public static boolean keepScreenOn(Context c) { return p(c).getBoolean("screenOn", false); }
    public static boolean satelliteDefault(Context c) { return p(c).getBoolean("satDefault", false); }
    public static boolean driftFilter(Context c) { return p(c).getBoolean("driftFilter", true); }
    public static boolean photoStamp(Context c) { return p(c).getBoolean("photoStamp", true); }
    /** 0 = off, 1 = light, 2 = medium, 3 = strong */
    public static int smoothing(Context c) { return p(c).getInt("smoothing", 2); }
    private static String[] smoothLabels() { return new String[]{L.t("বন্ধ", "Off"), L.t("হালকা", "Light"), L.t("মাঝারি", "Medium"), L.t("বেশি", "Strong")}; }

    private static void putInt(Context c, String k, int v) { p(c).edit().putInt(k, v).apply(); }
    private static void putBool(Context c, String k, boolean v) { p(c).edit().putBoolean(k, v).apply(); }

    public interface OnChanged {
        void onSettingsChanged();
    }

    /** Main settings dialog. */
    public static void show(final Activity a, final OnChanged cb) {
        String[] items = {
                "🌐  ভাষা / Language: " + (L.isEnglish() ? "English" : "বাংলা"),
                L.t("📶  GPS নির্ভুলতার সীমা: ", "📶  GPS accuracy limit: ") + maxAccuracy(a) + L.t(" মি", " m"),
                L.t("📏  পয়েন্টের মাঝে কম দূরত্ব: ", "📏  Minimum distance between points: ") + minStep(a) + L.t(" মি", " m"),
                L.t("🧍  দাঁড়িয়ে থাকলে জিগজ্যাগ আটকানো: ", "🧍  Stop zig-zag while standing: ") + (driftFilter(a) ? L.t("চালু", "On") : L.t("বন্ধ", "Off")),
                L.t("〰  চলার সময় লাইন মসৃণ করা: ", "〰  Smooth the line while moving: ") + smoothLabels()[Math.max(0, Math.min(3, smoothing(a)))],
                L.t("🏷  ম্যাপে চেইনেজ দাগ: প্রতি ", "🏷  Chainage labels on map: every ") + tickStep(a) + L.t(" মি", " m"),
                L.t("🎥  ভিডিও কোয়ালিটি: ", "🎥  Video quality: ") + videoQuality(a) + "p",
                L.t("🎤  ভিডিওতে শব্দ: ", "🎤  Sound in video: ") + (videoAudio(a) ? L.t("চালু", "On") : L.t("বন্ধ", "Off")),
                L.t("🔄  ভিডিওর দিক: ", "🔄  Video orientation: ") + (videoLandscape(a) ? L.t("আড়াআড়ি (Landscape)", "Landscape") : L.t("খাড়া (Portrait)", "Portrait")),
                L.t("📷  পয়েন্টের পর ছবির কথা জিজ্ঞেস: ", "📷  Ask for a photo after marking: ") + (askPhoto(a) ? L.t("হ্যাঁ", "Yes") : L.t("না", "No")),
                L.t("🏷  ছবিতে চেইনেজ-স্থানাঙ্ক লেখা (স্ট্যাম্প): ", "🏷  Stamp chainage & coordinates on photos: ") + (photoStamp(a) ? L.t("হ্যাঁ", "Yes") : L.t("না", "No")),
                L.t("💡  রেকর্ডের সময় স্ক্রিন জ্বালিয়ে রাখা: ", "💡  Keep screen on while recording: ") + (keepScreenOn(a) ? L.t("হ্যাঁ", "Yes") : L.t("না", "No")),
                L.t("🛰  শুরুতে স্যাটেলাইট ম্যাপ: ", "🛰  Start with satellite map: ") + (satelliteDefault(a) ? L.t("হ্যাঁ", "Yes") : L.t("না", "No")),
                L.t("🏷  ট্যাগ তালিকা সাজান", "🏷  Edit tag list"),
                L.t("ℹ  অ্যাপ সম্পর্কে", "ℹ  About the app"),
        };
        new AlertDialog.Builder(a)
                .setTitle(L.t("⚙ সেটিংস", "⚙ Settings"))
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            new AlertDialog.Builder(a)
                                    .setTitle("ভাষা / Language")
                                    .setSingleChoiceItems(new String[]{"বাংলা", "English"}, L.isEnglish() ? 1 : 0,
                                            (d2, w2) -> {
                                                d2.dismiss();
                                                boolean en = w2 == 1;
                                                if (en != L.isEnglish()) {
                                                    L.set(a, en);
                                                    a.recreate(); // redraw every button in the new language
                                                }
                                            })
                                    .show();
                            break;
                        case 1:
                            choose(a, L.t("GPS নির্ভুলতার সীমা", "GPS accuracy limit"), new int[]{10, 15, 25, 50}, L.t(" মি", " m"),
                                    L.t("এর চেয়ে খারাপ GPS রিডিং বাদ যাবে। কম রাখলে লাইন পরিষ্কার, কিন্তু গাছপালার নিচে পয়েন্ট কম আসতে পারে।", "GPS readings worse than this are ignored. Lower = cleaner line, but fewer points under trees."),
                                    maxAccuracy(a), v -> { putInt(a, "maxAcc", v); reopen(a, cb); });
                            break;
                        case 2:
                            choose(a, L.t("পয়েন্টের মাঝে কম দূরত্ব", "Minimum distance between points"), new int[]{1, 2, 3, 5, 10}, L.t(" মি", " m"),
                                    L.t("এতটা না সরলে নতুন পয়েন্ট সেভ হবে না (দাঁড়িয়ে থাকলে লাইন কাঁপবে না)।", "A new point is saved only after moving this far (the line won't shake while standing)."),
                                    minStep(a), v -> { putInt(a, "minStep", v); reopen(a, cb); });
                            break;
                        case 3:
                            putBool(a, "driftFilter", !driftFilter(a));
                            reopen(a, cb);
                            break;
                        case 4:
                            new AlertDialog.Builder(a)
                                    .setTitle(L.t("লাইন মসৃণ করা", "Line smoothing"))
                                    .setSingleChoiceItems(smoothLabels(), smoothing(a), (d2, w2) -> {
                                        d2.dismiss();
                                        putInt(a, "smoothing", w2);
                                        reopen(a, cb);
                                    })
                                    .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                                    .show();
                            break;
                        case 5:
                            choose(a, L.t("ম্যাপে চেইনেজ দাগ", "Chainage labels on map"), new int[]{50, 100, 200, 500}, L.t(" মি", " m"),
                                    L.t("কাছে জুম করলে এই দূরত্ব পরপর চেইনেজ লেখা দেখাবে। প্রতি কিমি সবসময় দেখাবে।", "When zoomed in, chainage is shown at this spacing. Every km is always shown."),
                                    tickStep(a), v -> { putInt(a, "tickStep", v); reopen(a, cb); });
                            break;
                        case 6:
                            choose(a, L.t("ভিডিও কোয়ালিটি", "Video quality"), new int[]{480, 720, 1080}, "p",
                                    L.t("480p ≈ ৩০ MB/মিনিট, 720p ≈ ৬০ MB/মিনিট, 1080p ≈ ১২০ MB/মিনিট।", "480p ≈ 30 MB/min, 720p ≈ 60 MB/min, 1080p ≈ 120 MB/min."),
                                    videoQuality(a), v -> { putInt(a, "videoQ", v); reopen(a, cb); });
                            break;
                        case 7:
                            putBool(a, "videoAudio", !videoAudio(a));
                            reopen(a, cb);
                            break;
                        case 8:
                            putBool(a, "videoLand", !videoLandscape(a));
                            reopen(a, cb);
                            break;
                        case 9:
                            putBool(a, "askPhoto", !askPhoto(a));
                            reopen(a, cb);
                            break;
                        case 10:
                            putBool(a, "photoStamp", !photoStamp(a));
                            reopen(a, cb);
                            break;
                        case 11:
                            putBool(a, "screenOn", !keepScreenOn(a));
                            reopen(a, cb);
                            break;
                        case 12:
                            putBool(a, "satDefault", !satelliteDefault(a));
                            reopen(a, cb);
                            break;
                        case 13:
                            Tags.manage(a);
                            break;
                        default:
                            about(a);
                    }
                })
                .setNegativeButton(L.t("বন্ধ", "Close"), null)
                .show();
    }

    private static void reopen(Activity a, OnChanged cb) {
        if (cb != null) cb.onSettingsChanged();
        show(a, cb);
    }

    private interface IntPicked {
        void picked(int v);
    }

    private static void choose(Activity a, String title, final int[] values, String unit, String help,
                               int current, final IntPicked cb) {
        String[] labels = new String[values.length];
        int checked = 0;
        for (int i = 0; i < values.length; i++) {
            labels[i] = values[i] + unit;
            if (values[i] == current) checked = i;
        }
        TextView helpView = new TextView(a);
        helpView.setText(help);
        int pad = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, a.getResources().getDisplayMetrics());
        helpView.setPadding(pad, pad / 2, pad, 0);
        new AlertDialog.Builder(a)
                .setTitle(title)
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    d.dismiss();
                    cb.picked(values[which]);
                })
                .setView(helpView)
                .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                .show();
    }

    public static void about(Activity a) {
        String version = "";
        try {
            version = a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        int pad = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 24, a.getResources().getDisplayMetrics());
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(pad, pad, pad, pad / 2);

        TextView t1 = new TextView(a);
        t1.setText(L.t("রোড সার্ভে", "Road Survey"));
        t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        t1.setTypeface(Typeface.DEFAULT_BOLD);
        t1.setGravity(Gravity.CENTER);
        TextView t2 = new TextView(a);
        t2.setText(L.t("GPS Road Alignment Survey\nসংস্করণ ", "GPS Road Alignment Survey\nVersion ") + version);
        t2.setGravity(Gravity.CENTER);
        t2.setPadding(0, pad / 3, 0, pad / 2);
        TextView t3 = new TextView(a);
        t3.setText(DEVELOPER);
        t3.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        t3.setTypeface(Typeface.DEFAULT_BOLD);
        t3.setTextColor(0xFF1565C0);
        t3.setGravity(Gravity.CENTER);
        TextView t4 = new TextView(a);
        t4.setText(L.t("\nম্যাপ: © OpenStreetMap contributors\nস্যাটেলাইট: Esri World Imagery", "\nMap: © OpenStreetMap contributors\nSatellite: Esri World Imagery"));
        t4.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        t4.setGravity(Gravity.CENTER);
        box.addView(t1);
        box.addView(t2);
        box.addView(t3);
        box.addView(t4);
        new AlertDialog.Builder(a).setView(box).setPositiveButton(L.t("ঠিক আছে", "OK"), null).show();
    }
}
