package com.akshoy.roadsurvey;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.InputStream;

/** Photos are saved in the phone gallery under Pictures/RoadSurvey. */
public class Photos {

    /** Creates an empty gallery entry the camera app can write into. Returns null on failure. */
    public static Uri newPhotoUri(Context c, String fileName) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + Exporter.FOLDER);
            }
            return c.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
        } catch (Exception e) {
            return null;
        }
    }

    /** Saves a bitmap (e.g. a frame grabbed from the video preview) to the gallery. Returns uri or null. */
    public static String saveBitmap(Context c, String fileName, Bitmap b) {
        Uri uri = newPhotoUri(c, fileName);
        if (uri == null) return null;
        try (java.io.OutputStream os = c.getContentResolver().openOutputStream(uri)) {
            if (os == null) throw new java.io.IOException("no stream");
            b.compress(Bitmap.CompressFormat.JPEG, 90, os);
            return uri.toString();
        } catch (Exception e) {
            delete(c, uri);
            return null;
        }
    }

    /** The photo's file name as seen in the gallery (e.g. Road_3_20261008.jpg), or "" if unknown. */
    public static String displayName(Context c, String uriString) {
        if (uriString == null || uriString.isEmpty()) return "";
        try {
            Uri uri = Uri.parse(uriString);
            if ("file".equals(uri.getScheme())) return uri.getLastPathSegment();
            try (android.database.Cursor cur = c.getContentResolver().query(uri,
                    new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cur != null && cur.moveToFirst()) {
                    String n = cur.getString(0);
                    if (n != null) return n;
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    /** Text lines printed on survey photos (geo-tag stamp). */
    public static String[] stampLines(String surveyName, String markName, String chainage,
                                      double lat, double lon, long time) {
        Geo.Utm u = Geo.utm(lat, lon);
        return new String[]{
                markName + "   |   Ch " + chainage,
                String.format(java.util.Locale.US, "%.6f, %.6f   |   UTM %s %.1f E %.1f N",
                        lat, lon, u.zoneLabel(), u.easting, u.northing),
                new java.text.SimpleDateFormat("dd-MM-yyyy HH:mm:ss", java.util.Locale.US)
                        .format(new java.util.Date(time)) + "   |   " + surveyName,
                AppSettings.DEVELOPER};
    }

    /** Draws the stamp in a dark box at the bottom of the (mutable) bitmap. */
    public static void drawStamp(Bitmap b, String[] lines) {
        android.graphics.Canvas c = new android.graphics.Canvas(b);
        float size = Math.max(14f, Math.min(b.getWidth(), b.getHeight()) / 32f);
        android.graphics.Paint text = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        text.setColor(android.graphics.Color.WHITE);
        text.setTextSize(size);
        text.setShadowLayer(size / 8f, 0, 0, android.graphics.Color.BLACK);
        android.graphics.Paint dev = new android.graphics.Paint(text);
        dev.setTextSize(size * 0.75f);
        dev.setColor(android.graphics.Color.rgb(144, 202, 249));
        float pad = size * 0.6f, lh = size * 1.3f;
        float boxH = pad * 2 + lh * (lines.length - 1) + size * 0.95f;
        android.graphics.Paint bg = new android.graphics.Paint();
        bg.setColor(android.graphics.Color.argb(150, 0, 0, 0));
        c.drawRect(0, b.getHeight() - boxH, b.getWidth(), b.getHeight(), bg);
        float y = b.getHeight() - boxH + pad + size;
        for (int i = 0; i < lines.length; i++) {
            boolean last = i == lines.length - 1;
            c.drawText(lines[i], pad, y, last ? dev : text);
            y += lh;
        }
    }

    /** Re-saves a gallery photo with the stamp drawn on it (photo is resized to max 2560 px). */
    public static boolean stampPhoto(Context c, String uriString, String[] lines) {
        Bitmap src = load(c, uriString, 2560);
        if (src == null) return false;
        Bitmap b = src.isMutable() ? src : src.copy(Bitmap.Config.ARGB_8888, true);
        if (b != src) src.recycle();
        if (b == null) return false;
        drawStamp(b, lines);
        try (java.io.OutputStream os = c.getContentResolver().openOutputStream(Uri.parse(uriString), "wt")) {
            if (os == null) return false;
            b.compress(Bitmap.CompressFormat.JPEG, 90, os);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            b.recycle();
        }
    }

    public static void delete(Context c, Uri uri) {
        try {
            c.getContentResolver().delete(uri, null, null);
        } catch (Exception ignored) {
        }
    }

    /** Loads a photo scaled down so its longest side is about maxSide pixels, rotated upright. */
    public static Bitmap load(Context c, String uriString, int maxSide) {
        if (uriString == null || uriString.isEmpty()) return null;
        try {
            Uri uri = Uri.parse(uriString);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= maxSide) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap b;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                b = BitmapFactory.decodeStream(in, null, o2);
            }
            if (b == null) return null;

            int rotate = 0;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                if (in != null) {
                    ExifInterface exif = new ExifInterface(in);
                    int or = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    if (or == ExifInterface.ORIENTATION_ROTATE_90) rotate = 90;
                    else if (or == ExifInterface.ORIENTATION_ROTATE_180) rotate = 180;
                    else if (or == ExifInterface.ORIENTATION_ROTATE_270) rotate = 270;
                }
            } catch (Exception ignored) {
            }

            float scale = Math.min(1f, (float) maxSide / Math.max(b.getWidth(), b.getHeight()));
            if (rotate != 0 || scale < 1f) {
                Matrix m = new Matrix();
                m.postScale(scale, scale);
                m.postRotate(rotate);
                Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                if (r != b) b.recycle();
                b = r;
            }
            return b;
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
    }
}
