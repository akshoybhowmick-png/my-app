package com.akshoy.roadsurvey;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.Handler;
import android.os.PowerManager;
import android.location.OnNmeaMessageListener;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Records GPS points in the background, even with the screen off. */
public class TrackingService extends Service implements LocationListener {

    private static final String CHANNEL_ID = "road_tracking";
    private static final int NOTIF_ID = 1;


    private LocationManager lm;
    private PowerManager.WakeLock wakeLock;
    private TrackStore store;
    private int sinceNotify = 0;

    // Simple Kalman filter (in metres) that smooths the GPS wobble while walking / driving.
    private double kLat, kLon, kVar = -1;

    // ----- height above sea level -----
    // Plain GPS height is measured from the WGS84 ellipsoid, which around Bengal is ~40-60 m
    // below sea level. We take sea-level height from the GPS chip's NMEA data when available,
    // otherwise (Android 14+) from Android's built-in geoid model.
    private volatile double nmeaAlt = Double.NaN;
    private volatile long nmeaTime = 0;
    private boolean nmeaSeen = false;
    private volatile double geoidOffset = Double.NaN;
    private volatile long offsetTime = 0;
    private double altF = Double.NaN; // smoothed altitude
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final OnNmeaMessageListener nmeaListener = (message, timestamp) -> parseNmea(message);

    private final android.location.GnssStatus.Callback gnssCallback = new android.location.GnssStatus.Callback() {
        @Override
        public void onSatelliteStatusChanged(android.location.GnssStatus status) {
            int used = 0, n = status.getSatelliteCount();
            for (int i = 0; i < n; i++) if (status.usedInFix(i)) used++;
            store.satUsed = used;
            store.satSeen = n;
        }
    };
    private long kTime;

    @Override
    public void onCreate() {
        super.onCreate();
        CrashLog.install(this);
        store = TrackStore.get(this);
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            // e.g. location permission was removed, or Android refused to restart us in the background
            store.tracking = false;
            store.notifyListeners();
            stopSelf();
            return START_NOT_STICKY;
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RoadSurvey:tracking");
            wakeLock.acquire();
        }

        kVar = -1; // fresh filter on every start / resume
        altF = Double.NaN;
        try {
            lm.removeNmeaListener(nmeaListener);
            lm.addNmeaListener(nmeaListener, new Handler(Looper.getMainLooper()));
        } catch (Exception ignored) {
        }
        try {
            lm.unregisterGnssStatusCallback(gnssCallback);
            lm.registerGnssStatusCallback(gnssCallback, new Handler(Looper.getMainLooper()));
        } catch (Exception ignored) {
        }
        try {
            lm.removeUpdates(this);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
            store.tracking = true;
        } catch (SecurityException | IllegalArgumentException e) {
            store.tracking = false;
            stopSelf();
        }
        store.notifyListeners();
        return START_STICKY;
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, L.t("রাস্তা রেকর্ডিং", "Road recording"),
                    NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL_ID);
        } else {
            b = new Notification.Builder(this);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return b.setContentTitle(L.t("রাস্তা রেকর্ড হচ্ছে", "Recording road"))
                .setContentText(store.name + L.t("  •  চেইনেজ ", "  •  Chainage ") + TrackStore.fmtCh(store.disp(store.length()))
                        + L.t("  •  পয়েন্ট ", "  •  Points ") + store.points.size())
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    @Override
    public void onLocationChanged(Location l) {
        store.lastAcc = l.hasAccuracy() ? l.getAccuracy() : -1f;
        store.hasFix = true;
        store.fixLat = l.getLatitude();
        store.fixLon = l.getLongitude();
        store.fixAlt = seaLevelAltitude(l);

        long now = System.currentTimeMillis();
        boolean good = !l.hasAccuracy() || l.getAccuracy() <= AppSettings.maxAccuracy(this);
        if (!good) {
            store.notifyListeners();
            return;
        }

        // ----- smoothing -----
        double lat = l.getLatitude(), lon = l.getLongitude();
        int level = AppSettings.smoothing(this);
        if (level > 0) {
            double acc = Math.max(3.0, l.hasAccuracy() ? l.getAccuracy() : 10.0);
            double qBase = level == 1 ? 4.0 : (level == 2 ? 2.5 : 1.5);   // expected wander, m/s
            double q = Math.max(qBase, l.hasSpeed() ? l.getSpeed() : 0);   // follow vehicles quickly
            if (kVar < 0) {
                kLat = lat;
                kLon = lon;
                kVar = acc * acc;
            } else {
                double dt = Math.max(0.2, (now - kTime) / 1000.0);
                kVar += dt * q * q;
                double k = kVar / (kVar + acc * acc);
                kLat += k * (lat - kLat);
                kLon += k * (lon - kLon);
                kVar = (1 - k) * kVar;
            }
            kTime = now;
            lat = kLat;
            lon = kLon;
        }

        TrackStore.Pt last = store.lastPoint();
        boolean moved = true;
        if (last != null) {
            double d = TrackStore.distance(last.lat, last.lon, lat, lon);

            // 1) Must move further than the GPS error, otherwise standing-still "drift" makes zig-zags.
            double need = AppSettings.minStep(this);
            if (AppSettings.driftFilter(this) && l.hasAccuracy()) {
                need = Math.max(need, Math.min(l.getAccuracy(), 20f) * 0.8);
            }
            moved = d >= need;

            // 2) Phone says we are not moving (speed below ~2 km/h) -> ignore position wobble.
            if (AppSettings.driftFilter(this) && l.hasSpeed() && l.getSpeed() < 0.6f) moved = false;

            // 3) Impossible jump (faster than ~250 km/h) -> a bad fix, drop it.
            double dt = Math.max(1.0, (now - last.time) / 1000.0);
            if (d / dt > 70) good = false;
        }

        if (good && moved) {
            store.addPoint(lat, lon, store.fixAlt, store.lastAcc, now);
            if (++sinceNotify >= 5) {
                sinceNotify = 0;
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                nm.notify(NOTIF_ID, buildNotification());
            }
        } else {
            store.notifyListeners();
        }
    }

    /** $GPGGA / $GNGGA ... field 9 = altitude above mean sea level (metres). */
    private void parseNmea(String msg) {
        try {
            if (msg == null || msg.length() < 7 || !msg.startsWith("$") || !msg.regionMatches(3, "GGA", 0, 3)) return;
            String[] f = msg.split(",");
            if (f.length < 11 || f[6].isEmpty() || "0".equals(f[6]) || f[9].isEmpty()) return;
            nmeaAlt = Double.parseDouble(f[9]);
            nmeaTime = System.currentTimeMillis();
            nmeaSeen = true;
        } catch (Exception ignored) {
        }
    }

    private double seaLevelAltitude(Location l) {
        long now = System.currentTimeMillis();
        double alt = Double.NaN;
        if (nmeaSeen) {
            // once the chip gives sea-level height, stick to it (avoids jumps between sources)
            if (now - nmeaTime < 5000) alt = nmeaAlt;
        } else if (Build.VERSION.SDK_INT >= 34 && l.hasMslAltitude()) {
            alt = l.getMslAltitudeMeters();
        } else if (l.hasAltitude()) {
            if (Build.VERSION.SDK_INT >= 34) {
                if (Double.isNaN(geoidOffset) || now - offsetTime > 120000) {
                    if (now - offsetTime > 10000) {
                        offsetTime = now;
                        final Location copy = new Location(l);
                        bg.submit(() -> {
                            try {
                                new android.location.altitude.AltitudeConverter()
                                        .addMslAltitudeToLocation(getApplicationContext(), copy);
                                if (copy.hasMslAltitude()) {
                                    geoidOffset = copy.getAltitude() - copy.getMslAltitudeMeters();
                                }
                            } catch (Throwable ignored) {
                            }
                        });
                    }
                }
                if (!Double.isNaN(geoidOffset)) alt = l.getAltitude() - geoidOffset;
            }
            if (Double.isNaN(alt)) alt = l.getAltitude(); // last resort: ellipsoid height
        }
        if (Double.isNaN(alt)) return Double.isNaN(altF) ? 0 : altF;

        // ignore very poor height readings, and smooth the rest (GPS height jumps a lot)
        boolean poor = Build.VERSION.SDK_INT >= 26 && l.hasVerticalAccuracy() && l.getVerticalAccuracyMeters() > 25;
        if (Double.isNaN(altF)) altF = alt;
        else if (!poor) altF += 0.2 * (alt - altF);
        return altF;
    }

    // Older Android versions need these implemented explicitly.
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
    }

    @Override
    public void onDestroy() {
        try {
            lm.removeUpdates(this);
            lm.removeNmeaListener(nmeaListener);
            lm.unregisterGnssStatusCallback(gnssCallback);
        } catch (Exception ignored) {
        }
        store.satUsed = -1;
        store.satSeen = -1;
        bg.shutdownNow();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
        store.tracking = false;
        store.notifyListeners();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
