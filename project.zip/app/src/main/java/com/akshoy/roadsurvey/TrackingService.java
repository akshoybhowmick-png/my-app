package com.akshoy.roadsurvey;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/** Records GPS points in the background, even with the screen off. */
public class TrackingService extends Service implements LocationListener {

    private static final String CHANNEL_ID = "road_tracking";
    private static final int NOTIF_ID = 1;

    /** Ignore fixes worse than this (metres). */
    private static final float MAX_ACCURACY = 25f;
    /** Only save a new point after moving at least this far (metres), to avoid jitter while standing. */
    private static final double MIN_STEP = 3.0;

    private LocationManager lm;
    private PowerManager.WakeLock wakeLock;
    private TrackStore store;
    private int sinceNotify = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        store = TrackStore.get(this);
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(NOTIF_ID, n);
        }

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RoadSurvey:tracking");
            wakeLock.acquire();
        }

        try {
            lm.removeUpdates(this);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
            store.tracking = true;
        } catch (SecurityException | IllegalArgumentException e) {
            store.tracking = false;
            stopSelf();
        }
        store.notifyListeners();
        return START_STICKY;
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "রাস্তা রেকর্ডিং",
                    NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL_ID);
        } else {
            b = new Notification.Builder(this);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return b.setContentTitle("রাস্তা রেকর্ড হচ্ছে")
                .setContentText(store.name + "  •  চেইনেজ " + TrackStore.fmtCh(store.disp(store.length()))
                        + "  •  পয়েন্ট " + store.points.size())
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    @Override
    public void onLocationChanged(Location l) {
        store.lastAcc = l.hasAccuracy() ? l.getAccuracy() : -1f;
        store.hasFix = true;
        store.fixLat = l.getLatitude();
        store.fixLon = l.getLongitude();
        if (Build.VERSION.SDK_INT >= 34 && l.hasMslAltitude()) {
            store.fixAlt = l.getMslAltitudeMeters(); // height above sea level (Android 14+)
        } else {
            store.fixAlt = l.hasAltitude() ? l.getAltitude() : 0;
        }

        boolean good = !l.hasAccuracy() || l.getAccuracy() <= MAX_ACCURACY;
        TrackStore.Pt last = store.lastPoint();
        boolean moved = last == null
                || TrackStore.distance(last.lat, last.lon, l.getLatitude(), l.getLongitude()) >= MIN_STEP;

        if (good && moved) {
            store.addPoint(l.getLatitude(), l.getLongitude(), store.fixAlt, store.lastAcc, l.getTime());
            if (++sinceNotify >= 5) {
                sinceNotify = 0;
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                nm.notify(NOTIF_ID, buildNotification());
            }
        } else {
            store.notifyListeners();
        }
    }

    // Older Android versions need these implemented explicitly.
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
    }

    @Override
    public void onDestroy() {
        try {
            lm.removeUpdates(this);
        } catch (SecurityException ignored) {
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
        store.tracking = false;
        store.notifyListeners();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
