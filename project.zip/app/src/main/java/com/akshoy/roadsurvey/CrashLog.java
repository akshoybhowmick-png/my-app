package com.akshoy.roadsurvey;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * If the app ever crashes, the error is saved; on the next start the user sees it and can
 * copy or share it, so the problem can be fixed quickly.
 */
public class CrashLog {

    private static boolean installed = false;

    private static File file(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), "last_crash.txt");
    }

    public static synchronized void install(Context ctx) {
        L.init(ctx);
        if (installed) return;
        installed = true;
        final Context app = ctx.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, ex) -> {
            try {
                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw);
                String version = "";
                try {
                    version = app.getPackageManager().getPackageInfo(app.getPackageName(), 0).versionName;
                } catch (Exception ignored) {
                }
                pw.println("RoadSurvey " + version + " | Android " + Build.VERSION.RELEASE
                        + " (API " + Build.VERSION.SDK_INT + ") | " + Build.MANUFACTURER + " " + Build.MODEL);
                pw.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())
                        + " | thread " + thread.getName());
                ex.printStackTrace(pw);
                pw.flush();
                try (FileOutputStream fos = new FileOutputStream(file(app))) {
                    fos.write(sw.toString().getBytes(StandardCharsets.UTF_8));
                }
            } catch (Throwable ignored) {
            }
            if (previous != null) previous.uncaughtException(thread, ex);
        });
    }

    /** Shows the saved error from the last crash (if any), then forgets it. */
    public static void showIfAny(final Activity a) {
        final File f = file(a);
        if (!f.exists()) return;
        String text;
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) Math.min(f.length(), 60000)];
            int n = in.read(b);
            text = new String(b, 0, Math.max(0, n), StandardCharsets.UTF_8);
        } catch (Exception e) {
            text = String.valueOf(e);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
        final String report = text;

        TextView tv = new TextView(a);
        tv.setText(report);
        tv.setTextSize(11);
        tv.setTextIsSelectable(true);
        int pad = (int) (16 * a.getResources().getDisplayMetrics().density);
        tv.setPadding(pad, pad / 2, pad, 0);
        ScrollView sv = new ScrollView(a);
        sv.addView(tv);

        new AlertDialog.Builder(a)
                .setTitle(L.t("আগেরবার অ্যাপ হঠাৎ বন্ধ হয়ে গিয়েছিল", "The app closed unexpectedly last time"))
                .setMessage(L.t("দুঃখিত! নিচের লেখাটা কপি বা শেয়ার করে পাঠালে সমস্যাটা ঠিক করা যাবে। আপনার সার্ভের ডেটা সেভ আছে।", "Sorry! Copy or share the text below and send it so the problem can be fixed. Your survey data is safe."))
                .setView(sv)
                .setPositiveButton(L.t("কপি করুন", "Copy"), (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("RoadSurvey crash", report));
                        Toast.makeText(a, L.t("কপি হয়েছে", "Copied"), Toast.LENGTH_SHORT).show();
                    }
                })
                .setNeutralButton(L.t("শেয়ার করুন", "Share"), (d, w) -> {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, report);
                    try {
                        a.startActivity(Intent.createChooser(send, L.t("ত্রুটির বিবরণ পাঠান", "Send error details")));
                    } catch (Exception ignored) {
                    }
                })
                .setNegativeButton(L.t("বন্ধ", "Off"), null)
                .show();
    }
}
