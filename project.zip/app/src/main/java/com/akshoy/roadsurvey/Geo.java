package com.akshoy.roadsurvey;

import java.util.Locale;

/** Coordinate helpers: UTM (WGS84) for engineers who work in Easting / Northing. */
public class Geo {

    public static class Utm {
        public int zone;
        public boolean north;
        public double easting, northing;

        public String zoneLabel() {
            return zone + (north ? "N" : "S");
        }

        @Override
        public String toString() {
            return String.format(Locale.US, "%s %.2f E %.2f N", zoneLabel(), easting, northing);
        }
    }

    /** WGS84 latitude/longitude → UTM (standard Transverse Mercator series, ~mm accuracy). */
    public static Utm utm(double lat, double lon) {
        double a = 6378137.0, f = 1 / 298.257223563, k0 = 0.9996;
        double e2 = f * (2 - f), ep2 = e2 / (1 - e2);
        int zone = (int) Math.floor((lon + 180) / 6) + 1;
        if (zone < 1) zone = 1;
        if (zone > 60) zone = 60;
        double lon0 = Math.toRadians((zone - 1) * 6 - 180 + 3);
        double phi = Math.toRadians(lat), lam = Math.toRadians(lon);
        double sin = Math.sin(phi), cos = Math.cos(phi), tan = Math.tan(phi);
        double N = a / Math.sqrt(1 - e2 * sin * sin);
        double T = tan * tan, C = ep2 * cos * cos, A = cos * (lam - lon0);
        double e4 = e2 * e2, e6 = e4 * e2;
        double M = a * ((1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi
                - (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * Math.sin(2 * phi)
                + (15 * e4 / 256 + 45 * e6 / 1024) * Math.sin(4 * phi)
                - (35 * e6 / 3072) * Math.sin(6 * phi));
        double x = k0 * N * (A + (1 - T + C) * Math.pow(A, 3) / 6
                + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * Math.pow(A, 5) / 120) + 500000.0;
        double y = k0 * (M + N * tan * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * Math.pow(A, 4) / 24
                + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * Math.pow(A, 6) / 720));
        Utm u = new Utm();
        u.zone = zone;
        u.north = lat >= 0;
        u.easting = x;
        u.northing = lat < 0 ? y + 10000000.0 : y;
        return u;
    }

    /** Compass bearing (0-360°, 0 = north) from point 1 to point 2. */
    public static double bearing(double lat1, double lon1, double lat2, double lon2) {
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2), dl = Math.toRadians(lon2 - lon1);
        double y = Math.sin(dl) * Math.cos(p2);
        double x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
        return (Math.toDegrees(Math.atan2(y, x)) + 360) % 360;
    }

    /** Point at a distance (m) and bearing (°) from a start point. Returns {lat, lon}. */
    public static double[] destination(double lat, double lon, double bearingDeg, double dist) {
        double r = 6371008.8, d = dist / r, b = Math.toRadians(bearingDeg);
        double p1 = Math.toRadians(lat), l1 = Math.toRadians(lon);
        double p2 = Math.asin(Math.sin(p1) * Math.cos(d) + Math.cos(p1) * Math.sin(d) * Math.cos(b));
        double l2 = l1 + Math.atan2(Math.sin(b) * Math.sin(d) * Math.cos(p1), Math.cos(d) - Math.sin(p1) * Math.sin(p2));
        return new double[]{Math.toDegrees(p2), Math.toDegrees(l2)};
    }
}
