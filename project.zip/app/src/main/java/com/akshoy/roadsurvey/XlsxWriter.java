package com.akshoy.roadsurvey;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Minimal Excel (.xlsx) writer: several sheets of text and numbers, bold first row. */
public class XlsxWriter {

    private final List<String> names = new ArrayList<>();
    private final List<List<Object[]>> sheets = new ArrayList<>();

    /** Adds a sheet. Each row is an array of String / Number (null = empty cell). First row is the header. */
    public void addSheet(String name, List<Object[]> rows) {
        String n = name.replaceAll("[\\\\/?*\\[\\]:]", " ");
        if (n.length() > 31) n = n.substring(0, 31);
        names.add(n);
        sheets.add(rows);
    }

    private static String esc(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&': b.append("&amp;"); break;
                case '<': b.append("&lt;"); break;
                case '>': b.append("&gt;"); break;
                case '"': b.append("&quot;"); break;
                default:
                    if (c < 0x20 && c != '\t' && c != '\n' && c != '\r') break; // not allowed in XML
                    b.append(c);
            }
        }
        return b.toString();
    }

    private static String col(int i) {
        StringBuilder s = new StringBuilder();
        i++;
        while (i > 0) {
            int r = (i - 1) % 26;
            s.insert(0, (char) ('A' + r));
            i = (i - 1) / 26;
        }
        return s.toString();
    }

    private static void put(ZipOutputStream z, String path, String content) throws IOException {
        z.putNextEntry(new ZipEntry(path));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    public byte[] build() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(bos)) {
            StringBuilder ct = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                    + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                    + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                    + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                    + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
            for (int i = 0; i < sheets.size(); i++) {
                ct.append("<Override PartName=\"/xl/worksheets/sheet").append(i + 1)
                        .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            }
            ct.append("</Types>");
            put(z, "[Content_Types].xml", ct.toString());

            put(z, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                    + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
                    + "</Relationships>");

            StringBuilder wb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                    + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
            StringBuilder rel = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
            for (int i = 0; i < sheets.size(); i++) {
                wb.append("<sheet name=\"").append(esc(names.get(i))).append("\" sheetId=\"").append(i + 1)
                        .append("\" r:id=\"rId").append(i + 1).append("\"/>");
                rel.append("<Relationship Id=\"rId").append(i + 1)
                        .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
                        .append(i + 1).append(".xml\"/>");
            }
            wb.append("</sheets></workbook>");
            rel.append("<Relationship Id=\"rId").append(sheets.size() + 1)
                    .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>")
                    .append("</Relationships>");
            put(z, "xl/workbook.xml", wb.toString());
            put(z, "xl/_rels/workbook.xml.rels", rel.toString());

            put(z, "xl/styles.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                    + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>"
                    + "<font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>"
                    + "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>"
                    + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                    + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                    + "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                    + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs>"
                    + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
                    + "</styleSheet>");

            for (int s = 0; s < sheets.size(); s++) {
                List<Object[]> rows = sheets.get(s);
                StringBuilder sh = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                        + "<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>"
                        + "<sheetData>");
                for (int r = 0; r < rows.size(); r++) {
                    Object[] row = rows.get(r);
                    sh.append("<row r=\"").append(r + 1).append("\">");
                    for (int c = 0; c < row.length; c++) {
                        Object v = row[c];
                        if (v == null) continue;
                        String ref = col(c) + (r + 1);
                        String style = r == 0 ? " s=\"1\"" : "";
                        if (v instanceof Number) {
                            double d = ((Number) v).doubleValue();
                            if (Double.isNaN(d) || Double.isInfinite(d)) continue;
                            sh.append("<c r=\"").append(ref).append("\"").append(style).append("><v>")
                                    .append(v instanceof Double || v instanceof Float ? String.valueOf(d) : v.toString())
                                    .append("</v></c>");
                        } else {
                            sh.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"").append(style)
                                    .append("><is><t>").append(esc(v.toString())).append("</t></is></c>");
                        }
                    }
                    sh.append("</row>");
                }
                sh.append("</sheetData></worksheet>");
                put(z, "xl/worksheets/sheet" + (s + 1) + ".xml", sh.toString());
            }
        }
        return bos.toByteArray();
    }
}
