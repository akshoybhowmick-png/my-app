package com.akshoy.roadsurvey;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

/** Builds a PDF survey report: summary + route sketch, height profile, and table of marked points with photos. */
public class Report {

    private static final int W = 595, H = 842; // A4 in points
    private static final float M = 40;         // page margin

    private final Context ctx;
    private final PdfDocument doc = new PdfDocument();
    private PdfDocument.Page page;
    private Canvas c;
    private int pageNo = 0;
    private final String title;

    private final Paint h1 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint h2 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rule = new Paint(Paint.ANTI_ALIAS_FLAG);

    private Report(Context ctx, String title) {
        this.ctx = ctx;
        this.title = title;
        h1.setTextSize(20);
        h1.setFakeBoldText(true);
        h1.setColor(Color.rgb(21, 101, 192));
        h2.setTextSize(14);
        h2.setFakeBoldText(true);
        h2.setColor(Color.rgb(33, 33, 33));
        body.setTextSize(11);
        body.setColor(Color.rgb(33, 33, 33));
        small.setTextSize(8.5f);
        small.setColor(Color.rgb(110, 110, 110));
        rule.setColor(Color.rgb(210, 210, 210));
        rule.setStrokeWidth(0.8f);
    }

    public static byte[] build(Context ctx, String name, double startCh,
                               List<TrackStore.Pt> pts, List<TrackStore.Mark> marks) throws IOException {
        Report r = new Report(ctx, name);
        r.summaryPage(startCh, pts, marks);
        r.profilePage(startCh, pts);
        r.marksPages(startCh, marks);
        return r.finish();
    }

    private void newPage() {
        if (page != null) doc.finishPage(page);
        pageNo++;
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(W, H, pageNo).create();
        page = doc.startPage(info);
        c = page.getCanvas();
        c.drawText("রাস্তা সার্ভে রিপোর্ট  •  " + title, M, H - 22, small);
        Paint right = new Paint(small);
        right.setTextAlign(Paint.Align.RIGHT);
        c.drawText("পৃষ্ঠা " + pageNo, W - M, H - 22, right);
        Paint dev = new Paint(small);
        dev.setTextAlign(Paint.Align.CENTER);
        dev.setColor(Color.rgb(21, 101, 192));
        c.drawText(AppSettings.DEVELOPER, W / 2f, H - 10, dev);
    }

    private byte[] finish() throws IOException {
        if (page != null) doc.finishPage(page);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        doc.writeTo(out);
        doc.close();
        return out.toByteArray();
    }

    private void summaryPage(double startCh, List<TrackStore.Pt> pts, List<TrackStore.Mark> marks) {
        newPage();
        float y = M + 14;
        c.drawText("রাস্তা সার্ভে রিপোর্ট", M, y, h1);
        y += 26;
        c.drawText(title, M, y, h2);
        y += 12;
        c.drawLine(M, y, W - M, y, rule);
        y += 20;

        double len = pts.isEmpty() ? 0 : pts.get(pts.size() - 1).ch;
        String from = pts.isEmpty() ? "—" : Exporter.local(pts.get(0).time);
        String to = pts.isEmpty() ? "—" : Exporter.local(pts.get(pts.size() - 1).time);
        String[][] rows = {
                {"শুরুর চেইনেজ", TrackStore.fmtCh(startCh)},
                {"শেষ চেইনেজ", TrackStore.fmtCh(startCh + len)},
                {"মোট দৈর্ঘ্য", String.format(Locale.US, "%.3f কিমি (%.1f মি)", len / 1000, len)},
                {"শুরুর অবস্থান", pts.isEmpty() ? "—" : String.format(Locale.US, "%.6f, %.6f", pts.get(0).lat, pts.get(0).lon)},
                {"শেষ অবস্থান", pts.isEmpty() ? "—" : String.format(Locale.US, "%.6f, %.6f",
                        pts.get(pts.size() - 1).lat, pts.get(pts.size() - 1).lon)},
                {"রেকর্ডের সময়", from + "  থেকে  " + to},
                {"GPS পয়েন্ট", String.valueOf(pts.size())},
                {"চিহ্নিত পয়েন্ট", String.valueOf(marks.size())},
        };
        for (String[] row : rows) {
            c.drawText(row[0], M, y, small);
            c.drawText(row[1], M + 110, y, body);
            y += 17;
        }
        y += 10;
        c.drawText("রাস্তার নকশা (উত্তর উপরে)", M, y, h2);
        y += 8;
        RectF box = new RectF(M, y, W - M, H - 50);
        Paint frame = new Paint(rule);
        frame.setStyle(Paint.Style.STROKE);
        c.drawRect(box, frame);
        box.inset(18, 18);
        drawSketch(box, startCh, pts, marks);
    }

    private void drawSketch(RectF box, double startCh, List<TrackStore.Pt> pts, List<TrackStore.Mark> marks) {
        if (pts.size() < 2) {
            Paint p = new Paint(body);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText("নকশা দেখানোর মতো যথেষ্ট পয়েন্ট নেই", box.centerX(), box.centerY(), p);
            return;
        }
        double minLat = 90, maxLat = -90, minLon = 180, maxLon = -180;
        for (TrackStore.Pt p : pts) {
            minLat = Math.min(minLat, p.lat);
            maxLat = Math.max(maxLat, p.lat);
            minLon = Math.min(minLon, p.lon);
            maxLon = Math.max(maxLon, p.lon);
        }
        final double k = Math.cos(Math.toRadians((minLat + maxLat) / 2));
        double spanX = Math.max((maxLon - minLon) * k, 1e-6);
        double spanY = Math.max(maxLat - minLat, 1e-6);
        final double scale = Math.min(box.width() / spanX, box.height() / spanY);
        final float ox = (float) (box.centerX() - spanX * scale / 2);
        final float oy = (float) (box.centerY() + spanY * scale / 2);
        final double fMinLon = minLon, fMinLat = minLat;

        Path path = new Path();
        for (int i = 0; i < pts.size(); i++) {
            float x = (float) (ox + (pts.get(i).lon - fMinLon) * k * scale);
            float y = (float) (oy - (pts.get(i).lat - fMinLat) * scale);
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        line.setColor(Color.rgb(229, 57, 53));
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2.2f);
        line.setStrokeJoin(Paint.Join.ROUND);
        c.drawPath(path, line);

        // km labels (or every 100 m on short roads)
        double len = pts.get(pts.size() - 1).ch;
        double step = len > 3000 ? 1000 : (len > 600 ? 200 : 100);
        Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
        tick.setColor(Color.rgb(21, 101, 192));
        Paint tickText = new Paint(small);
        tickText.setColor(Color.rgb(21, 101, 192));
        double next = Math.ceil(startCh / step) * step;
        for (int i = 1; i < pts.size(); i++) {
            TrackStore.Pt a = pts.get(i - 1), b = pts.get(i);
            double ca = startCh + a.ch, cb = startCh + b.ch;
            while (next <= cb) {
                if (next >= ca) {
                    double f = cb - ca < 1e-6 ? 0 : (next - ca) / (cb - ca);
                    double lat = a.lat + (b.lat - a.lat) * f, lon = a.lon + (b.lon - a.lon) * f;
                    float x = (float) (ox + (lon - fMinLon) * k * scale);
                    float y = (float) (oy - (lat - fMinLat) * scale);
                    c.drawCircle(x, y, 2.5f, tick);
                    c.drawText(TrackStore.fmtCh(next), x + 4, y - 3, tickText);
                }
                next += step;
            }
        }

        // start / end
        Paint se = new Paint(Paint.ANTI_ALIAS_FLAG);
        se.setFakeBoldText(true);
        se.setTextSize(10);
        TrackStore.Pt s = pts.get(0), e = pts.get(pts.size() - 1);
        float sx = (float) (ox + (s.lon - fMinLon) * k * scale), sy = (float) (oy - (s.lat - fMinLat) * scale);
        float ex = (float) (ox + (e.lon - fMinLon) * k * scale), ey = (float) (oy - (e.lat - fMinLat) * scale);
        se.setColor(Color.rgb(46, 125, 50));
        c.drawCircle(sx, sy, 5, se);
        c.drawText("শুরু", sx + 7, sy + 12, se);
        se.setColor(Color.rgb(183, 28, 28));
        c.drawCircle(ex, ey, 5, se);
        c.drawText("শেষ", ex + 7, ey + 12, se);

        // numbered marks
        Paint mk = new Paint(Paint.ANTI_ALIAS_FLAG);
        mk.setColor(Color.rgb(239, 108, 0));
        Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
        num.setColor(Color.WHITE);
        num.setTextSize(7.5f);
        num.setFakeBoldText(true);
        num.setTextAlign(Paint.Align.CENTER);
        int n = 1;
        for (TrackStore.Mark m : marks) {
            float x = (float) (ox + (m.lon - fMinLon) * k * scale);
            float y = (float) (oy - (m.lat - fMinLat) * scale);
            c.drawCircle(x, y, 6.5f, mk);
            c.drawText(String.valueOf(n++), x, y + 2.7f, num);
        }

        // scale bar
        double metresPerPt = 111320.0 / scale;
        double[] nice = {10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000};
        double bar = nice[0];
        for (double v : nice) if (v / metresPerPt <= box.width() / 4) bar = v;
        float bl = (float) (bar / metresPerPt);
        Paint sb = new Paint(Paint.ANTI_ALIAS_FLAG);
        sb.setColor(Color.DKGRAY);
        sb.setStrokeWidth(1.5f);
        float bx = box.left, by = box.bottom + 10;
        c.drawLine(bx, by, bx + bl, by, sb);
        c.drawLine(bx, by - 3, bx, by + 3, sb);
        c.drawLine(bx + bl, by - 3, bx + bl, by + 3, sb);
        c.drawText(bar >= 1000 ? String.format(Locale.US, "%.0f কিমি", bar / 1000)
                : String.format(Locale.US, "%.0f মি", bar), bx + bl + 5, by + 3, small);
    }

    private void profilePage(double startCh, List<TrackStore.Pt> pts) {
        newPage();
        float y = M + 14;
        c.drawText("উচ্চতা প্রোফাইল", M, y, h1);
        y += 10;
        c.drawLine(M, y, W - M, y, rule);
        y += 10;
        RectF r = new RectF(M, y, W - M, y + 300);
        Profile.draw(c, r, pts, startCh, 9);
        y += 330;

        Profile.Stats s = Profile.stats(pts);
        if (s.valid) {
            String[][] rows = {
                    {"শুরুর উচ্চতা", String.format(Locale.US, "%.1f মি", s.startAlt)},
                    {"শেষের উচ্চতা", String.format(Locale.US, "%.1f মি", s.endAlt)},
                    {"সর্বনিম্ন / সর্বোচ্চ", String.format(Locale.US, "%.1f মি / %.1f মি", s.minAlt, s.maxAlt)},
                    {"মোট চড়াই / উৎরাই", String.format(Locale.US, "%.1f মি / %.1f মি", s.rise, s.fall)},
                    {"গড় ঢাল", String.format(Locale.US, "%.2f %%", s.avgGrade)},
                    {"সবচেয়ে খাড়া ঢাল (৫০ মি অংশে)", String.format(Locale.US, "%.1f %%", s.maxGrade)},
            };
            for (String[] row : rows) {
                c.drawText(row[0], M, y, small);
                c.drawText(row[1], M + 170, y, body);
                y += 18;
            }
        }
        y += 10;
        c.drawText("দ্রষ্টব্য: ফোনের GPS-এর উচ্চতা আনুমানিক (কয়েক মিটার এদিক-ওদিক হতে পারে)।", M, y, small);
        y += 12;
        c.drawText("সঠিক লেভেলের জন্য লেভেল মেশিন / টোটাল স্টেশন দিয়ে মিলিয়ে নিন।", M, y, small);
    }

    private void marksPages(double startCh, List<TrackStore.Mark> marks) {
        newPage();
        float y = M + 14;
        c.drawText("চিহ্নিত পয়েন্টের তালিকা", M, y, h1);
        y += 10;
        c.drawLine(M, y, W - M, y, rule);
        y += 18;
        if (marks.isEmpty()) {
            c.drawText("কোনো পয়েন্ট চিহ্নিত করা হয়নি।", M, y, body);
            return;
        }
        y = tableHeader(y);
        int n = 1;
        for (TrackStore.Mark m : marks) {
            Bitmap photo = Photos.load(ctx, m.photo, 360);
            float rowH = photo != null ? 96 : 40;
            if (y + rowH > H - 50) {
                newPage();
                y = tableHeader(M + 10);
            }
            float ty = y + 14;
            c.drawText(String.valueOf(n++), M, ty, body);
            String nm = m.name.length() > 26 ? m.name.substring(0, 25) + "…" : m.name;
            c.drawText(nm, M + 24, ty, body);
            c.drawText(TrackStore.fmtCh(startCh + m.ch), M + 190, ty, body);
            c.drawText(String.format(Locale.US, "%.6f", m.lat), M + 258, ty, small);
            c.drawText(String.format(Locale.US, "%.6f", m.lon), M + 258, ty + 12, small);
            c.drawText(Exporter.local(m.time), M + 24, ty + 14, small);
            if (photo != null) {
                float maxW = 120, maxH = 88;
                float sc = Math.min(maxW / photo.getWidth(), maxH / photo.getHeight());
                float pw = photo.getWidth() * sc, ph = photo.getHeight() * sc;
                RectF dst = new RectF(W - M - pw, y + 4, W - M, y + 4 + ph);
                c.drawBitmap(photo, new Rect(0, 0, photo.getWidth(), photo.getHeight()), dst, null);
                photo.recycle();
            }
            y += rowH;
            c.drawLine(M, y, W - M, y, rule);
        }
    }

    private float tableHeader(float y) {
        Paint hd = new Paint(small);
        hd.setFakeBoldText(true);
        hd.setColor(Color.rgb(60, 60, 60));
        c.drawText("নং", M, y, hd);
        c.drawText("নাম / সময়", M + 24, y, hd);
        c.drawText("চেইনেজ", M + 190, y, hd);
        c.drawText("অক্ষাংশ / দ্রাঘিমাংশ", M + 258, y, hd);
        c.drawText("ছবি", W - M - 120, y, hd);
        y += 5;
        c.drawLine(M, y, W - M, y, rule);
        return y;
    }
}
