package com.akshoy.roadsurvey;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.List;
import java.util.Locale;

/** Plays a survey video with the live chainage shown on top, optionally starting from a given moment. */
public class PlayerActivity extends Activity {

    public static final String EXTRA_URI = "uri";
    public static final String EXTRA_START = "start"; // phone time when the video started (ms)
    public static final String EXTRA_SEEK = "seek";   // where to begin playing (ms into the video)
    public static final String EXTRA_TITLE = "title";

    private VideoView video;
    private TextView tvCh, tvPos;
    private long videoStart;
    private double startCh;
    private List<TrackStore.Pt> pts;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            update();
            handler.postDelayed(this, 400);
        }
    };

    public static void open(Context c, TrackStore.VideoRec v, long seekMs) {
        Intent i = new Intent(c, PlayerActivity.class);
        i.putExtra(EXTRA_URI, v.uri);
        i.putExtra(EXTRA_START, v.start);
        i.putExtra(EXTRA_SEEK, Math.max(0, seekMs));
        i.putExtra(EXTRA_TITLE, v.name);
        c.startActivity(i);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLog.install(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        TrackStore store = TrackStore.get(this);
        pts = store.pointsCopy();
        startCh = store.startCh;

        Intent in = getIntent();
        String uri = in.getStringExtra(EXTRA_URI);
        videoStart = in.getLongExtra(EXTRA_START, 0);
        final int seek = (int) in.getLongExtra(EXTRA_SEEK, 0);
        if (uri == null) {
            finish();
            return;
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        video = new VideoView(this);
        root.addView(video, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(150, 0, 0, 0));
        bg.setCornerRadius(dp(12));
        info.setBackground(bg);
        tvCh = new TextView(this);
        tvCh.setTextColor(Color.WHITE);
        tvCh.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        tvCh.setTypeface(Typeface.DEFAULT_BOLD);
        tvPos = new TextView(this);
        tvPos.setTextColor(Color.rgb(230, 230, 230));
        tvPos.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        TextView dev = new TextView(this);
        dev.setText(AppSettings.DEVELOPER);
        dev.setTextColor(Color.rgb(144, 202, 249));
        dev.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        info.addView(tvCh);
        info.addView(tvPos);
        info.addView(dev);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        lp.setMargins(dp(12), dp(12), dp(12), dp(12));
        root.addView(info, lp);
        setContentView(root);

        MediaController mc = new MediaController(this);
        mc.setAnchorView(video);
        video.setMediaController(mc);
        video.setVideoURI(Uri.parse(uri));
        video.setOnPreparedListener(mp -> {
            if (seek > 0) video.seekTo(seek);
            video.start();
        });
        video.setOnErrorListener((mp, what, extra) -> {
            Toast.makeText(this, "ভিডিও চালানো যাচ্ছে না। ফাইলটা হয়তো মোছা হয়েছে।", Toast.LENGTH_LONG).show();
            finish();
            return true;
        });
    }

    private void update() {
        if (video == null) return;
        long t = videoStart + video.getCurrentPosition();
        double[] pos = TrackStore.positionAt(pts, t);
        if (pos == null) {
            tvCh.setText("GPS তথ্য নেই");
            tvPos.setText("");
            return;
        }
        tvCh.setText("Ch " + TrackStore.fmtCh(startCh + pos[2]));
        tvPos.setText(String.format(Locale.US, "%.6f, %.6f  •  %.0f km/h", pos[0], pos[1], pos[3]));
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }
}
