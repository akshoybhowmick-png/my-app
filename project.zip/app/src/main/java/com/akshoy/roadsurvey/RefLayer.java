package com.akshoy.roadsurvey;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * An imported reference: a design alignment or an older track (lines) and named points,
 * read from KML, KMZ or GPX. Used to compare the live position with the design.
 */
public class RefLayer {

    public static class RefPoint {
        public double lat, lon;
        public String name;
    }

    public final List<List<double[]>> lines = new ArrayList<>(); // each point {lat, lon}
    public final List<RefPoint> points = new ArrayList<>();
    public String name = "";

    public boolean isEmpty() {
        return lines.isEmpty() && points.isEmpty();
    }

    // ---------- reading files ----------

    public static RefLayer parse(InputStream in, String fileName) throws Exception {
        byte[] data = readAll(in);
        RefLayer r = new RefLayer();
        r.name = fileName == null ? "" : fileName;
        if (data.length > 2 && data[0] == 'P' && data[1] == 'K') { // KMZ = zip with a .kml inside
            try (ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(data))) {
                ZipEntry e;
                while ((e = z.getNextEntry()) != null) {
                    if (e.getName().toLowerCase(Locale.US).endsWith(".kml")) {
                        data = readAll(z);
                        break;
                    }
                }
            }
        }
        r.parseXml(data);
        return r;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) {
            bos.write(buf, 0, n);
            if (bos.size() > 50_000_000) throw new IOException("file too large");
        }
        return bos.toByteArray();
    }

    private void parseXml(byte[] data) throws Exception {
        XmlPullParser p = Xml.newPullParser();
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
        p.setInput(new ByteArrayInputStream(data), null);
        String placemarkName = null;
        boolean inPoint = false, inLine = false;
        List<double[]> gpxSeg = null;
        RefPoint gpxWpt = null;
        String tag;
        int ev = p.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                tag = local(p.getName());
                switch (tag) {
                    case "placemark":
                        placemarkName = null;
                        break;
                    case "name":
                        String nm = p.nextText();
                        if (gpxWpt != null) gpxWpt.name = nm.trim();
                        else placemarkName = nm.trim();
                        break;
                    case "point":
                        inPoint = true;
                        break;
                    case "linestring":
                    case "linearring":
                        inLine = true;
                        break;
                    case "coordinates":
                        List<double[]> c = parseKmlCoords(p.nextText());
                        if (inPoint && !c.isEmpty()) {
                            RefPoint rp = new RefPoint();
                            rp.lat = c.get(0)[0];
                            rp.lon = c.get(0)[1];
                            rp.name = placemarkName == null ? "" : placemarkName;
                            points.add(rp);
                        } else if (inLine && c.size() >= 2) {
                            lines.add(c);
                        }
                        break;
                    case "trkseg":
                    case "rte":
                        gpxSeg = new ArrayList<>();
                        break;
                    case "trkpt":
                    case "rtept":
                        double[] ll = latLonAttr(p);
                        if (ll != null && gpxSeg != null) gpxSeg.add(ll);
                        break;
                    case "wpt":
                        double[] w = latLonAttr(p);
                        if (w != null) {
                            gpxWpt = new RefPoint();
                            gpxWpt.lat = w[0];
                            gpxWpt.lon = w[1];
                            gpxWpt.name = "";
                        }
                        break;
                    default:
                        break;
                }
            } else if (ev == XmlPullParser.END_TAG) {
                tag = local(p.getName());
                switch (tag) {
                    case "point":
                        inPoint = false;
                        break;
                    case "linestring":
                    case "linearring":
                        inLine = false;
                        break;
                    case "trkseg":
                    case "rte":
                        if (gpxSeg != null && gpxSeg.size() >= 2) lines.add(gpxSeg);
                        gpxSeg = null;
                        break;
                    case "wpt":
                        if (gpxWpt != null) points.add(gpxWpt);
                        gpxWpt = null;
                        break;
                    default:
                        break;
                }
            }
            ev = p.next();
        }
    }

    private static String local(String n) {
        if (n == null) return "";
        int i = n.indexOf(':');
        return (i >= 0 ? n.substring(i + 1) : n).toLowerCase(Locale.US);
    }

    private static double[] latLonAttr(XmlPullParser p) {
        try {
            String la = p.getAttributeValue(null, "lat"), lo = p.getAttributeValue(null, "lon");
            if (la == null || lo == null) return null;
            return new double[]{Double.parseDouble(la), Double.parseDouble(lo)};
        } catch (Exception e) {
            return null;
        }
    }

    /** KML coordinates: "lon,lat[,alt] lon,lat[,alt] ..." */
    private static List<double[]> parseKmlCoords(String text) {
        List<double[]> out = new ArrayList<>();
        for (String tok : text.trim().split("\\s+")) {
            String[] f = tok.split(",");
            if (f.length < 2) continue;
            try {
                out.add(new double[]{Double.parseDouble(f[1]), Double.parseDouble(f[0])});
            } catch (NumberFormatException ignored) {
            }
        }
        return out;
    }

    // ---------- saving with the survey ----------

    public void save(File f) throws IOException {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8)) {
            w.write("N," + name.replace('\n', ' ') + "\n");
            for (int i = 0; i < lines.size(); i++) {
                for (double[] q : lines.get(i)) {
                    w.write(String.format(Locale.US, "L,%d,%.8f,%.8f\n", i, q[0], q[1]));
                }
            }
            for (RefPoint rp : points) {
                w.write(String.format(Locale.US, "P,%.8f,%.8f,%s\n", rp.lat, rp.lon, rp.name.replace('\n', ' ')));
            }
        }
    }

    public static RefLayer load(File f) {
        if (!f.exists()) return null;
        RefLayer r = new RefLayer();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            int cur = -1;
            List<double[]> seg = null;
            while ((line = br.readLine()) != null) {
                try {
                    if (line.startsWith("N,")) {
                        r.name = line.substring(2);
                    } else if (line.startsWith("L,")) {
                        String[] a = line.split(",", 4);
                        int idx = Integer.parseInt(a[1]);
                        if (idx != cur) {
                            seg = new ArrayList<>();
                            r.lines.add(seg);
                            cur = idx;
                        }
                        seg.add(new double[]{Double.parseDouble(a[2]), Double.parseDouble(a[3])});
                    } else if (line.startsWith("P,")) {
                        String[] a = line.split(",", 4);
                        RefPoint rp = new RefPoint();
                        rp.lat = Double.parseDouble(a[1]);
                        rp.lon = Double.parseDouble(a[2]);
                        rp.name = a.length > 3 ? a[3] : "";
                        r.points.add(rp);
                    }
                } catch (Exception ignored) {
                }
            }
        } catch (IOException e) {
            return null;
        }
        return r.isEmpty() ? null : r;
    }

    // ---------- comparing with the design ----------

    /**
     * Where a position is relative to the nearest reference line.
     * Returns {offset m (+ = right of line direction, - = left), chainage along that line (m), line index}
     * or null if there are no lines.
     */
    public double[] offsetFrom(double lat, double lon) {
        double best = Double.MAX_VALUE;
        double[] res = null;
        double k = Math.cos(Math.toRadians(lat));
        final double M = 111320.0;
        for (int li = 0; li < lines.size(); li++) {
            List<double[]> ln = lines.get(li);
            double along = 0;
            for (int i = 1; i < ln.size(); i++) {
                double[] a = ln.get(i - 1), b = ln.get(i);
                // local metres relative to the position
                double ax = (a[1] - lon) * M * k, ay = (a[0] - lat) * M;
                double bx = (b[1] - lon) * M * k, by = (b[0] - lat) * M;
                double dx = bx - ax, dy = by - ay;
                double segLen = Math.sqrt(dx * dx + dy * dy);
                if (segLen < 1e-6) continue;
                double t = Math.max(0, Math.min(1, (-ax * dx - ay * dy) / (segLen * segLen)));
                double px = ax + t * dx, py = ay + t * dy;
                double dist = Math.sqrt(px * px + py * py);
                if (dist < best) {
                    best = dist;
                    double cross = dx * (-ay) - dy * (-ax); // >0: position is left of the line direction
                    res = new double[]{cross > 0 ? -dist : dist, along + t * segLen, li};
                }
                along += segLen;
            }
        }
        return res;
    }
}
