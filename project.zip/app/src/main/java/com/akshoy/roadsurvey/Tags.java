package com.akshoy.roadsurvey;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** The list of point tags (কালভার্ট, ব্রিজ …) the user can pick from, add to or remove from. */
public class Tags {

    private static final String[] DEFAULTS = {
            "কালভার্ট", "ব্রিজ", "বাঁক / মোড়", "জংশন / ক্রসিং", "স্কুল", "বাজার", "বসতি",
            "পুকুর / জলাশয়", "মন্দির / মসজিদ", "বিদ্যুতের খুঁটি", "গাছ", "শুরু বিন্দু", "শেষ বিন্দু"};

    public interface OnTag {
        void onTag(String tag);
    }

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("tags", Context.MODE_PRIVATE);
    }

    public static List<String> list(Context c) {
        String s = p(c).getString("list", null);
        if (s == null) return new ArrayList<>(Arrays.asList(DEFAULTS));
        List<String> out = new ArrayList<>();
        for (String t : s.split("\n")) if (!t.trim().isEmpty()) out.add(t.trim());
        return out;
    }

    private static void save(Context c, List<String> tags) {
        p(c).edit().putString("list", TextUtils.join("\n", tags)).apply();
    }

    public static boolean add(Context c, String tag) {
        tag = tag.replace('\n', ' ').trim();
        if (tag.isEmpty()) return false;
        List<String> l = list(c);
        if (l.contains(tag)) return false;
        l.add(tag);
        save(c, l);
        return true;
    }

    private static int dp(Context c, int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    /** Lets the user pick a tag from the list, or type one. */
    public static void pick(final Activity a, final OnTag cb) {
        final List<String> tags = list(a);
        final String[] items = new String[tags.size() + 2];
        items[0] = "✏  নিজে লিখুন";
        for (int i = 0; i < tags.size(); i++) items[i + 1] = "🏷  " + tags.get(i);
        items[items.length - 1] = "➕  নতুন ট্যাগ যোগ / তালিকা সাজান";
        new AlertDialog.Builder(a)
                .setTitle("কী চিহ্নিত করবেন?")
                .setItems(items, (d, which) -> {
                    if (which == 0) write(a, cb);
                    else if (which == items.length - 1) manage(a, () -> pick(a, cb));
                    else cb.onTag(tags.get(which - 1));
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private static void write(final Activity a, final OnTag cb) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), 0);
        final EditText et = new EditText(a);
        et.setHint("যেমন: ভাঙা অংশ, জল জমে");
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        final CheckBox keep = new CheckBox(a);
        keep.setText("এটা ট্যাগ তালিকায় রেখে দিন");
        keep.setChecked(false);
        box.addView(et);
        box.addView(keep);
        new AlertDialog.Builder(a)
                .setTitle("পয়েন্টের নাম লিখুন")
                .setView(box)
                .setPositiveButton("সেভ", (d, w) -> {
                    String n = et.getText().toString().trim();
                    if (n.isEmpty()) n = "পয়েন্ট";
                    if (keep.isChecked()) add(a, n);
                    cb.onTag(n);
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    public static void manage(final Activity a) {
        manage(a, null);
    }

    /** Tag list editor: add new tags, remove old ones. "after" runs when the editor is closed. */
    public static void manage(final Activity a, final Runnable after) {
        final List<String> tags = list(a);
        final String[] items = new String[tags.size() + 1];
        items[0] = "➕  নতুন ট্যাগ যোগ করুন";
        for (int i = 0; i < tags.size(); i++) items[i + 1] = "🏷  " + tags.get(i) + "   (মুছতে চাপুন)";
        new AlertDialog.Builder(a)
                .setTitle("ট্যাগ তালিকা")
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        final EditText et = new EditText(a);
                        et.setHint("নতুন ট্যাগের নাম");
                        et.setInputType(InputType.TYPE_CLASS_TEXT);
                        LinearLayout box = new LinearLayout(a);
                        box.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), 0);
                        box.addView(et, new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                        new AlertDialog.Builder(a)
                                .setTitle("নতুন ট্যাগ")
                                .setView(box)
                                .setPositiveButton("যোগ করুন", (d2, w2) -> {
                                    if (add(a, et.getText().toString())) {
                                        Toast.makeText(a, "ট্যাগ যোগ হলো", Toast.LENGTH_SHORT).show();
                                    }
                                    manage(a, after);
                                })
                                .setNegativeButton("বাতিল", (d2, w2) -> manage(a, after))
                                .show();
                    } else {
                        final String t = tags.get(which - 1);
                        new AlertDialog.Builder(a)
                                .setTitle("\"" + t + "\" ট্যাগ মুছবেন?")
                                .setPositiveButton("মুছুন", (d2, w2) -> {
                                    List<String> l = list(a);
                                    l.remove(t);
                                    save(a, l);
                                    manage(a, after);
                                })
                                .setNegativeButton("না", (d2, w2) -> manage(a, after))
                                .show();
                    }
                })
                .setNegativeButton("বন্ধ", (d, w) -> {
                    if (after != null) after.run();
                })
                .setNeutralButton("আগের তালিকায় ফেরান", (d, w) -> {
                    p(a).edit().remove("list").apply();
                    manage(a, after);
                })
                .show();
    }
}
