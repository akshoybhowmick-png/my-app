package com.akshoy.roadsurvey;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** The list of point tags (কালভার্ট, ব্রিজ …) the user can pick from, add to or remove from. */
public class Tags {

    private static String[] defaults() {
        return new String[]{
            L.t("কালভার্ট", "Culvert"), L.t("ব্রিজ", "Bridge"), L.t("বাঁক / মোড়", "Curve / Turn"), L.t("জংশন / ক্রসিং", "Junction / Crossing"), L.t("স্কুল", "School"), L.t("বাজার", "Market"), L.t("বসতি", "Settlement"),
            L.t("পুকুর / জলাশয়", "Pond / Water body"), L.t("মন্দির / মসজিদ", "Temple / Mosque"), L.t("বিদ্যুতের খুঁটি", "Electric pole"), L.t("গাছ", "Tree"), L.t("শুরু বিন্দু", "Start point"), L.t("শেষ বিন্দু", "End point")};
    }

    public interface OnTag {
        void onTag(String tag);
    }

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("tags", Context.MODE_PRIVATE);
    }

    public static List<String> list(Context c) {
        String s = p(c).getString("list", null);
        if (s == null) return new ArrayList<>(Arrays.asList(defaults()));
        List<String> out = new ArrayList<>();
        for (String t : s.split("\n")) if (!t.trim().isEmpty()) out.add(t.trim());
        return out;
    }

    private static void save(Context c, List<String> tags) {
        p(c).edit().putString("list", TextUtils.join("\n", tags)).apply();
    }

    public static boolean add(Context c, String tag) {
        tag = tag.replace('\n', ' ').trim();
        if (tag.isEmpty()) return false;
        List<String> l = list(c);
        if (l.contains(tag)) return false;
        l.add(tag);
        save(c, l);
        return true;
    }

    private static int dp(Context c, int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    /** Lets the user pick a tag from the list, or type one. */
    public static void pick(final Activity a, final OnTag cb) {
        pick(a, cb, null);
    }

    /** Pick a tag. If onOffset is given, an extra "offset point" choice is shown. */
    public static void pick(final Activity a, final OnTag cb, final Runnable onOffset) {
        if (onOffset == null) pick(a, cb, new String[0], new Runnable[0]);
        else pick(a, cb, new String[]{L.t("↔  অফসেট পয়েন্ট (রাস্তার বাঁয়ে / ডানে)", "↔  Offset point (left / right of road)")},
                new Runnable[]{onOffset});
    }

    /** Pick a tag; extra special actions are listed right after "type it yourself". */
    public static void pick(final Activity a, final OnTag cb, final String[] extraLabels, final Runnable[] extraActions) {
        final List<String> tags = list(a);
        final int extra = extraLabels.length;
        final String[] items = new String[tags.size() + 2 + extra];
        items[0] = L.t("✏  নিজে লিখুন", "✏  Type it yourself");
        System.arraycopy(extraLabels, 0, items, 1, extra);
        for (int i = 0; i < tags.size(); i++) items[i + 1 + extra] = "🏷  " + tags.get(i);
        items[items.length - 1] = L.t("➕  নতুন ট্যাগ যোগ / তালিকা সাজান", "➕  Add new tag / edit list");
        new AlertDialog.Builder(a)
                .setTitle(L.t("কী চিহ্নিত করবেন?", "What are you marking?"))
                .setItems(items, (d, which) -> {
                    if (which == 0) write(a, cb);
                    else if (which <= extra) extraActions[which - 1].run();
                    else if (which == items.length - 1) manage(a, () -> pick(a, cb, extraLabels, extraActions));
                    else cb.onTag(tags.get(which - 1 - extra));
                })
                .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                .show();
    }

    private static void write(final Activity a, final OnTag cb) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), 0);
        final EditText et = new EditText(a);
        et.setHint(L.t("যেমন: ভাঙা অংশ, জল জমে", "e.g. broken patch, waterlogging"));
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        final CheckBox keep = new CheckBox(a);
        keep.setText(L.t("এটা ট্যাগ তালিকায় রেখে দিন", "Keep this in the tag list"));
        keep.setChecked(false);
        box.addView(et);
        box.addView(keep);
        new AlertDialog.Builder(a)
                .setTitle(L.t("পয়েন্টের নাম লিখুন", "Type the point name"))
                .setView(box)
                .setPositiveButton(L.t("সেভ", "Save"), (d, w) -> {
                    String n = et.getText().toString().trim();
                    if (n.isEmpty()) n = L.t("পয়েন্ট", "Point");
                    if (keep.isChecked()) add(a, n);
                    cb.onTag(n);
                })
                .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                .show();
    }

    public static void manage(final Activity a) {
        manage(a, null);
    }

    /** Tag list editor: add new tags, remove old ones. "after" runs when the editor is closed. */
    public static void manage(final Activity a, final Runnable after) {
        final List<String> tags = list(a);
        final String[] items = new String[tags.size() + 1];
        items[0] = L.t("➕  নতুন ট্যাগ যোগ করুন", "➕  Add a new tag");
        for (int i = 0; i < tags.size(); i++) items[i + 1] = "🏷  " + tags.get(i) + L.t("   (মুছতে চাপুন)", "   (tap to delete)");
        new AlertDialog.Builder(a)
                .setTitle(L.t("ট্যাগ তালিকা", "Tag list"))
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        final EditText et = new EditText(a);
                        et.setHint(L.t("নতুন ট্যাগের নাম", "New tag name"));
                        et.setInputType(InputType.TYPE_CLASS_TEXT);
                        LinearLayout box = new LinearLayout(a);
                        box.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), 0);
                        box.addView(et, new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                        new AlertDialog.Builder(a)
                                .setTitle(L.t("নতুন ট্যাগ", "New tag"))
                                .setView(box)
                                .setPositiveButton(L.t("যোগ করুন", "Add"), (d2, w2) -> {
                                    if (add(a, et.getText().toString())) {
                                        Toast.makeText(a, L.t("ট্যাগ যোগ হলো", "Tag added"), Toast.LENGTH_SHORT).show();
                                    }
                                    manage(a, after);
                                })
                                .setNegativeButton(L.t("বাতিল", "Cancel"), (d2, w2) -> manage(a, after))
                                .show();
                    } else {
                        final String t = tags.get(which - 1);
                        new AlertDialog.Builder(a)
                                .setTitle("\"" + t + L.t("\" ট্যাগ মুছবেন?", "\" — delete tag?"))
                                .setPositiveButton(L.t("মুছুন", "Delete"), (d2, w2) -> {
                                    List<String> l = list(a);
                                    l.remove(t);
                                    save(a, l);
                                    manage(a, after);
                                })
                                .setNegativeButton(L.t("না", "No"), (d2, w2) -> manage(a, after))
                                .show();
                    }
                })
                .setNegativeButton(L.t("বন্ধ", "Close"), (d, w) -> {
                    if (after != null) after.run();
                })
                .setNeutralButton(L.t("আগের তালিকায় ফেরান", "Restore default list"), (d, w) -> {
                    p(a).edit().remove("list").apply();
                    manage(a, after);
                })
                .show();
    }
}
