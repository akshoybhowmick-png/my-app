package com.akshoy.roadsurvey;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.view.MotionEvent;

import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.Projection;
import org.osmdroid.views.overlay.Overlay;

import java.util.List;

/**
 * Fast grip editor: draws the edited line and all grips in one pass and handles touches itself.
 * Touch a grip and move = drag immediately (no long-press). Tap a grip = select it.
 * Tap the line between grips = add a grip there. Touches elsewhere pan/zoom the map as usual.
 */
public class GripOverlay extends Overlay {

    public interface Listener {
        void beforeChange();          // a change is about to happen (for undo)

        void onChanged(boolean live); // geometry changed; live = still dragging

        void onSelect(int index);     // -1 = nothing selected
    }

    private final List<GripEdit.Vertex> verts;
    private final Listener listener;
    private final float density;
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gripFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gripStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint endFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Point pt = new Point();

    private int dragging = -1;
    private int selected = -1;
    private float downX, downY;
    private boolean moved;
    private int downOnGrip = -1;

    public GripOverlay(List<GripEdit.Vertex> verts, float density, Listener l) {
        super();
        this.verts = verts;
        this.listener = l;
        this.density = density;
        linePaint.setColor(Color.rgb(255, 111, 0));
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(4 * density);
        linePaint.setStrokeJoin(Paint.Join.ROUND);
        gripFill.setColor(Color.WHITE);
        gripStroke.setColor(Color.rgb(255, 111, 0));
        gripStroke.setStyle(Paint.Style.STROKE);
        gripStroke.setStrokeWidth(2 * density);
        endFill.setColor(Color.rgb(255, 111, 0));
        selFill.setColor(Color.rgb(229, 57, 53));
    }

    public int getSelected() {
        return selected;
    }

    public void clearSelection() {
        selected = -1;
    }

    @Override
    public void draw(Canvas c, MapView mv, boolean shadow) {
        if (shadow || verts.isEmpty()) return;
        Projection pj = mv.getProjection();
        path.rewind();
        for (int i = 0; i < verts.size(); i++) {
            GripEdit.Vertex v = verts.get(i);
            pj.toPixels(new GeoPoint(v.lat, v.lon), pt);
            if (i == 0) path.moveTo(pt.x, pt.y);
            else path.lineTo(pt.x, pt.y);
        }
        c.drawPath(path, linePaint);
        float h = 7 * density;
        int w = c.getWidth(), ht = c.getHeight();
        for (int i = 0; i < verts.size(); i++) {
            GripEdit.Vertex v = verts.get(i);
            pj.toPixels(new GeoPoint(v.lat, v.lon), pt);
            if (pt.x < -50 || pt.y < -50 || pt.x > w + 50 || pt.y > ht + 50) continue; // off screen
            boolean end = i == 0 || i == verts.size() - 1;
            float s = (i == selected || i == dragging) ? h * 1.5f : h;
            Paint fill = i == selected || i == dragging ? selFill : (end ? endFill : gripFill);
            c.drawRect(pt.x - s, pt.y - s, pt.x + s, pt.y + s, fill);
            c.drawRect(pt.x - s, pt.y - s, pt.x + s, pt.y + s, gripStroke);
        }
    }

    /** Grip index under a screen point (within a finger's width), or -1. */
    private int gripAt(float x, float y, MapView mv) {
        Projection pj = mv.getProjection();
        float best = 26 * density;
        int bi = -1;
        for (int i = 0; i < verts.size(); i++) {
            GripEdit.Vertex v = verts.get(i);
            pj.toPixels(new GeoPoint(v.lat, v.lon), pt);
            float d = (float) Math.hypot(pt.x - x, pt.y - y);
            if (d < best) {
                best = d;
                bi = i;
            }
        }
        return bi;
    }

    /** Segment index whose screen distance to the point is under a finger's width, or -1. */
    private int segmentAt(float x, float y, MapView mv) {
        Projection pj = mv.getProjection();
        Point a = new Point(), b = new Point();
        float best = 20 * density;
        int bi = -1;
        for (int i = 0; i + 1 < verts.size(); i++) {
            pj.toPixels(new GeoPoint(verts.get(i).lat, verts.get(i).lon), a);
            pj.toPixels(new GeoPoint(verts.get(i + 1).lat, verts.get(i + 1).lon), b);
            float dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy;
            float t = l2 < 1e-3f ? 0 : Math.max(0, Math.min(1, ((x - a.x) * dx + (y - a.y) * dy) / l2));
            float d = (float) Math.hypot(a.x + t * dx - x, a.y + t * dy - y);
            if (d < best) {
                best = d;
                bi = i;
            }
        }
        return bi;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e, MapView mv) {
        if (e.getPointerCount() > 1) { // pinch zoom: let the map handle it
            if (dragging >= 0) {
                dragging = -1;
                listener.onChanged(false);
            }
            downOnGrip = -1;
            return false;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                moved = false;
                downOnGrip = gripAt(e.getX(), e.getY(), mv);
                if (downOnGrip >= 0) {
                    dragging = -1;
                    return true; // own the gesture: the map must not pan while a grip is touched
                }
                return false;
            case MotionEvent.ACTION_MOVE:
                if (downOnGrip < 0) return false;
                if (!moved && Math.hypot(e.getX() - downX, e.getY() - downY) > 6 * density) {
                    moved = true;
                    listener.beforeChange();
                    dragging = downOnGrip;
                }
                if (dragging >= 0) {
                    IGeoPoint g = mv.getProjection().fromPixels((int) e.getX(), (int) e.getY());
                    GripEdit.Vertex v = verts.get(dragging);
                    v.lat = g.getLatitude();
                    v.lon = g.getLongitude();
                    listener.onChanged(true);
                    mv.invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (downOnGrip >= 0) {
                    if (dragging >= 0) {
                        dragging = -1;
                        listener.onChanged(false);
                    } else if (!moved) {
                        selected = selected == downOnGrip ? -1 : downOnGrip; // tap toggles selection
                        listener.onSelect(selected);
                    }
                    downOnGrip = -1;
                    mv.invalidate();
                    return true;
                }
                return false;
            case MotionEvent.ACTION_CANCEL:
                dragging = -1;
                downOnGrip = -1;
                return false;
            default:
                return downOnGrip >= 0;
        }
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e, MapView mv) {
        if (gripAt(e.getX(), e.getY(), mv) >= 0) return true;
        int seg = segmentAt(e.getX(), e.getY(), mv);
        if (seg < 0) return false;
        IGeoPoint g = mv.getProjection().fromPixels((int) e.getX(), (int) e.getY());
        listener.beforeChange();
        verts.add(seg + 1, new GripEdit.Vertex(g.getLatitude(), g.getLongitude(), -1));
        selected = seg + 1;
        listener.onSelect(selected);
        listener.onChanged(false);
        mv.invalidate();
        return true;
    }
}
