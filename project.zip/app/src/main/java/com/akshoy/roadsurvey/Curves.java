package com.akshoy.roadsurvey;

import java.util.ArrayList;
import java.util.List;

/**
 * Finds horizontal curves (bends) in the recorded road: start/end chainage, direction,
 * deflection angle, curve length, approximate radius and tangent length.
 */
public class Curves {

    public static class Curve {
        public double startCh, endCh;   // raw metres from the survey start
        public double deflection;       // degrees (always positive)
        public boolean right;           // turning to the right?
        public double radius, length, tangent;
        public double midLat, midLon;
    }

    private static final double STEP = 5;           // resampling interval (m)
    private static final double CHORD = 20;          // half-chord used for the heading (m)
    private static final double MAX_RADIUS = 600;    // flatter than this = straight
    private static final double MIN_DEFLECTION = 8;  // ignore tiny wiggles (degrees)
    private static final double MIN_LENGTH = 15;     // shortest curve worth reporting (m)
    private static final double MERGE_GAP = 20;      // join same-direction pieces closer than this (m)

    public static List<Curve> find(List<TrackStore.Pt> pts) {
        List<Curve> out = new ArrayList<>();
        if (pts.size() < 4) return out;
        double len = pts.get(pts.size() - 1).ch;
        if (len < 4 * CHORD) return out;

        // 1) resample the line every STEP metres
        int n = (int) Math.floor(len / STEP) + 1;
        double[] lat = new double[n], lon = new double[n], ch = new double[n];
        int j = 1;
        for (int i = 0; i < n; i++) {
            double c = i * STEP;
            while (j < pts.size() - 1 && pts.get(j).ch < c) j++;
            TrackStore.Pt a = pts.get(j - 1), b = pts.get(j);
            double f = b.ch - a.ch < 1e-6 ? 0 : Math.max(0, Math.min(1, (c - a.ch) / (b.ch - a.ch)));
            lat[i] = a.lat + (b.lat - a.lat) * f;
            lon[i] = a.lon + (b.lon - a.lon) * f;
            ch[i] = c;
        }

        // 1b) smooth the positions (±15 m, twice) so GPS wobble does not look like bends
        for (int pass = 0; pass < 2; pass++) {
            double[] la2 = new double[n], lo2 = new double[n];
            for (int i = 0; i < n; i++) {
                int a0 = Math.max(0, i - 3), a1 = Math.min(n - 1, i + 3);
                double sl = 0, so = 0;
                for (int q = a0; q <= a1; q++) {
                    sl += lat[q];
                    so += lon[q];
                }
                la2[i] = sl / (a1 - a0 + 1);
                lo2[i] = so / (a1 - a0 + 1);
            }
            lat = la2;
            lon = lo2;
        }

        // 2) heading at each sample from points CHORD metres before and after
        int k = (int) Math.round(CHORD / STEP);
        double[] head = new double[n];
        for (int i = 0; i < n; i++) {
            int i0 = Math.max(0, i - k), i1 = Math.min(n - 1, i + k);
            head[i] = Geo.bearing(lat[i0], lon[i0], lat[i1], lon[i1]);
        }

        // 3) curvature (degrees per metre), signed: + = right turn
        double[] curv = new double[n];
        for (int i = 1; i < n - 1; i++) {
            double d = angleDiff(head[i + 1], head[i - 1]);
            curv[i] = d / (2 * STEP);
        }
        double minCurv = Math.toDegrees(1.0 / MAX_RADIUS);

        // 4) group samples that turn the same way and sharply enough
        List<int[]> pieces = new ArrayList<>(); // {start, end, right?1:0}
        int i = 1;
        while (i < n - 1) {
            if (Math.abs(curv[i]) < minCurv) {
                i++;
                continue;
            }
            boolean right = curv[i] > 0;
            int s = i;
            while (i < n - 1 && Math.abs(curv[i]) >= minCurv * 0.6 && (curv[i] > 0) == right) i++;
            pieces.add(new int[]{s, i - 1, right ? 1 : 0});
        }
        // merge neighbouring pieces turning the same way
        List<int[]> merged = new ArrayList<>();
        for (int[] pc : pieces) {
            if (!merged.isEmpty()) {
                int[] last = merged.get(merged.size() - 1);
                if (last[2] == pc[2] && (pc[0] - last[1]) * STEP <= MERGE_GAP) {
                    last[1] = pc[1];
                    continue;
                }
            }
            merged.add(new int[]{pc[0], pc[1], pc[2]});
        }
        for (int[] pc : merged) {
            int s = pc[0], e = pc[1];
            boolean right = pc[2] == 1;
            double defl = Math.abs(angleDiff(head[Math.min(n - 1, e + k / 2)], head[Math.max(0, s - k / 2)]));
            // smoothing spreads a bend out; its true extent is where curvature is at least half the peak
            double peak = 0;
            for (int q = s; q <= e; q++) peak = Math.max(peak, Math.abs(curv[q]));
            int cs = e, ce = s;
            for (int q = s; q <= e; q++) {
                if (Math.abs(curv[q]) >= peak * 0.5) {
                    cs = Math.min(cs, q);
                    ce = Math.max(ce, q);
                }
            }
            if (ce < cs) {
                cs = s;
                ce = e;
            }
            double lc = ch[ce] - ch[cs] + STEP;
            if (defl < MIN_DEFLECTION || lc < MIN_LENGTH) continue;
            s = cs;
            e = ce;
            Curve c = new Curve();
            c.startCh = ch[s];
            c.endCh = ch[e];
            c.length = lc;
            c.deflection = defl;
            c.right = right;
            double rad = Math.toRadians(defl);
            c.radius = lc / rad;
            c.tangent = defl < 170 ? c.radius * Math.tan(rad / 2) : Double.NaN;
            int mid = (s + e) / 2;
            c.midLat = lat[mid];
            c.midLon = lon[mid];
            out.add(c);
        }
        return out;
    }

    /** Smallest signed difference b - a in degrees (-180..180). */
    private static double angleDiff(double b, double a) {
        double d = (b - a) % 360;
        if (d > 180) d -= 360;
        if (d < -180) d += 360;
        return d;
    }
}
