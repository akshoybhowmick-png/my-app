package com.akshoy.roadsurvey;

import android.content.Context;

/** App language: Bengali (default) or English. Every text in the app goes through L.t(bengali, english). */
public class L {

    private static volatile boolean english = false;
    private static volatile boolean loaded = false;

    public static void init(Context c) {
        if (loaded) return;
        english = "en".equals(c.getApplicationContext()
                .getSharedPreferences("settings", Context.MODE_PRIVATE).getString("lang", "bn"));
        loaded = true;
    }

    public static boolean isEnglish() {
        return english;
    }

    public static void set(Context c, boolean useEnglish) {
        english = useEnglish;
        loaded = true;
        c.getApplicationContext().getSharedPreferences("settings", Context.MODE_PRIVATE)
                .edit().putString("lang", useEnglish ? "en" : "bn").apply();
    }

    public static String t(String bengali, String englishText) {
        return english ? englishText : bengali;
    }
}
