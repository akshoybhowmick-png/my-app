package com.akshoy.roadsurvey;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;

import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.Projection;
import org.osmdroid.views.overlay.Overlay;

import java.util.ArrayList;
import java.util.List;

/** Draws chainage labels along the road: every 100 m when zoomed in, every km always. */
public class ChainageOverlay extends Overlay {

    private static class Tick {
        GeoPoint gp;
        String label;
        boolean km;
    }

    private final List<Tick> ticks = new ArrayList<>();
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint kmDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint kmText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint kmHalo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;

    public ChainageOverlay(float density) {
        super();
        this.density = density;
        dot.setColor(Color.WHITE);
        dot.setStyle(Paint.Style.FILL);
        kmDot.setColor(Color.rgb(21, 101, 192));
        kmDot.setStyle(Paint.Style.FILL);
        text.setColor(Color.rgb(33, 33, 33));
        text.setTextSize(11 * density);
        kmText.setColor(Color.rgb(21, 101, 192));
        kmText.setTextSize(14 * density);
        kmText.setFakeBoldText(true);
        halo.set(text);
        halo.setColor(Color.WHITE);
        halo.setStyle(Paint.Style.STROKE);
        halo.setStrokeWidth(3 * density);
        kmHalo.set(kmText);
        kmHalo.setColor(Color.WHITE);
        kmHalo.setStyle(Paint.Style.STROKE);
        kmHalo.setStrokeWidth(4 * density);
    }

    /** Rebuild the label positions. startCh is the survey's start chainage. */
    public void setTrack(List<TrackStore.Pt> pts, double startCh) {
        ticks.clear();
        if (pts.size() < 2) return;
        double step = 100;
        double next = Math.ceil(startCh / step) * step;
        for (int i = 1; i < pts.size(); i++) {
            TrackStore.Pt a = pts.get(i - 1), b = pts.get(i);
            double ca = startCh + a.ch, cb = startCh + b.ch;
            while (next <= cb) {
                if (next >= ca) {
                    double f = cb - ca < 1e-6 ? 0 : (next - ca) / (cb - ca);
                    Tick t = new Tick();
                    t.gp = new GeoPoint(a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f);
                    long m = Math.round(next);
                    t.km = m % 1000 == 0;
                    t.label = TrackStore.fmtCh(next);
                    ticks.add(t);
                }
                next += step;
            }
        }
    }

    @Override
    public void draw(Canvas c, MapView mapView, boolean shadow) {
        if (shadow || ticks.isEmpty()) return;
        double zoom = mapView.getZoomLevelDouble();
        boolean showHundreds = zoom >= 15.5;
        if (!showHundreds && zoom < 11) return;
        Projection pj = mapView.getProjection();
        Point p = new Point();
        float r = 4 * density, rk = 6 * density, off = 8 * density;
        for (Tick t : ticks) {
            if (!t.km && !showHundreds) continue;
            pj.toPixels(t.gp, p);
            if (t.km) {
                c.drawCircle(p.x, p.y, rk + 2 * density, dot);
                c.drawCircle(p.x, p.y, rk, kmDot);
                c.drawText(t.label, p.x + off, p.y - off, kmHalo);
                c.drawText(t.label, p.x + off, p.y - off, kmText);
            } else {
                c.drawCircle(p.x, p.y, r + density, text);
                c.drawCircle(p.x, p.y, r, dot);
                c.drawText(t.label, p.x + off, p.y - off * 0.5f, halo);
                c.drawText(t.label, p.x + off, p.y - off * 0.5f, text);
            }
        }
    }
}
