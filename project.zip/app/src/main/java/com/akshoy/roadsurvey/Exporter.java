package com.akshoy.roadsurvey;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Builds KML / CSV / GPX files and saves files in Download/RoadSurvey. */
public class Exporter {

    public static final String FOLDER = "RoadSurvey";

    private static String iso(long t) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(t));
    }

    public static String local(long t) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(t));
    }

    private static String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static String csvCell(String s) {
        if (s.contains(",") || s.contains("\"")) return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }

    /** Short photo file name from a content uri, for reports. */
    public static String photoLabel(String uri) {
        if (uri == null || uri.isEmpty()) return "";
        if (!uri.startsWith("content:") && !uri.startsWith("file:")) return L.t("ছবি: ", "Photo: ") + uri; // already a file name
        int slash = uri.lastIndexOf('/');
        return L.t("ছবি #", "Photo #") + (slash >= 0 ? uri.substring(slash + 1) : uri);
    }

    public static String kml(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title, double startCh) {
        return kml(pts, marks, title, startCh, null);
    }

    /** photoPaths[i] = path of mark i's photo inside a KMZ (or null). */
    public static String kml(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title, double startCh,
                             String[] photoPaths) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
                .append("<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n<Document>\n")
                .append("<name>").append(xml(title)).append("</name>\n")
                .append("<description>").append(AppSettings.DEVELOPER).append("</description>\n")
                .append("<Style id=\"road\"><LineStyle><color>ff0000ff</color><width>4</width></LineStyle></Style>\n")
                .append("<Style id=\"km\"><IconStyle><scale>0.6</scale></IconStyle><LabelStyle><scale>0.8</scale></LabelStyle></Style>\n");
        if (!pts.isEmpty()) {
            double len = pts.get(pts.size() - 1).ch;
            sb.append("<Placemark>\n<name>").append(xml(title)).append("</name>\n")
                    .append("<description>Chainage ").append(TrackStore.fmtCh(startCh))
                    .append(" to ").append(TrackStore.fmtCh(startCh + len))
                    .append(", length ").append(String.format(Locale.US, "%.1f", len)).append(" m</description>\n")
                    .append("<styleUrl>#road</styleUrl>\n<LineString>\n<tessellate>1</tessellate>\n<coordinates>\n");
            for (TrackStore.Pt p : pts) {
                sb.append(String.format(Locale.US, "%.7f,%.7f,%.1f\n", p.lon, p.lat, p.alt));
            }
            sb.append("</coordinates>\n</LineString>\n</Placemark>\n");

            // kilometre stones
            sb.append("<Folder><name>Km chainage</name>\n");
            double next = Math.ceil(startCh / 1000.0) * 1000;
            for (int i = 1; i < pts.size(); i++) {
                TrackStore.Pt a = pts.get(i - 1), b = pts.get(i);
                double ca = startCh + a.ch, cb = startCh + b.ch;
                while (next <= cb) {
                    if (next >= ca) {
                        double f = cb - ca < 1e-6 ? 0 : (next - ca) / (cb - ca);
                        sb.append("<Placemark><name>").append(TrackStore.fmtCh(next))
                                .append("</name><styleUrl>#km</styleUrl><Point><coordinates>")
                                .append(String.format(Locale.US, "%.7f,%.7f,0",
                                        a.lon + (b.lon - a.lon) * f, a.lat + (b.lat - a.lat) * f))
                                .append("</coordinates></Point></Placemark>\n");
                    }
                    next += 1000;
                }
            }
            sb.append("</Folder>\n");
        }
        sb.append("<Folder><name>Points</name>\n");
        int i = 1;
        for (TrackStore.Mark m : marks) {
            String img = photoPaths != null && i - 1 < photoPaths.length ? photoPaths[i - 1] : null;
            sb.append("<Placemark>\n<name>").append(i).append(". ").append(xml(m.name)).append("</name>\n");
            if (img != null) {
                sb.append("<description><![CDATA[<b>Chainage ").append(TrackStore.fmtCh(startCh + m.ch))
                        .append("</b><br/>").append(local(m.time))
                        .append("<br/><img src=\"").append(img).append("\" width=\"480\"/>]]>");
            } else {
                sb.append("<description>Chainage ").append(TrackStore.fmtCh(startCh + m.ch))
                        .append(" | ").append(local(m.time));
                if (!m.photo.isEmpty()) sb.append(" | ").append(xml(photoLabel(m.photo)));
            }
            i++;
            sb.append("</description>\n<Point><coordinates>")
                    .append(String.format(Locale.US, "%.7f,%.7f,%.1f", m.lon, m.lat, m.alt))
                    .append("</coordinates></Point>\n</Placemark>\n");
        }
        sb.append("</Folder>\n</Document>\n</kml>\n");
        return sb.toString();
    }

    /** KMZ = zipped KML with the point photos inside, so Google Earth shows them. */
    public static byte[] kmz(Context c, List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title,
                             double startCh) throws IOException {
        String[] paths = new String[marks.size()];
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        try (java.util.zip.ZipOutputStream zip = new java.util.zip.ZipOutputStream(bos)) {
            for (int i = 0; i < marks.size(); i++) {
                android.graphics.Bitmap b = Photos.load(c, marks.get(i).photo, 1280);
                if (b == null) continue;
                paths[i] = "files/point_" + (i + 1) + ".jpg";
                zip.putNextEntry(new java.util.zip.ZipEntry(paths[i]));
                b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, zip);
                b.recycle();
                zip.closeEntry();
            }
            zip.putNextEntry(new java.util.zip.ZipEntry("doc.kml"));
            zip.write(kml(pts, marks, title, startCh, paths).getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        }
        return bos.toByteArray();
    }

    /**
     * Excel workbook: (1) chainage table at a fixed interval with lat/lon, UTM and smoothed elevation,
     * (2) marked points with UTM. Engineers can use sheet 1 directly for an L-section.
     */
    public static byte[] chainageXlsx(Context c, List<TrackStore.Pt> pts, List<TrackStore.Mark> marks,
                                      String title, double startCh, double step) throws IOException {
        XlsxWriter w = new XlsxWriter();
        List<Object[]> t = new ArrayList<>();
        t.add(new Object[]{L.t("চেইনেজ", "Chainage"), L.t("চেইনেজ (মি)", "Chainage (m)"),
                L.t("অক্ষাংশ", "Latitude"), L.t("দ্রাঘিমাংশ", "Longitude"),
                "Easting (m)", "Northing (m)", "UTM zone", L.t("উচ্চতা (মি, আনুমানিক)", "Elevation (m, approx.)")});
        if (pts.size() >= 2) {
            double[] h = Profile.smooth(pts);
            double len = pts.get(pts.size() - 1).ch;
            double first = Math.ceil(startCh / step) * step;
            List<Double> stations = new ArrayList<>();
            stations.add(startCh);
            for (double s = first; s < startCh + len - 0.01; s += step) if (s > startCh + 0.01) stations.add(s);
            stations.add(startCh + len);
            int i = 1;
            for (double st : stations) {
                double raw = st - startCh;
                while (i < pts.size() - 1 && pts.get(i).ch < raw) i++;
                TrackStore.Pt a = pts.get(i - 1), b = pts.get(i);
                double f = b.ch - a.ch < 1e-6 ? 0 : Math.max(0, Math.min(1, (raw - a.ch) / (b.ch - a.ch)));
                double lat = a.lat + (b.lat - a.lat) * f, lon = a.lon + (b.lon - a.lon) * f;
                double el = h[i - 1] + (h[i] - h[i - 1]) * f;
                Geo.Utm u = Geo.utm(lat, lon);
                t.add(new Object[]{TrackStore.fmtCh(st), round(st, 2), round(lat, 7), round(lon, 7),
                        round(u.easting, 2), round(u.northing, 2), u.zoneLabel(), round(el, 1)});
            }
        }
        w.addSheet(L.t("চেইনেজ টেবিল", "Chainage table"), t);

        List<Object[]> m = new ArrayList<>();
        m.add(new Object[]{L.t("নং", "No."), L.t("নাম", "Name"), L.t("চেইনেজ", "Chainage"), L.t("অক্ষাংশ", "Latitude"),
                L.t("দ্রাঘিমাংশ", "Longitude"), "Easting (m)", "Northing (m)", "UTM zone",
                L.t("উচ্চতা (মি)", "Elevation (m)"), L.t("সময়", "Time"), L.t("ছবি", "Photo")});
        int n = 1;
        for (TrackStore.Mark k : marks) {
            Geo.Utm u = Geo.utm(k.lat, k.lon);
            m.add(new Object[]{n++, k.name, TrackStore.fmtCh(startCh + k.ch), round(k.lat, 7), round(k.lon, 7),
                    round(u.easting, 2), round(u.northing, 2), u.zoneLabel(), round(k.alt, 1), local(k.time),
                    Photos.displayName(c, k.photo)});
        }
        w.addSheet(L.t("চিহ্নিত পয়েন্ট", "Marked points"), m);

        List<Object[]> info = new ArrayList<>();
        info.add(new Object[]{L.t("বিষয়", "Item"), L.t("মান", "Value")});
        double len = pts.isEmpty() ? 0 : pts.get(pts.size() - 1).ch;
        info.add(new Object[]{L.t("সার্ভে", "Survey"), title});
        info.add(new Object[]{L.t("শুরুর চেইনেজ", "Start chainage"), TrackStore.fmtCh(startCh)});
        info.add(new Object[]{L.t("শেষ চেইনেজ", "End chainage"), TrackStore.fmtCh(startCh + len)});
        info.add(new Object[]{L.t("মোট দৈর্ঘ্য (মি)", "Total length (m)"), round(len, 2)});
        info.add(new Object[]{L.t("টেবিলের ব্যবধান (মি)", "Table interval (m)"), step});
        info.add(new Object[]{L.t("তৈরি", "Created"), local(System.currentTimeMillis())});
        info.add(new Object[]{"", AppSettings.DEVELOPER});
        w.addSheet(L.t("সারাংশ", "Summary"), info);
        return w.build();
    }

    private static Double round(double v, int digits) {
        double p = Math.pow(10, digits);
        return Math.round(v * p) / p;
    }

    public static String csv(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, double startCh) {
        StringBuilder sb = new StringBuilder();
        sb.append('﻿'); // lets Excel read Bengali names correctly
        sb.append("Type,No,Name,Latitude,Longitude,Easting_m,Northing_m,UTM_zone,Altitude_m,Accuracy_m,Chainage_m,Chainage,Time,Photo\n");
        int i = 1;
        for (TrackStore.Pt p : pts) {
            double ch = startCh + p.ch;
            Geo.Utm u = Geo.utm(p.lat, p.lon);
            sb.append(String.format(Locale.US, "TRACK,%d,,%.7f,%.7f,%.2f,%.2f,%s,%.1f,%.1f,%.2f,%s,%s,\n",
                    i++, p.lat, p.lon, u.easting, u.northing, u.zoneLabel(), p.alt, p.acc, ch, TrackStore.fmtCh(ch), local(p.time)));
        }
        i = 1;
        for (TrackStore.Mark m : marks) {
            double ch = startCh + m.ch;
            Geo.Utm u = Geo.utm(m.lat, m.lon);
            sb.append(String.format(Locale.US, "POINT,%d,%s,%.7f,%.7f,%.2f,%.2f,%s,%.1f,,%.2f,%s,%s,%s\n",
                    i++, csvCell(m.name), m.lat, m.lon, u.easting, u.northing, u.zoneLabel(), m.alt, ch, TrackStore.fmtCh(ch), local(m.time),
                    csvCell(photoLabel(m.photo))));
        }
        return sb.toString();
    }

    public static String gpx(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title, double startCh) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
                .append("<gpx version=\"1.1\" creator=\"RoadSurvey\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");
        int i = 1;
        for (TrackStore.Mark m : marks) {
            sb.append(String.format(Locale.US, "<wpt lat=\"%.7f\" lon=\"%.7f\"><ele>%.1f</ele><time>%s</time>",
                            m.lat, m.lon, m.alt, iso(m.time)))
                    .append("<name>").append(i++).append(". ").append(xml(m.name)).append("</name>")
                    .append("<desc>Chainage ").append(TrackStore.fmtCh(startCh + m.ch)).append("</desc></wpt>\n");
        }
        sb.append("<trk><name>").append(xml(title)).append("</name><trkseg>\n");
        for (TrackStore.Pt p : pts) {
            sb.append(String.format(Locale.US, "<trkpt lat=\"%.7f\" lon=\"%.7f\"><ele>%.1f</ele><time>%s</time></trkpt>\n",
                    p.lat, p.lon, p.alt, iso(p.time)));
        }
        sb.append("</trkseg></trk>\n</gpx>\n");
        return sb.toString();
    }

    public static Uri save(Context c, String fileName, String mime, String content) throws IOException {
        return save(c, fileName, mime, content.getBytes(StandardCharsets.UTF_8));
    }

    /** Saves bytes to Download/RoadSurvey/fileName. Returns a content Uri on Android 10+, otherwise null. */
    public static Uri save(Context c, String fileName, String mime, byte[] data) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER);
            Uri uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException(L.t("ফাইল তৈরি করা যায়নি", "Could not create the file"));
            try (OutputStream os = c.getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new IOException(L.t("ফাইল খোলা যায়নি", "Could not open the file"));
                os.write(data);
            }
            return uri;
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER);
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            try (FileOutputStream fos = new FileOutputStream(new File(dir, fileName))) {
                fos.write(data);
            }
            return null;
        }
    }
}
