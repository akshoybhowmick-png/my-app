package com.akshoy.roadsurvey;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Builds KML / CSV / GPX files and saves files in Download/RoadSurvey. */
public class Exporter {

    public static final String FOLDER = "RoadSurvey";

    private static String iso(long t) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(t));
    }

    public static String local(long t) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(t));
    }

    private static String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static String csvCell(String s) {
        if (s.contains(",") || s.contains("\"")) return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }

    /** Short photo file name from a content uri, for reports. */
    public static String photoLabel(String uri) {
        if (uri == null || uri.isEmpty()) return "";
        int slash = uri.lastIndexOf('/');
        return "ছবি #" + (slash >= 0 ? uri.substring(slash + 1) : uri);
    }

    public static String kml(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title, double startCh) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
                .append("<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n<Document>\n")
                .append("<name>").append(xml(title)).append("</name>\n")
                .append("<Style id=\"road\"><LineStyle><color>ff0000ff</color><width>4</width></LineStyle></Style>\n")
                .append("<Style id=\"km\"><IconStyle><scale>0.6</scale></IconStyle><LabelStyle><scale>0.8</scale></LabelStyle></Style>\n");
        if (!pts.isEmpty()) {
            double len = pts.get(pts.size() - 1).ch;
            sb.append("<Placemark>\n<name>").append(xml(title)).append("</name>\n")
                    .append("<description>Chainage ").append(TrackStore.fmtCh(startCh))
                    .append(" to ").append(TrackStore.fmtCh(startCh + len))
                    .append(", length ").append(String.format(Locale.US, "%.1f", len)).append(" m</description>\n")
                    .append("<styleUrl>#road</styleUrl>\n<LineString>\n<tessellate>1</tessellate>\n<coordinates>\n");
            for (TrackStore.Pt p : pts) {
                sb.append(String.format(Locale.US, "%.7f,%.7f,%.1f\n", p.lon, p.lat, p.alt));
            }
            sb.append("</coordinates>\n</LineString>\n</Placemark>\n");

            // kilometre stones
            sb.append("<Folder><name>Km chainage</name>\n");
            double next = Math.ceil(startCh / 1000.0) * 1000;
            for (int i = 1; i < pts.size(); i++) {
                TrackStore.Pt a = pts.get(i - 1), b = pts.get(i);
                double ca = startCh + a.ch, cb = startCh + b.ch;
                while (next <= cb) {
                    if (next >= ca) {
                        double f = cb - ca < 1e-6 ? 0 : (next - ca) / (cb - ca);
                        sb.append("<Placemark><name>").append(TrackStore.fmtCh(next))
                                .append("</name><styleUrl>#km</styleUrl><Point><coordinates>")
                                .append(String.format(Locale.US, "%.7f,%.7f,0",
                                        a.lon + (b.lon - a.lon) * f, a.lat + (b.lat - a.lat) * f))
                                .append("</coordinates></Point></Placemark>\n");
                    }
                    next += 1000;
                }
            }
            sb.append("</Folder>\n");
        }
        sb.append("<Folder><name>Points</name>\n");
        int i = 1;
        for (TrackStore.Mark m : marks) {
            sb.append("<Placemark>\n<name>").append(i++).append(". ").append(xml(m.name)).append("</name>\n")
                    .append("<description>Chainage ").append(TrackStore.fmtCh(startCh + m.ch))
                    .append(" | ").append(local(m.time));
            if (!m.photo.isEmpty()) sb.append(" | ").append(xml(photoLabel(m.photo)));
            sb.append("</description>\n<Point><coordinates>")
                    .append(String.format(Locale.US, "%.7f,%.7f,%.1f", m.lon, m.lat, m.alt))
                    .append("</coordinates></Point>\n</Placemark>\n");
        }
        sb.append("</Folder>\n</Document>\n</kml>\n");
        return sb.toString();
    }

    public static String csv(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, double startCh) {
        StringBuilder sb = new StringBuilder();
        sb.append('﻿'); // lets Excel read Bengali names correctly
        sb.append("Type,No,Name,Latitude,Longitude,Altitude_m,Accuracy_m,Chainage_m,Chainage,Time,Photo\n");
        int i = 1;
        for (TrackStore.Pt p : pts) {
            double ch = startCh + p.ch;
            sb.append(String.format(Locale.US, "TRACK,%d,,%.7f,%.7f,%.1f,%.1f,%.2f,%s,%s,\n",
                    i++, p.lat, p.lon, p.alt, p.acc, ch, TrackStore.fmtCh(ch), local(p.time)));
        }
        i = 1;
        for (TrackStore.Mark m : marks) {
            double ch = startCh + m.ch;
            sb.append(String.format(Locale.US, "POINT,%d,%s,%.7f,%.7f,%.1f,,%.2f,%s,%s,%s\n",
                    i++, csvCell(m.name), m.lat, m.lon, m.alt, ch, TrackStore.fmtCh(ch), local(m.time),
                    csvCell(photoLabel(m.photo))));
        }
        return sb.toString();
    }

    public static String gpx(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title, double startCh) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
                .append("<gpx version=\"1.1\" creator=\"RoadSurvey\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");
        int i = 1;
        for (TrackStore.Mark m : marks) {
            sb.append(String.format(Locale.US, "<wpt lat=\"%.7f\" lon=\"%.7f\"><ele>%.1f</ele><time>%s</time>",
                            m.lat, m.lon, m.alt, iso(m.time)))
                    .append("<name>").append(i++).append(". ").append(xml(m.name)).append("</name>")
                    .append("<desc>Chainage ").append(TrackStore.fmtCh(startCh + m.ch)).append("</desc></wpt>\n");
        }
        sb.append("<trk><name>").append(xml(title)).append("</name><trkseg>\n");
        for (TrackStore.Pt p : pts) {
            sb.append(String.format(Locale.US, "<trkpt lat=\"%.7f\" lon=\"%.7f\"><ele>%.1f</ele><time>%s</time></trkpt>\n",
                    p.lat, p.lon, p.alt, iso(p.time)));
        }
        sb.append("</trkseg></trk>\n</gpx>\n");
        return sb.toString();
    }

    public static Uri save(Context c, String fileName, String mime, String content) throws IOException {
        return save(c, fileName, mime, content.getBytes(StandardCharsets.UTF_8));
    }

    /** Saves bytes to Download/RoadSurvey/fileName. Returns a content Uri on Android 10+, otherwise null. */
    public static Uri save(Context c, String fileName, String mime, byte[] data) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER);
            Uri uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("ফাইল তৈরি করা যায়নি");
            try (OutputStream os = c.getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new IOException("ফাইল খোলা যায়নি");
                os.write(data);
            }
            return uri;
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER);
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            try (FileOutputStream fos = new FileOutputStream(new File(dir, fileName))) {
                fos.write(data);
            }
            return null;
        }
    }
}
