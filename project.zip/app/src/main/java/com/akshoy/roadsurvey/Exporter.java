package com.akshoy.roadsurvey;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Builds KML / CSV / GPX files and saves files in Download/RoadSurvey. */
public class Exporter {

    public static final String FOLDER = "RoadSurvey";

    private static String iso(long t) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(t));
    }

    public static String local(long t) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(t));
    }

    private static String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static String csvCell(String s) {
        if (s.contains(",") || s.contains("\"")) return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }

    /** Short photo file name from a content uri, for reports. */
    public static String photoLabel(String uri) {
        if (uri == null || uri.isEmpty()) return "";
        if (!uri.startsWith("content:") && !uri.startsWith("file:")) return L.t("ছবি: ", "Photo: ") + uri; // already a file name
        int slash = uri.lastIndexOf('/');
        return L.t("ছবি #", "Photo #") + (slash >= 0 ? uri.substring(slash + 1) : uri);
    }

    public static String kml(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title, double startCh) {
        return kml(pts, marks, title, startCh, null, null, null);
    }

    public static String kml(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title, double startCh,
                             String[] photoPaths) {
        return kml(pts, marks, title, startCh, photoPaths, null, null);
    }

    /** Part of the line that a video covers (with exact start / end positions). */
    public static List<double[]> videoPath(List<TrackStore.Pt> pts, TrackStore.VideoRec v) {
        List<double[]> out = new ArrayList<>();
        double[] a = TrackStore.positionAt(pts, v.start), z = TrackStore.positionAt(pts, v.end);
        if (a == null) return out;
        out.add(new double[]{a[0], a[1], a[2], v.start});
        for (TrackStore.Pt p : pts) if (p.time > v.start && p.time < v.end) out.add(new double[]{p.lat, p.lon, p.ch, p.time});
        out.add(new double[]{z[0], z[1], z[2], v.end});
        return out;
    }

    /** A still picture taken from a video at a place on the road (for the KMZ). */
    public static class Frame {
        public int video;      // 0-based video index
        public double lat, lon, ch;
        public long time;
        public String file;    // path inside the KMZ
    }

    /** Places every 'step' metres along a video's stretch: {lat, lon, ch, time}. */
    public static List<double[]> frameSpots(List<double[]> path, double step) {
        List<double[]> out = new ArrayList<>();
        if (path.size() < 2 || step <= 0) return out;
        double dist = 0, next = 0;
        for (int i = 1; i < path.size(); i++) {
            double[] a = path.get(i - 1), b = path.get(i);
            double d = TrackStore.distance(a[0], a[1], b[0], b[1]);
            while (next <= dist + d) {
                double f = d < 1e-6 ? 0 : (next - dist) / d;
                out.add(new double[]{a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f, a[3] + (b[3] - a[3]) * f});
                next += step;
            }
            dist += d;
        }
        return out;
    }

    /**
     * photoPaths[i] = path of mark i's photo inside a KMZ (or null).
     * videos = video recordings shown as purple stretches of the road; frames = pictures taken from them (or null).
     */
    public static String kml(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title, double startCh,
                             String[] photoPaths, List<TrackStore.VideoRec> videos, List<Frame> frames) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
                .append("<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n<Document>\n")
                .append("<name>").append(xml(title)).append("</name>\n")
                .append("<description>").append(AppSettings.DEVELOPER).append("</description>\n")
                .append("<Style id=\"road\"><LineStyle><color>ff0000ff</color><width>4</width></LineStyle></Style>\n")
                .append("<Style id=\"km\"><IconStyle><scale>0.6</scale></IconStyle><LabelStyle><scale>0.8</scale></LabelStyle></Style>\n")
                .append("<Style id=\"video\"><LineStyle><color>ffb0279c</color><width>9</width></LineStyle>")
                .append("<IconStyle><color>ffb0279c</color><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/shapes/movies.png</href></Icon></IconStyle></Style>\n")
                .append("<Style id=\"vframe\"><IconStyle><color>ffb0279c</color><scale>0.7</scale><Icon><href>http://maps.google.com/mapfiles/kml/shapes/camera.png</href></Icon></IconStyle>")
                .append("<LabelStyle><scale>0</scale></LabelStyle></Style>\n");
        if (!pts.isEmpty()) {
            double len = pts.get(pts.size() - 1).ch;
            sb.append("<Placemark>\n<name>").append(xml(title)).append("</name>\n")
                    .append("<description>Chainage ").append(TrackStore.fmtCh(startCh))
                    .append(" to ").append(TrackStore.fmtCh(startCh + len))
                    .append(", length ").append(String.format(Locale.US, "%.1f", len)).append(" m</description>\n")
                    .append("<styleUrl>#road</styleUrl>\n<LineString>\n<tessellate>1</tessellate>\n<coordinates>\n");
            for (TrackStore.Pt p : pts) {
                sb.append(String.format(Locale.US, "%.7f,%.7f,%.1f\n", p.lon, p.lat, p.alt));
            }
            sb.append("</coordinates>\n</LineString>\n</Placemark>\n");

            // kilometre stones
            sb.append("<Folder><name>Km chainage</name>\n");
            double next = Math.ceil(startCh / 1000.0) * 1000;
            for (int i = 1; i < pts.size(); i++) {
                TrackStore.Pt a = pts.get(i - 1), b = pts.get(i);
                double ca = startCh + a.ch, cb = startCh + b.ch;
                while (next <= cb) {
                    if (next >= ca) {
                        double f = cb - ca < 1e-6 ? 0 : (next - ca) / (cb - ca);
                        sb.append("<Placemark><name>").append(TrackStore.fmtCh(next))
                                .append("</name><styleUrl>#km</styleUrl><Point><coordinates>")
                                .append(String.format(Locale.US, "%.7f,%.7f,0",
                                        a.lon + (b.lon - a.lon) * f, a.lat + (b.lat - a.lat) * f))
                                .append("</coordinates></Point></Placemark>\n");
                    }
                    next += 1000;
                }
            }
            sb.append("</Folder>\n");
        }
        sb.append("<Folder><name>Points</name>\n");
        int i = 1;
        for (TrackStore.Mark m : marks) {
            String img = photoPaths != null && i - 1 < photoPaths.length ? photoPaths[i - 1] : null;
            sb.append("<Placemark>\n<name>").append(i).append(". ").append(xml(m.name)).append("</name>\n");
            if (img != null) {
                sb.append("<description><![CDATA[<b>Chainage ").append(TrackStore.fmtCh(startCh + m.ch))
                        .append("</b><br/>").append(local(m.time))
                        .append("<br/>");
                for (String one : img.split("\\|")) {
                    sb.append("<img src=\"").append(one).append("\" width=\"480\"/><br/>");
                }
                sb.append("]]>");
            } else {
                sb.append("<description>Chainage ").append(TrackStore.fmtCh(startCh + m.ch))
                        .append(" | ").append(local(m.time));
                if (!m.photo.isEmpty()) sb.append(" | ").append(xml(photoLabel(m.photo)));
            }
            i++;
            sb.append("</description>\n<Point><coordinates>")
                    .append(String.format(Locale.US, "%.7f,%.7f,%.1f", m.lon, m.lat, m.alt))
                    .append("</coordinates></Point>\n</Placemark>\n");
        }
        sb.append("</Folder>\n");
        if (videos != null && !videos.isEmpty() && pts.size() >= 2) {
            sb.append("<Folder><name>Videos</name>\n");
            for (int k = 0; k < videos.size(); k++) {
                TrackStore.VideoRec v = videos.get(k);
                List<double[]> path = videoPath(pts, v);
                if (path.size() < 2) continue;
                long sec = Math.max(0, (v.end - v.start) / 1000);
                StringBuilder d = new StringBuilder();
                d.append("<b>").append(xml(v.name)).append("</b><br/>Chainage ")
                        .append(TrackStore.fmtCh(startCh + path.get(0)[2])).append(" – ")
                        .append(TrackStore.fmtCh(startCh + path.get(path.size() - 1)[2])).append("<br/>")
                        .append(local(v.start)).append(String.format(Locale.US, " (%d:%02d)", sec / 60, sec % 60));
                d.append("<br/>Video file: Download/").append(FOLDER).append("/").append(xml(v.name));
                if (frames == null) {
                    // plain KML: it sits next to the video in Download/RoadSurvey, so a relative link finds it
                    // (copy the KML and the .mp4 together into one folder on the computer)
                    String rel = xml(v.name).replace(" ", "%20");
                    d.append("<br/><video controls autoplay width=\"560\" src=\"").append(rel).append("\"></video>")
                            .append("<br/><a href=\"").append(rel).append("\">&#9654; Open the video</a>");
                }
                String desc = "<![CDATA[" + d + "]]>";
                sb.append("<Placemark><name>Video ").append(k + 1).append("</name><description>").append(desc)
                        .append("</description><styleUrl>#video</styleUrl><LineString><tessellate>1</tessellate><coordinates>\n");
                for (double[] q : path) sb.append(String.format(Locale.US, "%.7f,%.7f,0\n", q[1], q[0]));
                sb.append("</coordinates></LineString></Placemark>\n");
                sb.append("<Placemark><name>&#127916; Video ").append(k + 1).append("</name><description>").append(desc)
                        .append("</description><styleUrl>#video</styleUrl><Point><coordinates>")
                        .append(String.format(Locale.US, "%.7f,%.7f,0", path.get(0)[1], path.get(0)[0]))
                        .append("</coordinates></Point></Placemark>\n");
            }
            if (frames != null && !frames.isEmpty()) {
                sb.append("<Folder><name>Video pictures</name>\n");
                for (Frame f : frames) {
                    sb.append("<Placemark><name>").append(TrackStore.fmtCh(startCh + f.ch)).append("</name><description><![CDATA[<b>Chainage ")
                            .append(TrackStore.fmtCh(startCh + f.ch)).append("</b> &nbsp; Video ").append(f.video + 1).append(" &nbsp; ")
                            .append(local(f.time)).append("<br/><img src=\"").append(f.file).append("\" width=\"560\"/>]]></description>")
                            .append("<styleUrl>#vframe</styleUrl><Point><coordinates>")
                            .append(String.format(Locale.US, "%.7f,%.7f,0", f.lon, f.lat)).append("</coordinates></Point></Placemark>\n");
                }
                sb.append("</Folder>\n");
            }
            sb.append("</Folder>\n");
        }
        sb.append("</Document>\n</kml>\n");
        return sb.toString();
    }

    public interface StreamWriter {
        void write(OutputStream os) throws IOException;
    }

    /** Size of a content / file uri in bytes, or -1. */
    public static long sizeOf(Context c, String uriString) {
        try {
            Uri u = Uri.parse(uriString);
            if ("file".equals(u.getScheme())) return new File(u.getPath()).length();
            try (android.database.Cursor cur = c.getContentResolver().query(u,
                    new String[]{android.provider.OpenableColumns.SIZE}, null, null, null)) {
                if (cur != null && cur.moveToFirst() && !cur.isNull(0)) return cur.getLong(0);
            }
        } catch (Exception ignored) {
        }
        return -1;
    }

    /**
     * KMZ written straight into the file (videos can be hundreds of MB, too big for memory):
     * KML + point photos + (optionally) the video files, so Google Earth can show and play them.
     */
    public static void kmzTo(Context c, OutputStream os, List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title,
                             double startCh, List<TrackStore.VideoRec> videos, double frameStep) throws IOException {
        String[] paths = new String[marks.size()];
        List<Frame> frames = new ArrayList<>();
        java.util.zip.ZipOutputStream zip = new java.util.zip.ZipOutputStream(new java.io.BufferedOutputStream(os, 65536));
        for (int i = 0; i < marks.size(); i++) {
            List<String> ph = marks.get(i).photos();
            StringBuilder joined = new StringBuilder();
            for (int j = 0; j < ph.size(); j++) {
                android.graphics.Bitmap b = Photos.load(c, ph.get(j), 1280);
                if (b == null) continue;
                String path = "files/point_" + (i + 1) + "_" + (j + 1) + ".jpg";
                zip.putNextEntry(new java.util.zip.ZipEntry(path));
                b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, zip);
                b.recycle();
                zip.closeEntry();
                if (joined.length() > 0) joined.append('|');
                joined.append(path);
            }
            if (joined.length() > 0) paths[i] = joined.toString();
        }
        // pictures from the videos every 'frameStep' metres (Google Earth cannot play phone videos, but shows pictures)
        if (frameStep > 0 && videos != null) {
            for (int k = 0; k < videos.size(); k++) {
                TrackStore.VideoRec v = videos.get(k);
                List<double[]> spots = frameSpots(videoPath(pts, v), frameStep);
                if (spots.isEmpty()) continue;
                android.media.MediaMetadataRetriever mr = new android.media.MediaMetadataRetriever();
                try {
                    mr.setDataSource(c, Uri.parse(v.uri));
                    int n = 0;
                    for (double[] q : spots) {
                        if (frames.size() >= 600) break;
                        long us = Math.max(0, (long) q[3] - v.start) * 1000L;
                        android.graphics.Bitmap bm = mr.getFrameAtTime(us, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                        if (bm == null) continue;
                        int w = bm.getWidth(), h = bm.getHeight();
                        if (w > 960) {
                            android.graphics.Bitmap sc = android.graphics.Bitmap.createScaledBitmap(bm, 960, Math.max(1, h * 960 / w), true);
                            if (sc != bm) bm.recycle();
                            bm = sc;
                        }
                        String path = "files/video" + (k + 1) + "_" + (++n) + ".jpg";
                        zip.putNextEntry(new java.util.zip.ZipEntry(path));
                        bm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, zip);
                        bm.recycle();
                        zip.closeEntry();
                        Frame f = new Frame();
                        f.video = k;
                        f.lat = q[0];
                        f.lon = q[1];
                        f.ch = q[2];
                        f.time = (long) q[3];
                        f.file = path;
                        frames.add(f);
                    }
                } catch (Exception e) {
                    // video deleted or unreadable: keep only its purple stretch
                } finally {
                    try {
                        mr.release();
                    } catch (Exception ignored) {
                    }
                }
            }
        }
        zip.putNextEntry(new java.util.zip.ZipEntry("doc.kml"));
        zip.write(kml(pts, marks, title, startCh, paths, videos, frames).getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
        zip.finish();
        zip.flush();
    }

    /** KMZ = zipped KML with the point photos inside, so Google Earth shows them. */
    public static byte[] kmz(Context c, List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title,
                             double startCh) throws IOException {
        String[] paths = new String[marks.size()];
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        try (java.util.zip.ZipOutputStream zip = new java.util.zip.ZipOutputStream(bos)) {
            for (int i = 0; i < marks.size(); i++) {
                List<String> ph = marks.get(i).photos();
                StringBuilder joined = new StringBuilder();
                for (int j = 0; j < ph.size(); j++) {
                    android.graphics.Bitmap b = Photos.load(c, ph.get(j), 1280);
                    if (b == null) continue;
                    String path = "files/point_" + (i + 1) + "_" + (j + 1) + ".jpg";
                    zip.putNextEntry(new java.util.zip.ZipEntry(path));
                    b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, zip);
                    b.recycle();
                    zip.closeEntry();
                    if (joined.length() > 0) joined.append('|');
                    joined.append(path);
                }
                if (joined.length() > 0) paths[i] = joined.toString();
            }
            zip.putNextEntry(new java.util.zip.ZipEntry("doc.kml"));
            zip.write(kml(pts, marks, title, startCh, paths).getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        }
        return bos.toByteArray();
    }

    /**
     * Excel workbook: (1) chainage table at a fixed interval with lat/lon, UTM and smoothed elevation,
     * (2) marked points with UTM. Engineers can use sheet 1 directly for an L-section.
     */
    public static byte[] chainageXlsx(Context c, List<TrackStore.Pt> pts, List<TrackStore.Mark> marks,
                                      List<TrackStore.Seg> segs, String title, double startCh, double step) throws IOException {
        XlsxWriter w = new XlsxWriter();
        List<Object[]> t = new ArrayList<>();
        t.add(new Object[]{L.t("চেইনেজ", "Chainage"), L.t("চেইনেজ (মি)", "Chainage (m)"),
                L.t("অক্ষাংশ", "Latitude"), L.t("দ্রাঘিমাংশ", "Longitude"),
                "Easting (m)", "Northing (m)", "UTM zone", L.t("উচ্চতা (মি, আনুমানিক)", "Elevation (m, approx.)")});
        if (pts.size() >= 2) {
            double[] h = Profile.smooth(pts);
            double len = pts.get(pts.size() - 1).ch;
            double first = Math.ceil(startCh / step) * step;
            List<Double> stations = new ArrayList<>();
            stations.add(startCh);
            for (double s = first; s < startCh + len - 0.01; s += step) if (s > startCh + 0.01) stations.add(s);
            stations.add(startCh + len);
            int i = 1;
            for (double st : stations) {
                double raw = st - startCh;
                while (i < pts.size() - 1 && pts.get(i).ch < raw) i++;
                TrackStore.Pt a = pts.get(i - 1), b = pts.get(i);
                double f = b.ch - a.ch < 1e-6 ? 0 : Math.max(0, Math.min(1, (raw - a.ch) / (b.ch - a.ch)));
                double lat = a.lat + (b.lat - a.lat) * f, lon = a.lon + (b.lon - a.lon) * f;
                double el = h[i - 1] + (h[i] - h[i - 1]) * f;
                Geo.Utm u = Geo.utm(lat, lon);
                t.add(new Object[]{TrackStore.fmtCh(st), round(st, 2), round(lat, 7), round(lon, 7),
                        round(u.easting, 2), round(u.northing, 2), u.zoneLabel(), round(el, 1)});
            }
        }
        w.addSheet(L.t("চেইনেজ টেবিল", "Chainage table"), t);

        List<Object[]> m = new ArrayList<>();
        m.add(new Object[]{L.t("নং", "No."), L.t("নাম", "Name"), L.t("চেইনেজ", "Chainage"), L.t("অক্ষাংশ", "Latitude"),
                L.t("দ্রাঘিমাংশ", "Longitude"), "Easting (m)", "Northing (m)", "UTM zone",
                L.t("উচ্চতা (মি)", "Elevation (m)"), L.t("সময়", "Time"), L.t("ছবি", "Photo")});
        int n = 1;
        for (TrackStore.Mark k : marks) {
            Geo.Utm u = Geo.utm(k.lat, k.lon);
            m.add(new Object[]{n++, k.name, TrackStore.fmtCh(startCh + k.ch), round(k.lat, 7), round(k.lon, 7),
                    round(u.easting, 2), round(u.northing, 2), u.zoneLabel(), round(k.alt, 1), local(k.time),
                    photoNames(c, k.photo)});
        }
        w.addSheet(L.t("চিহ্নিত পয়েন্ট", "Marked points"), m);

        List<Object[]> cv = new ArrayList<>();
        cv.add(new Object[]{L.t("নং", "No."), L.t("শুরু চেইনেজ", "Start chainage"), L.t("শেষ চেইনেজ", "End chainage"),
                L.t("দিক", "Direction"), L.t("কোণ (°)", "Deflection (°)"), L.t("ব্যাসার্ধ (মি, আনুমানিক)", "Radius (m, approx.)"),
                L.t("বাঁকের দৈর্ঘ্য (মি)", "Curve length (m)"), L.t("ট্যানজেন্ট দৈর্ঘ্য (মি)", "Tangent length (m)"),
                L.t("মাঝের অক্ষাংশ", "Mid latitude"), L.t("মাঝের দ্রাঘিমাংশ", "Mid longitude")});
        int cn = 1;
        for (Curves.Curve cu : Curves.find(pts)) {
            cv.add(new Object[]{cn++, TrackStore.fmtCh(startCh + cu.startCh), TrackStore.fmtCh(startCh + cu.endCh),
                    cu.right ? L.t("ডানে", "Right") : L.t("বাঁয়ে", "Left"), round(cu.deflection, 1), round(cu.radius, 0),
                    round(cu.length, 0), Double.isNaN(cu.tangent) ? null : round(cu.tangent, 0),
                    round(cu.midLat, 7), round(cu.midLon, 7)});
        }
        w.addSheet(L.t("বাঁক", "Curves"), cv);

        List<Object[]> sg = new ArrayList<>();
        sg.add(new Object[]{L.t("থেকে", "From"), L.t("পর্যন্ত", "To"), L.t("দৈর্ঘ্য (মি)", "Length (m)"),
                L.t("ধরন", "Surface"), L.t("অবস্থা", "Condition"), L.t("চওড়া (মি)", "Width (m)")});
        double total = pts.isEmpty() ? 0 : pts.get(pts.size() - 1).ch;
        for (int q = 0; q < segs.size(); q++) {
            TrackStore.Seg g = segs.get(q);
            double to = q + 1 < segs.size() ? segs.get(q + 1).ch : total;
            sg.add(new Object[]{TrackStore.fmtCh(startCh + g.ch), TrackStore.fmtCh(startCh + to), round(Math.max(0, to - g.ch), 1),
                    g.surface, g.condition, Double.isNaN(g.width) ? null : round(g.width, 2)});
        }
        w.addSheet(L.t("রাস্তার অংশ", "Road segments"), sg);

        List<Object[]> info = new ArrayList<>();
        info.add(new Object[]{L.t("বিষয়", "Item"), L.t("মান", "Value")});
        double len = pts.isEmpty() ? 0 : pts.get(pts.size() - 1).ch;
        info.add(new Object[]{L.t("সার্ভে", "Survey"), title});
        info.add(new Object[]{L.t("শুরুর চেইনেজ", "Start chainage"), TrackStore.fmtCh(startCh)});
        info.add(new Object[]{L.t("শেষ চেইনেজ", "End chainage"), TrackStore.fmtCh(startCh + len)});
        info.add(new Object[]{L.t("মোট দৈর্ঘ্য (মি)", "Total length (m)"), round(len, 2)});
        info.add(new Object[]{L.t("টেবিলের ব্যবধান (মি)", "Table interval (m)"), step});
        info.add(new Object[]{L.t("তৈরি", "Created"), local(System.currentTimeMillis())});
        info.add(new Object[]{"", AppSettings.DEVELOPER});
        w.addSheet(L.t("সারাংশ", "Summary"), info);
        return w.build();
    }

    /** Gallery file names of all photos of a mark, joined with "; ". */
    public static String photoNames(Context c, String field) {
        StringBuilder sb = new StringBuilder();
        for (String u : TrackStore.photosOf(field)) {
            String n = Photos.displayName(c, u);
            if (n.isEmpty()) continue;
            if (sb.length() > 0) sb.append("; ");
            sb.append(n);
        }
        return sb.toString();
    }

    private static Double round(double v, int digits) {
        double p = Math.pow(10, digits);
        return Math.round(v * p) / p;
    }

    public static String csv(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, double startCh) {
        StringBuilder sb = new StringBuilder();
        sb.append('﻿'); // lets Excel read Bengali names correctly
        sb.append("Type,No,Name,Latitude,Longitude,Easting_m,Northing_m,UTM_zone,Altitude_m,Accuracy_m,Chainage_m,Chainage,Time,Photo\n");
        int i = 1;
        for (TrackStore.Pt p : pts) {
            double ch = startCh + p.ch;
            Geo.Utm u = Geo.utm(p.lat, p.lon);
            sb.append(String.format(Locale.US, "TRACK,%d,,%.7f,%.7f,%.2f,%.2f,%s,%.1f,%.1f,%.2f,%s,%s,\n",
                    i++, p.lat, p.lon, u.easting, u.northing, u.zoneLabel(), p.alt, p.acc, ch, TrackStore.fmtCh(ch), local(p.time)));
        }
        i = 1;
        for (TrackStore.Mark m : marks) {
            double ch = startCh + m.ch;
            Geo.Utm u = Geo.utm(m.lat, m.lon);
            sb.append(String.format(Locale.US, "POINT,%d,%s,%.7f,%.7f,%.2f,%.2f,%s,%.1f,,%.2f,%s,%s,%s\n",
                    i++, csvCell(m.name), m.lat, m.lon, u.easting, u.northing, u.zoneLabel(), m.alt, ch, TrackStore.fmtCh(ch), local(m.time),
                    csvCell(photoLabel(m.photo))));
        }
        return sb.toString();
    }

    public static String gpx(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, String title, double startCh) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
                .append("<gpx version=\"1.1\" creator=\"RoadSurvey\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");
        int i = 1;
        for (TrackStore.Mark m : marks) {
            sb.append(String.format(Locale.US, "<wpt lat=\"%.7f\" lon=\"%.7f\"><ele>%.1f</ele><time>%s</time>",
                            m.lat, m.lon, m.alt, iso(m.time)))
                    .append("<name>").append(i++).append(". ").append(xml(m.name)).append("</name>")
                    .append("<desc>Chainage ").append(TrackStore.fmtCh(startCh + m.ch)).append("</desc></wpt>\n");
        }
        sb.append("<trk><name>").append(xml(title)).append("</name><trkseg>\n");
        for (TrackStore.Pt p : pts) {
            sb.append(String.format(Locale.US, "<trkpt lat=\"%.7f\" lon=\"%.7f\"><ele>%.1f</ele><time>%s</time></trkpt>\n",
                    p.lat, p.lon, p.alt, iso(p.time)));
        }
        sb.append("</trkseg></trk>\n</gpx>\n");
        return sb.toString();
    }

    public static Uri save(Context c, String fileName, String mime, String content) throws IOException {
        return save(c, fileName, mime, content.getBytes(StandardCharsets.UTF_8));
    }

    /** Like save(), but the content is written by 'w' directly into the file (for very large files). */
    public static Uri saveStream(Context c, String fileName, String mime, StreamWriter w) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER);
            Uri uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException(L.t("ফাইল তৈরি করা যায়নি", "Could not create the file"));
            try (OutputStream os = c.getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new IOException(L.t("ফাইল খোলা যায়নি", "Could not open the file"));
                w.write(os);
            } catch (IOException | RuntimeException e) {
                try {
                    c.getContentResolver().delete(uri, null, null);
                } catch (Exception ignored) {
                }
                throw e;
            }
            return uri;
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER);
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            try (FileOutputStream fos = new FileOutputStream(new File(dir, fileName))) {
                w.write(fos);
            }
            return null;
        }
    }

    /** Saves bytes to Download/RoadSurvey/fileName. Returns a content Uri on Android 10+, otherwise null. */
    public static Uri save(Context c, String fileName, String mime, byte[] data) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER);
            Uri uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException(L.t("ফাইল তৈরি করা যায়নি", "Could not create the file"));
            try (OutputStream os = c.getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new IOException(L.t("ফাইল খোলা যায়নি", "Could not open the file"));
                os.write(data);
            }
            return uri;
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER);
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            try (FileOutputStream fos = new FileOutputStream(new File(dir, fileName))) {
                fos.write(data);
            }
            return null;
        }
    }
}
