package com.akshoy.roadsurvey;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.FallbackStrategy;
import androidx.camera.video.FileOutputOptions;
import androidx.camera.video.MediaStoreOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Records road video while GPS tracking keeps running, and saves a chainage subtitle (.srt) with it. */
public class VideoActivity extends ComponentActivity implements TrackStore.Listener {

    private static final int REQ_PERMS = 21;

    private TrackStore store;
    private PreviewView preview;
    private VideoCapture<Recorder> videoCapture;
    private Recording recording;
    private long recStart = 0;
    private String recBase;

    private TextView tvCh, tvInfo, tvRec;
    private Button btnRec;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            updateTimer();
            handler.postDelayed(this, 500);
        }
    };

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(AppSettings.videoLandscape(this)
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        store = TrackStore.get(this);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        preview = new PreviewView(this);
        root.addView(preview, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        // info card (top-left)
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(150, 0, 0, 0));
        bg.setCornerRadius(dp(12));
        info.setBackground(bg);
        tvCh = new TextView(this);
        tvCh.setTextColor(Color.WHITE);
        tvCh.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tvCh.setTypeface(Typeface.DEFAULT_BOLD);
        tvInfo = new TextView(this);
        tvInfo.setTextColor(Color.rgb(230, 230, 230));
        tvInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        TextView dev = new TextView(this);
        dev.setText(AppSettings.DEVELOPER);
        dev.setTextColor(Color.rgb(144, 202, 249));
        dev.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        info.addView(tvCh);
        info.addView(tvInfo);
        info.addView(dev);
        FrameLayout.LayoutParams infoLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        infoLp.setMargins(dp(12), dp(12), dp(12), dp(12));
        root.addView(info, infoLp);

        // recording indicator (top-right)
        tvRec = new TextView(this);
        tvRec.setTextColor(Color.WHITE);
        tvRec.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tvRec.setTypeface(Typeface.DEFAULT_BOLD);
        tvRec.setPadding(dp(10), dp(4), dp(10), dp(4));
        FrameLayout.LayoutParams recLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        recLp.setMargins(dp(12), dp(16), dp(16), dp(12));
        root.addView(tvRec, recLp);

        // buttons (bottom)
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER);
        Button btnMark = roundButton("📍 মার্ক", Color.rgb(239, 108, 0));
        btnRec = roundButton("⏺ রেকর্ড", Color.rgb(198, 40, 40));
        Button btnClose = roundButton("✕ বন্ধ", Color.rgb(69, 90, 100));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(120), dp(56));
        blp.setMargins(dp(8), 0, dp(8), 0);
        bar.addView(btnMark, blp);
        bar.addView(btnRec, new LinearLayout.LayoutParams(blp));
        bar.addView(btnClose, new LinearLayout.LayoutParams(blp));
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        barLp.setMargins(0, 0, 0, dp(20));
        root.addView(bar, barLp);

        setContentView(root);

        btnRec.setOnClickListener(v -> {
            if (recording != null) stopRecording();
            else startRecording();
        });
        btnMark.setOnClickListener(v -> markHere());
        btnClose.setOnClickListener(v -> closeScreen());

        List<String> need = missingPermissions();
        if (need.isEmpty()) startCamera();
        else requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    private Button roundButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(28));
        b.setBackground(g);
        return b;
    }

    private boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private List<String> missingPermissions() {
        List<String> need = new ArrayList<>();
        if (!has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
        if (AppSettings.videoAudio(this) && !has(Manifest.permission.RECORD_AUDIO))
            need.add(Manifest.permission.RECORD_AUDIO);
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION);
            need.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (Build.VERSION.SDK_INT < 29 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE))
            need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS))
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        return need;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) return;
        if (!has(Manifest.permission.CAMERA)) {
            Toast.makeText(this, "ক্যামেরার অনুমতি ছাড়া ভিডিও তোলা যাবে না।", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        startCamera();
    }

    // ---------- Camera ----------

    private void startCamera() {
        final ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview p = new Preview.Builder().build();
                p.setSurfaceProvider(preview.getSurfaceProvider());

                int q = AppSettings.videoQuality(this);
                Quality quality = q >= 1080 ? Quality.FHD : (q >= 720 ? Quality.HD : Quality.SD);
                Recorder recorder = new Recorder.Builder()
                        .setQualitySelector(QualitySelector.from(quality,
                                FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
                        .build();
                videoCapture = VideoCapture.withOutput(recorder);

                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, p, videoCapture);
            } catch (Exception e) {
                new AlertDialog.Builder(this)
                        .setTitle("ক্যামেরা চালু হয়নি")
                        .setMessage(String.valueOf(e.getMessage()))
                        .setPositiveButton("ঠিক আছে", (d, w) -> finish())
                        .show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void ensureTracking() {
        if (store.tracking || !has(Manifest.permission.ACCESS_FINE_LOCATION)) return;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this, "ফোনের GPS বন্ধ! ভিডিও হবে, কিন্তু চেইনেজ পাওয়া যাবে না।", Toast.LENGTH_LONG).show();
            return;
        }
        Intent i = new Intent(this, TrackingService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        Toast.makeText(this, "GPS রেকর্ডও চালু হলো।", Toast.LENGTH_SHORT).show();
    }

    private void startRecording() {
        if (videoCapture == null) {
            Toast.makeText(this, "ক্যামেরা এখনও তৈরি হয়নি, একটু অপেক্ষা করুন।", Toast.LENGTH_SHORT).show();
            return;
        }
        ensureTracking();
        recBase = safeName(store.name) + "_video_"
                + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());

        Recorder recorder = videoCapture.getOutput();
        PendingRecording pending;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, recBase + ".mp4");
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + Exporter.FOLDER);
            MediaStoreOutputOptions opts = new MediaStoreOutputOptions.Builder(getContentResolver(),
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI).setContentValues(cv).build();
            pending = recorder.prepareRecording(this, opts);
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    Exporter.FOLDER);
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            FileOutputOptions opts = new FileOutputOptions.Builder(new File(dir, recBase + ".mp4")).build();
            pending = recorder.prepareRecording(this, opts);
        }
        if (AppSettings.videoAudio(this) && has(Manifest.permission.RECORD_AUDIO)) {
            try {
                pending = pending.withAudioEnabled();
            } catch (SecurityException ignored) {
            }
        }

        final Context app = getApplicationContext();
        final String base = recBase;
        final String surveyName = store.name;
        final double startCh = store.startCh;
        recording = pending.start(ContextCompat.getMainExecutor(this), event -> {
            if (event instanceof VideoRecordEvent.Start) {
                recStart = System.currentTimeMillis();
            } else if (event instanceof VideoRecordEvent.Finalize) {
                VideoRecordEvent.Finalize fin = (VideoRecordEvent.Finalize) event;
                Uri out = fin.getOutputResults().getOutputUri();
                long durMs = fin.getRecordingStats().getRecordedDurationNanos() / 1_000_000L;
                if (out != null && !Uri.EMPTY.equals(out) && durMs > 0) {
                    long start = recStart > 0 ? recStart : System.currentTimeMillis() - durMs;
                    store.addVideo(start, start + durMs, out.toString(), base + ".mp4");
                    try {
                        String srt = Srt.build(store.pointsCopy(), start, durMs, startCh, surveyName);
                        Exporter.save(app, base + ".srt", "application/octet-stream", srt);
                    } catch (Exception ignored) {
                    }
                    Toast.makeText(app, "ভিডিও সেভ হলো: Download/" + Exporter.FOLDER + "/" + base + ".mp4",
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(app, "ভিডিও সেভ হয়নি (ত্রুটি " + fin.getError() + ")", Toast.LENGTH_LONG).show();
                }
                recStart = 0;
            }
        });
        btnRec.setText("⏹ থামান");
        handler.post(ticker);
    }

    private void stopRecording() {
        if (recording != null) {
            recording.stop();
            recording = null;
        }
        btnRec.setText("⏺ রেকর্ড");
        handler.removeCallbacks(ticker);
        tvRec.setText("");
        tvRec.setBackground(null);
    }

    private void updateTimer() {
        if (recording == null) return;
        long s = recStart > 0 ? (System.currentTimeMillis() - recStart) / 1000 : 0;
        tvRec.setText(String.format(Locale.US, "● REC %02d:%02d", s / 60, s % 60));
        GradientDrawable g = new GradientDrawable();
        g.setColor(s % 2 == 0 ? Color.rgb(198, 40, 40) : Color.rgb(140, 20, 20));
        g.setCornerRadius(dp(8));
        tvRec.setBackground(g);
    }

    // ---------- Marking during video ----------

    private void markHere() {
        if (!store.hasFix) {
            Toast.makeText(this, "এখনও GPS অবস্থান পাওয়া যায়নি।", Toast.LENGTH_SHORT).show();
            return;
        }
        final double lat = store.fixLat, lon = store.fixLon, alt = store.fixAlt;
        final Bitmap frame = preview.getBitmap(); // picture of this moment from the camera
        Tags.pick(this, tag -> {
            final int index = store.addMark(tag, lat, lon, alt);
            Toast.makeText(this, tag + " মার্ক হলো, চেইনেজ "
                    + TrackStore.fmtCh(store.disp(store.marks.get(index).ch)), Toast.LENGTH_SHORT).show();
            if (frame != null) {
                final Context app = getApplicationContext();
                final String name = safeName(store.name) + "_" + (index + 1) + "_frame.jpg";
                new Thread(() -> {
                    String uri = Photos.saveBitmap(app, name, frame);
                    if (uri != null) handler.post(() -> store.setMarkPhoto(index, uri));
                }).start();
            }
        });
    }

    // ---------- Screen ----------

    private void closeScreen() {
        if (recording == null) {
            finish();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("ভিডিও থামিয়ে বেরোবেন?")
                .setMessage("ভিডিও সেভ হয়ে যাবে। GPS রেকর্ড চলতেই থাকবে, মূল স্ক্রিন থেকে পজ করতে পারবেন।")
                .setPositiveButton("হ্যাঁ", (d, w) -> {
                    stopRecording();
                    finish();
                })
                .setNegativeButton("না", null)
                .show();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (recording != null) closeScreen();
        else super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        store.addListener(this);
        onTrackChanged();
    }

    @Override
    protected void onPause() {
        store.removeListener(this);
        super.onPause();
    }

    @Override
    protected void onStop() {
        // camera stops when the screen goes away; save what we have
        if (recording != null) stopRecording();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public void onTrackChanged() {
        TrackStore.Pt last = store.lastPoint();
        double raw = last == null ? 0 : last.ch;
        tvCh.setText("Ch " + TrackStore.fmtCh(store.disp(raw)));
        String acc = store.lastAcc < 0 ? "—" : String.format(Locale.US, "±%.0f মি", store.lastAcc);
        tvInfo.setText(String.format(Locale.US, "%s\n%s  •  GPS %s  •  মার্ক %d",
                store.name, store.tracking ? "● GPS রেকর্ড চলছে" : "GPS রেকর্ড বন্ধ", acc, store.marks.size()));
    }

    private static String safeName(String s) {
        String t = s.trim().replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
        return t.isEmpty() ? "survey" : t;
    }
}
