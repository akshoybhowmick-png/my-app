package com.akshoy.roadsurvey;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

/**
 * Holds every survey on the phone. Each survey lives in its own folder
 * (files/surveys/&lt;id&gt;/) with meta.properties, points.csv and marks.csv,
 * so nothing is lost if the app closes. Only one survey is "open" at a time.
 */
public class TrackStore {

    public static class Pt {
        public double lat, lon, alt, ch; // ch = metres from the survey start (without the start chainage)
        public float acc;
        public long time;
    }

    public static class Mark {
        public String name;
        public String photo = ""; // content:// uri of the photo, or empty
        public double lat, lon, alt, ch;
        public long time;
    }

    public static class SurveyInfo {
        public String id, name;
        public double startCh, length;
        public int points;
        public long created;
    }

    public interface Listener {
        void onTrackChanged();
    }

    private static TrackStore instance;

    private final Context app;
    private final File root;
    private final SharedPreferences prefs;

    public String id;
    public String name = "";
    public double startCh = 0;
    public long created;
    private File dir;

    public final List<Pt> points = new ArrayList<>();
    public final List<Mark> marks = new ArrayList<>();

    public volatile boolean tracking = false;
    public volatile float lastAcc = -1f;
    public volatile boolean hasFix = false;
    public volatile double fixLat, fixLon, fixAlt;

    private final List<Listener> listeners = new ArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());

    public static synchronized TrackStore get(Context c) {
        if (instance == null) instance = new TrackStore(c.getApplicationContext());
        return instance;
    }

    private TrackStore(Context c) {
        app = c;
        root = new File(c.getFilesDir(), "surveys");
        //noinspection ResultOfMethodCallIgnored
        root.mkdirs();
        prefs = c.getSharedPreferences("survey", Context.MODE_PRIVATE);
        migrateOldData();
        String cur = prefs.getString("current", null);
        if (cur != null && new File(root, cur).isDirectory()) {
            open(cur);
        } else {
            List<SurveyInfo> all = listSurveys();
            if (!all.isEmpty()) open(all.get(0).id);
            else createSurvey("সার্ভে ১", 0);
        }
    }

    // ---------- Display helpers ----------

    /** Chainage shown to the user = start chainage + distance travelled. */
    public double disp(double raw) {
        return startCh + raw;
    }

    // ---------- Survey management ----------

    public synchronized void createSurvey(String surveyName, double startChainage) {
        String newId = "s" + System.currentTimeMillis();
        File d = new File(root, newId);
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        Properties p = new Properties();
        p.setProperty("name", surveyName);
        p.setProperty("startCh", String.valueOf(startChainage));
        p.setProperty("created", String.valueOf(System.currentTimeMillis()));
        writeMeta(d, p);
        open(newId);
    }

    public synchronized void open(String surveyId) {
        id = surveyId;
        dir = new File(root, surveyId);
        Properties p = readMeta(dir);
        name = p.getProperty("name", "সার্ভে");
        startCh = parseD(p.getProperty("startCh"), 0);
        created = (long) parseD(p.getProperty("created"), System.currentTimeMillis());
        prefs.edit().putString("current", surveyId).apply();
        loadPoints(new File(dir, "points.csv"), points);
        loadMarks(new File(dir, "marks.csv"), marks);
        notifyListeners();
    }

    public synchronized void updateSurvey(String surveyId, String newName, double newStartCh) {
        File d = new File(root, surveyId);
        Properties p = readMeta(d);
        p.setProperty("name", newName);
        p.setProperty("startCh", String.valueOf(newStartCh));
        writeMeta(d, p);
        if (surveyId.equals(id)) {
            name = newName;
            startCh = newStartCh;
            notifyListeners();
        }
    }

    /** Deletes a survey. If it is the open one, another survey is opened (or a new one made). */
    public synchronized void deleteSurvey(String surveyId) {
        deleteRecursive(new File(root, surveyId));
        if (surveyId.equals(id)) {
            List<SurveyInfo> all = listSurveys();
            if (!all.isEmpty()) open(all.get(0).id);
            else createSurvey("সার্ভে ১", 0);
        }
    }

    /** All surveys, newest first. */
    public synchronized List<SurveyInfo> listSurveys() {
        List<SurveyInfo> out = new ArrayList<>();
        File[] dirs = root.listFiles();
        if (dirs == null) return out;
        for (File d : dirs) {
            if (!d.isDirectory()) continue;
            Properties p = readMeta(d);
            SurveyInfo s = new SurveyInfo();
            s.id = d.getName();
            s.name = p.getProperty("name", "সার্ভে");
            s.startCh = parseD(p.getProperty("startCh"), 0);
            s.created = (long) parseD(p.getProperty("created"), d.lastModified());
            if (s.id.equals(id)) {
                s.points = points.size();
                s.length = points.isEmpty() ? 0 : points.get(points.size() - 1).ch;
            } else {
                List<Pt> tmp = new ArrayList<>();
                loadPoints(new File(d, "points.csv"), tmp);
                s.points = tmp.size();
                s.length = tmp.isEmpty() ? 0 : tmp.get(tmp.size() - 1).ch;
            }
            out.add(s);
        }
        Collections.sort(out, (a, b) -> Long.compare(b.created, a.created));
        return out;
    }

    // ---------- Track points ----------

    public synchronized void addPoint(double lat, double lon, double alt, float acc, long time) {
        Pt p = new Pt();
        p.lat = lat;
        p.lon = lon;
        p.alt = alt;
        p.acc = acc;
        p.time = time;
        if (points.isEmpty()) {
            p.ch = 0;
        } else {
            Pt last = points.get(points.size() - 1);
            p.ch = last.ch + distance(last.lat, last.lon, lat, lon);
        }
        points.add(p);
        append(new File(dir, "points.csv"), pointLine(p));
        notifyListeners();
    }

    public synchronized Pt lastPoint() {
        return points.isEmpty() ? null : points.get(points.size() - 1);
    }

    /** Raw distance travelled (metres). */
    public synchronized double length() {
        return points.isEmpty() ? 0 : points.get(points.size() - 1).ch;
    }

    /** Raw chainage of a location = chainage of the nearest recorded track point. */
    public synchronized double chainageAt(double lat, double lon) {
        double best = Double.MAX_VALUE;
        double ch = 0;
        for (Pt p : points) {
            double d = distance(p.lat, p.lon, lat, lon);
            if (d < best) {
                best = d;
                ch = p.ch;
            }
        }
        return ch;
    }

    // ---------- Marks ----------

    public synchronized int addMark(String markName, double lat, double lon, double alt) {
        Mark m = new Mark();
        m.name = clean(markName);
        m.lat = lat;
        m.lon = lon;
        m.alt = alt;
        m.ch = chainageAt(lat, lon);
        m.time = System.currentTimeMillis();
        marks.add(m);
        append(new File(dir, "marks.csv"), markLine(m));
        notifyListeners();
        return marks.size() - 1;
    }

    public synchronized void setMarkPhoto(int index, String uri) {
        if (index < 0 || index >= marks.size()) return;
        marks.get(index).photo = uri == null ? "" : uri;
        rewriteMarks();
    }

    public synchronized void deleteMark(int index) {
        if (index < 0 || index >= marks.size()) return;
        marks.remove(index);
        rewriteMarks();
    }

    private void rewriteMarks() {
        try (Writer w = utf8Writer(new File(dir, "marks.csv"), false)) {
            for (Mark m : marks) {
                w.write(markLine(m));
                w.write('\n');
            }
        } catch (IOException ignored) {
        }
        notifyListeners();
    }

    public synchronized List<Pt> pointsCopy() {
        return new ArrayList<>(points);
    }

    public synchronized List<Mark> marksCopy() {
        List<Mark> out = new ArrayList<>();
        for (Mark m : marks) {
            Mark c = new Mark();
            c.name = m.name;
            c.photo = m.photo;
            c.lat = m.lat;
            c.lon = m.lon;
            c.alt = m.alt;
            c.ch = m.ch;
            c.time = m.time;
            out.add(c);
        }
        return out;
    }

    // ---------- Listeners ----------

    public void addListener(Listener l) {
        synchronized (listeners) {
            if (!listeners.contains(l)) listeners.add(l);
        }
    }

    public void removeListener(Listener l) {
        synchronized (listeners) {
            listeners.remove(l);
        }
    }

    public void notifyListeners() {
        main.post(() -> {
            List<Listener> copy;
            synchronized (listeners) {
                copy = new ArrayList<>(listeners);
            }
            for (Listener l : copy) l.onTrackChanged();
        });
    }

    // ---------- File helpers ----------

    private static String pointLine(Pt p) {
        return String.format(Locale.US, "%.7f,%.7f,%.1f,%.1f,%d,%.2f",
                p.lat, p.lon, p.alt, p.acc, p.time, p.ch);
    }

    /** lat,lon,alt,ch,time,photo,name  (name last, so it may contain commas). */
    private static String markLine(Mark m) {
        return String.format(Locale.US, "%.7f,%.7f,%.1f,%.2f,%d,%s,%s",
                m.lat, m.lon, m.alt, m.ch, m.time, m.photo.replace(",", "%2C"), m.name);
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\n', ' ').replace('\r', ' ').trim();
    }

    private static void loadPoints(File f, List<Pt> out) {
        out.clear();
        if (!f.exists()) return;
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] a = line.split(",", -1);
                if (a.length < 6) continue;
                try {
                    Pt p = new Pt();
                    p.lat = Double.parseDouble(a[0]);
                    p.lon = Double.parseDouble(a[1]);
                    p.alt = Double.parseDouble(a[2]);
                    p.acc = Float.parseFloat(a[3]);
                    p.time = Long.parseLong(a[4]);
                    p.ch = Double.parseDouble(a[5]);
                    out.add(p);
                } catch (NumberFormatException ignored) {
                }
            }
        } catch (IOException ignored) {
        }
    }

    private static void loadMarks(File f, List<Mark> out) {
        out.clear();
        if (!f.exists()) return;
        try (BufferedReader r = new BufferedReader(utf8Reader(f))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] a = line.split(",", 7);
                if (a.length < 7) continue;
                try {
                    Mark m = new Mark();
                    m.lat = Double.parseDouble(a[0]);
                    m.lon = Double.parseDouble(a[1]);
                    m.alt = Double.parseDouble(a[2]);
                    m.ch = Double.parseDouble(a[3]);
                    m.time = Long.parseLong(a[4]);
                    m.photo = a[5].replace("%2C", ",");
                    m.name = a[6];
                    out.add(m);
                } catch (NumberFormatException ignored) {
                }
            }
        } catch (IOException ignored) {
        }
    }

    /** Version 1 kept one survey directly in files/. Move it into its own survey folder. */
    private void migrateOldData() {
        File oldPoints = new File(app.getFilesDir(), "points.csv");
        File oldMarks = new File(app.getFilesDir(), "marks.csv");
        if (!oldPoints.exists() && !oldMarks.exists()) return;
        String newId = "s" + (oldPoints.exists() ? oldPoints.lastModified() : System.currentTimeMillis());
        File d = new File(root, newId);
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        Properties p = new Properties();
        p.setProperty("name", "পুরনো সার্ভে");
        p.setProperty("startCh", "0");
        p.setProperty("created", newId.substring(1));
        writeMeta(d, p);
        if (oldPoints.exists()) {
            //noinspection ResultOfMethodCallIgnored
            oldPoints.renameTo(new File(d, "points.csv"));
        }
        if (oldMarks.exists()) {
            // old format: lat,lon,alt,ch,time,name
            try (BufferedReader r = new BufferedReader(utf8Reader(oldMarks));
                 Writer w = utf8Writer(new File(d, "marks.csv"), false)) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] a = line.split(",", 6);
                    if (a.length < 6) continue;
                    w.write(a[0] + "," + a[1] + "," + a[2] + "," + a[3] + "," + a[4] + ",," + a[5] + "\n");
                }
            } catch (IOException ignored) {
            }
            //noinspection ResultOfMethodCallIgnored
            oldMarks.delete();
        }
        prefs.edit().putString("current", newId).apply();
    }

    private static Properties readMeta(File d) {
        Properties p = new Properties();
        File f = new File(d, "meta.properties");
        if (f.exists()) {
            try (Reader r = utf8Reader(f)) {
                p.load(r);
            } catch (IOException ignored) {
            }
        }
        return p;
    }

    private static void writeMeta(File d, Properties p) {
        try (Writer w = utf8Writer(new File(d, "meta.properties"), false)) {
            p.store(w, null);
        } catch (IOException ignored) {
        }
    }

    private static Reader utf8Reader(File f) throws IOException {
        return new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8);
    }

    private static Writer utf8Writer(File f, boolean append) throws IOException {
        return new OutputStreamWriter(new FileOutputStream(f, append), StandardCharsets.UTF_8);
    }

    private static void append(File f, String line) {
        try (Writer w = utf8Writer(f, true)) {
            w.write(line);
            w.write('\n');
        } catch (IOException ignored) {
        }
    }

    private static void deleteRecursive(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private static double parseD(String s, double def) {
        if (s == null) return def;
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    // ---------- Maths & formatting ----------

    /** Distance in metres between two lat/lon points (haversine). */
    public static double distance(double lat1, double lon1, double lat2, double lon2) {
        double r = 6371008.8;
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2 - lat1), dl = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2)
                + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * r * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    /** Road chainage style: 1250.4 m -> "1+250". */
    public static String fmtCh(double metres) {
        long m = Math.round(metres);
        String sign = m < 0 ? "-" : "";
        m = Math.abs(m);
        return String.format(Locale.US, "%s%d+%03d", sign, m / 1000, m % 1000);
    }

    /** Accepts "5+200" or "5200" (metres). Returns NaN if it cannot be read. */
    public static double parseCh(String s) {
        if (s == null) return Double.NaN;
        s = s.trim().replace(" ", "");
        if (s.isEmpty()) return 0;
        try {
            int plus = s.indexOf('+');
            if (plus >= 0) {
                String km = s.substring(0, plus);
                String m = s.substring(plus + 1);
                return (km.isEmpty() ? 0 : Double.parseDouble(km)) * 1000
                        + (m.isEmpty() ? 0 : Double.parseDouble(m));
            }
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }
}
