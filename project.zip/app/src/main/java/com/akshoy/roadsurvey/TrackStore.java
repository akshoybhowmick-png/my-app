package com.akshoy.roadsurvey;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

/**
 * Holds every survey on the phone. Each survey lives in its own folder
 * (files/surveys/&lt;id&gt;/) with meta.properties, points.csv and marks.csv,
 * so nothing is lost if the app closes. Only one survey is "open" at a time.
 */
public class TrackStore {

    public static class Pt {
        public double lat, lon, alt, ch; // ch = metres from the survey start (without the start chainage)
        public float acc;
        public long time;
    }

    public static class Mark {
        public String name;
        /** Attachments separated by '|': photo uris, and voice notes as "audio:" + uri. */
        public String photo = "";

        public List<String> photos() {
            return photosOf(photo);
        }

        public List<String> audios() {
            List<String> out = new ArrayList<>();
            for (String a : photo.split("\\|")) if (a.startsWith("audio:")) out.add(a.substring(6));
            return out;
        }
        public double lat, lon, alt, ch;
        public long time;
    }

    public static List<String> photosOf(String field) {
        List<String> out = new ArrayList<>();
        if (field == null) return out;
        for (String a : field.split("\\|")) if (!a.isEmpty() && !a.startsWith("audio:")) out.add(a);
        return out;
    }

    public static String firstPhoto(String field) {
        List<String> p = photosOf(field);
        return p.isEmpty() ? "" : p.get(0);
    }

    /** Road condition from this chainage onwards (until the next segment). */
    public static class Seg {
        public double ch;        // raw metres
        public long time;
        public double width;     // metres, NaN if not given
        public String surface = "", condition = "";
    }

    public static class VideoRec {
        public long start, end; // phone clock, ms
        public String uri, name;
    }

    public static class SurveyInfo {
        public String id, name;
        public double startCh, length;
        public int points;
        public long created;
    }

    public interface Listener {
        void onTrackChanged();
    }

    private static TrackStore instance;

    private final Context app;
    private final File root;
    private final SharedPreferences prefs;

    public String id;
    public String name = "";
    public double startCh = 0;
    public long created;
    private File dir;

    public final List<Pt> points = new ArrayList<>();
    public final List<Mark> marks = new ArrayList<>();
    public final List<VideoRec> videos = new ArrayList<>();
    public final List<Seg> segments = new ArrayList<>();

    public volatile boolean tracking = false;
    public volatile float lastAcc = -1f;
    public volatile boolean hasFix = false;
    public volatile double fixLat, fixLon, fixAlt;
    public volatile int satUsed = -1, satSeen = -1;
    public volatile boolean externalGps = false; // position comes from a Bluetooth receiver (mock location app)

    private final List<Listener> listeners = new ArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());

    public static synchronized TrackStore get(Context c) {
        if (instance == null) instance = new TrackStore(c.getApplicationContext());
        return instance;
    }

    private TrackStore(Context c) {
        app = c;
        root = new File(c.getFilesDir(), "surveys");
        //noinspection ResultOfMethodCallIgnored
        root.mkdirs();
        prefs = c.getSharedPreferences("survey", Context.MODE_PRIVATE);
        migrateOldData();
        String cur = prefs.getString("current", null);
        if (cur != null && new File(root, cur).isDirectory()) {
            open(cur);
        } else {
            List<SurveyInfo> all = listSurveys();
            if (!all.isEmpty()) open(all.get(0).id);
            else createSurvey(L.t("সার্ভে ১", "Survey 1"), 0);
        }
    }

    // ---------- Display helpers ----------

    /** Chainage shown to the user = start chainage + distance travelled. */
    public double disp(double raw) {
        return startCh + raw;
    }

    // ---------- Survey management ----------

    public synchronized void createSurvey(String surveyName, double startChainage) {
        String newId = "s" + System.currentTimeMillis();
        File d = new File(root, newId);
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        Properties p = new Properties();
        p.setProperty("name", surveyName);
        p.setProperty("startCh", String.valueOf(startChainage));
        p.setProperty("created", String.valueOf(System.currentTimeMillis()));
        writeMeta(d, p);
        open(newId);
    }

    public synchronized void open(String surveyId) {
        id = surveyId;
        dir = new File(root, surveyId);
        Properties p = readMeta(dir);
        name = p.getProperty("name", L.t("সার্ভে", "Surveys"));
        startCh = parseD(p.getProperty("startCh"), 0);
        created = (long) parseD(p.getProperty("created"), System.currentTimeMillis());
        prefs.edit().putString("current", surveyId).apply();
        loadPoints(new File(dir, "points.csv"), points);
        loadMarks(new File(dir, "marks.csv"), marks);
        loadVideos(new File(dir, "videos.csv"), videos);
        loadSegments(new File(dir, "segments.csv"), segments);
        notifyListeners();
    }

    public synchronized void updateSurvey(String surveyId, String newName, double newStartCh) {
        File d = new File(root, surveyId);
        Properties p = readMeta(d);
        p.setProperty("name", newName);
        p.setProperty("startCh", String.valueOf(newStartCh));
        writeMeta(d, p);
        if (surveyId.equals(id)) {
            name = newName;
            startCh = newStartCh;
            notifyListeners();
        }
    }

    /** Deletes a survey. If it is the open one, another survey is opened (or a new one made). */
    public synchronized void deleteSurvey(String surveyId) {
        deleteRecursive(new File(root, surveyId));
        if (surveyId.equals(id)) {
            List<SurveyInfo> all = listSurveys();
            if (!all.isEmpty()) open(all.get(0).id);
            else createSurvey(L.t("সার্ভে ১", "Survey 1"), 0);
        }
    }

    /** All surveys, newest first. */
    public synchronized List<SurveyInfo> listSurveys() {
        List<SurveyInfo> out = new ArrayList<>();
        File[] dirs = root.listFiles();
        if (dirs == null) return out;
        for (File d : dirs) {
            if (!d.isDirectory()) continue;
            Properties p = readMeta(d);
            SurveyInfo s = new SurveyInfo();
            s.id = d.getName();
            s.name = p.getProperty("name", L.t("সার্ভে", "Surveys"));
            s.startCh = parseD(p.getProperty("startCh"), 0);
            s.created = (long) parseD(p.getProperty("created"), d.lastModified());
            if (s.id.equals(id)) {
                s.points = points.size();
                s.length = points.isEmpty() ? 0 : points.get(points.size() - 1).ch;
            } else {
                List<Pt> tmp = new ArrayList<>();
                loadPoints(new File(d, "points.csv"), tmp);
                s.points = tmp.size();
                s.length = tmp.isEmpty() ? 0 : tmp.get(tmp.size() - 1).ch;
            }
            out.add(s);
        }
        Collections.sort(out, (a, b) -> Long.compare(b.created, a.created));
        return out;
    }

    // ---------- Track points ----------

    public synchronized void addPoint(double lat, double lon, double alt, float acc, long time) {
        Pt p = new Pt();
        p.lat = lat;
        p.lon = lon;
        p.alt = alt;
        p.acc = acc;
        p.time = time;
        if (points.isEmpty()) {
            p.ch = 0;
        } else {
            Pt last = points.get(points.size() - 1);
            p.ch = last.ch + distance(last.lat, last.lon, lat, lon);
        }
        points.add(p);
        append(new File(dir, "points.csv"), pointLine(p));
        notifyListeners();
    }

    public synchronized Pt lastPoint() {
        return points.isEmpty() ? null : points.get(points.size() - 1);
    }

    /** Raw distance travelled (metres). */
    public synchronized double length() {
        return points.isEmpty() ? 0 : points.get(points.size() - 1).ch;
    }

    /**
     * Chainage for a marked point after the line was changed: if the mark was taken while recording,
     * use where we were on the road at that moment (correct on out-and-back walks); otherwise nearest point.
     */
    private double chainageForMark(Mark m) {
        if (!points.isEmpty()) {
            Pt a = points.get(0), b = points.get(points.size() - 1);
            if (m.time >= a.time && m.time <= b.time) {
                double[] pos = positionAt(points, m.time);
                if (pos != null && distance(pos[0], pos[1], m.lat, m.lon) < 40) return pos[2];
            }
        }
        return chainageAt(m.lat, m.lon);
    }

    /** Raw chainage of a location = chainage of the nearest recorded track point. */
    public synchronized double chainageAt(double lat, double lon) {
        double best = Double.MAX_VALUE;
        double ch = 0;
        for (Pt p : points) {
            double d = distance(p.lat, p.lon, lat, lon);
            if (d < best) {
                best = d;
                ch = p.ch;
            }
        }
        return ch;
    }

    // ---------- Marks ----------

    public synchronized int addMark(String markName, double lat, double lon, double alt) {
        Mark m = new Mark();
        m.name = clean(markName);
        m.lat = lat;
        m.lon = lon;
        m.alt = alt;
        Pt last = points.isEmpty() ? null : points.get(points.size() - 1);
        if (tracking && last != null && distance(last.lat, last.lon, lat, lon) < 30) {
            m.ch = last.ch; // where we are now on the road (correct even when walking back)
        } else {
            m.ch = chainageAt(lat, lon);
        }
        m.time = System.currentTimeMillis();
        marks.add(m);
        append(new File(dir, "marks.csv"), markLine(m));
        notifyListeners();
        return marks.size() - 1;
    }

    public synchronized void setMarkPhoto(int index, String uri) {
        addMarkAttachment(index, uri);
    }

    /** Adds a photo uri (or "audio:" + uri) to a mark. */
    public synchronized void addMarkAttachment(int index, String item) {
        if (index < 0 || index >= marks.size() || item == null || item.isEmpty()) return;
        Mark m = marks.get(index);
        m.photo = m.photo.isEmpty() ? item : m.photo + "|" + item;
        rewriteMarks();
    }

    public synchronized void removeMarkAttachment(int index, String item) {
        if (index < 0 || index >= marks.size()) return;
        Mark m = marks.get(index);
        StringBuilder sb = new StringBuilder();
        for (String a : m.photo.split("\\|")) {
            if (a.isEmpty() || a.equals(item)) continue;
            if (sb.length() > 0) sb.append('|');
            sb.append(a);
        }
        m.photo = sb.toString();
        rewriteMarks();
    }

    // ---------- Imported reference (design alignment / old track) ----------

    private RefLayer refCache;
    private String refCacheId;

    public synchronized RefLayer reference() {
        if (refCacheId == null || !refCacheId.equals(id)) {
            refCache = RefLayer.load(new File(dir, "ref.csv"));
            refCacheId = id;
        }
        return refCache;
    }

    public synchronized void setReference(RefLayer r) throws IOException {
        r.save(new File(dir, "ref.csv"));
        refCache = r;
        refCacheId = id;
        notifyListeners();
    }

    public synchronized void clearReference() {
        //noinspection ResultOfMethodCallIgnored
        new File(dir, "ref.csv").delete();
        refCache = null;
        refCacheId = id;
        notifyListeners();
    }

    /** Folder for this survey's voice notes. */
    public synchronized File audioDir() {
        File d = new File(dir, "audio");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    public synchronized void deleteMark(int index) {
        if (index < 0 || index >= marks.size()) return;
        marks.remove(index);
        rewriteMarks();
    }

    private void rewriteMarks() {
        try (Writer w = utf8Writer(new File(dir, "marks.csv"), false)) {
            for (Mark m : marks) {
                w.write(markLine(m));
                w.write('\n');
            }
        } catch (IOException ignored) {
        }
        notifyListeners();
    }

    /**
     * Removes the zig-zag points recorded while standing still (GPS drift) from the open survey,
     * then recalculates chainage of the track and of the marked points. Returns how many were removed.
     */
    public synchronized int cleanTrack(double minDist) {
        if (points.size() < 3) return 0;
        List<Pt> kept = new ArrayList<>();
        Pt prev = points.get(0);
        prev.ch = 0;
        kept.add(prev);
        for (int i = 1; i < points.size(); i++) {
            Pt p = points.get(i);
            double d = distance(prev.lat, prev.lon, p.lat, p.lon);
            double need = Math.max(minDist, Math.min(p.acc > 0 ? p.acc : 0, 20) * 0.8);
            if (d >= need) {
                p.ch = prev.ch + d;
                kept.add(p);
                prev = p;
            }
        }
        int removed = points.size() - kept.size();
        if (removed == 0) return 0;
        points.clear();
        points.addAll(kept);
        try (Writer w = utf8Writer(new File(dir, "points.csv"), false)) {
            for (Pt p : points) {
                w.write(pointLine(p));
                w.write('\n');
            }
        } catch (IOException ignored) {
        }
        for (Mark m : marks) m.ch = chainageForMark(m);
        rewriteMarks(); // also notifies listeners
        return removed;
    }

    /**
     * Smooths an already-recorded line (moving average over 'radius' points on each side),
     * which removes the side-to-side zig-zag. Start and end stay where they are.
     */
    public synchronized int smoothTrack(int radius) {
        int n = points.size();
        if (n < 5 || radius < 1) return 0;
        double[] la = new double[n], lo = new double[n];
        for (int i = 0; i < n; i++) {
            if (i == 0 || i == n - 1) {
                la[i] = points.get(i).lat;
                lo[i] = points.get(i).lon;
                continue;
            }
            int r = Math.min(radius, Math.min(i, n - 1 - i));
            double sl = 0, so = 0, sw = 0;
            for (int j = i - r; j <= i + r; j++) {
                double w = r + 1 - Math.abs(j - i); // triangle weights
                sl += points.get(j).lat * w;
                so += points.get(j).lon * w;
                sw += w;
            }
            la[i] = sl / sw;
            lo[i] = so / sw;
        }
        for (int i = 0; i < n; i++) {
            Pt p = points.get(i);
            p.lat = la[i];
            p.lon = lo[i];
            p.ch = i == 0 ? 0 : points.get(i - 1).ch + distance(points.get(i - 1).lat, points.get(i - 1).lon, p.lat, p.lon);
        }
        try (Writer w = utf8Writer(new File(dir, "points.csv"), false)) {
            for (Pt p : points) {
                w.write(pointLine(p));
                w.write('\n');
            }
        } catch (IOException ignored) {
        }
        for (Mark m : marks) m.ch = chainageForMark(m);
        rewriteMarks();
        return n;
    }

    // ---------- Undo ----------

    /** Removes the last marked point. Returns its name, or null if there was none. */
    public synchronized String undoLastMark() {
        if (marks.isEmpty()) return null;
        String n = marks.get(marks.size() - 1).name;
        marks.remove(marks.size() - 1);
        rewriteMarks();
        return n;
    }

    /** Removes the last 'metres' of the recorded line. Returns how many points were removed. */
    public synchronized int undoLastMetres(double metres) {
        if (points.size() < 2) return 0;
        double cut = points.get(points.size() - 1).ch - metres;
        int before = points.size();
        while (points.size() > 1 && points.get(points.size() - 1).ch > cut) points.remove(points.size() - 1);
        int removed = before - points.size();
        if (removed > 0) {
            try (Writer w = utf8Writer(new File(dir, "points.csv"), false)) {
                for (Pt p : points) {
                    w.write(pointLine(p));
                    w.write('\n');
                }
            } catch (IOException ignored) {
            }
            notifyListeners();
        }
        return removed;
    }

    // ---------- Backup / restore ----------

    /** Zip of every survey (track, marks, videos list, settings of each survey) plus the tag list. */
    public synchronized byte[] backupZip(List<String> tags) throws IOException {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        try (java.util.zip.ZipOutputStream z = new java.util.zip.ZipOutputStream(bos)) {
            File[] dirs = root.listFiles();
            if (dirs != null) {
                for (File d : dirs) {
                    File[] files = d.isDirectory() ? d.listFiles() : null;
                    if (files == null) continue;
                    for (File f : files) {
                        if (!f.isFile()) continue;
                        z.putNextEntry(new java.util.zip.ZipEntry("surveys/" + d.getName() + "/" + f.getName()));
                        try (FileInputStream in = new FileInputStream(f)) {
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = in.read(buf)) > 0) z.write(buf, 0, n);
                        }
                        z.closeEntry();
                    }
                }
            }
            z.putNextEntry(new java.util.zip.ZipEntry("tags.txt"));
            StringBuilder sb = new StringBuilder();
            for (String t : tags) sb.append(t).append('\n');
            z.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            z.closeEntry();
        }
        return bos.toByteArray();
    }

    /**
     * Restores surveys from a backup zip. Surveys that already exist on the phone are kept;
     * a restored copy gets a new id. Returns {surveys restored, tags found} and fills 'tagsOut'.
     */
    public synchronized int restoreZip(java.io.InputStream in, List<String> tagsOut) throws IOException {
        java.util.Map<String, String> idMap = new java.util.HashMap<>();
        java.util.Set<String> allowed = new java.util.HashSet<>(java.util.Arrays.asList(
                "meta.properties", "points.csv", "marks.csv", "videos.csv", "ref.csv", "segments.csv"));
        try (java.util.zip.ZipInputStream z = new java.util.zip.ZipInputStream(in)) {
            java.util.zip.ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String name = e.getName();
                if (e.isDirectory() || name.contains("..") || name.contains("\\")) continue;
                if (name.equals("tags.txt")) {
                    BufferedReader r = new BufferedReader(new InputStreamReader(z, StandardCharsets.UTF_8));
                    String line;
                    while ((line = r.readLine()) != null) if (!line.trim().isEmpty()) tagsOut.add(line.trim());
                    continue;
                }
                String[] parts = name.split("/");
                if (parts.length != 3 || !parts[0].equals("surveys") || !parts[1].matches("[A-Za-z0-9_]+")
                        || !allowed.contains(parts[2])) continue;
                String id = idMap.get(parts[1]);
                if (id == null) {
                    id = parts[1];
                    if (new File(root, id).exists()) id = parts[1] + "r" + (System.currentTimeMillis() % 100000);
                    idMap.put(parts[1], id);
                }
                File d = new File(root, id);
                //noinspection ResultOfMethodCallIgnored
                d.mkdirs();
                try (FileOutputStream out = new FileOutputStream(new File(d, parts[2]))) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = z.read(buf)) > 0) out.write(buf, 0, n);
                }
            }
        }
        notifyListeners();
        return idMap.size();
    }

    // ---------- Road segments ----------

    public synchronized void addSegment(double rawCh, String surface, String condition, double width) {
        Seg g = new Seg();
        g.ch = rawCh;
        g.time = System.currentTimeMillis();
        g.width = width;
        g.surface = clean(surface).replace(",", " ");
        g.condition = clean(condition).replace(",", " ");
        segments.add(g);
        Collections.sort(segments, (x, y) -> Double.compare(x.ch, y.ch));
        writeSegments();
    }

    public synchronized void deleteSegment(int index) {
        if (index < 0 || index >= segments.size()) return;
        segments.remove(index);
        writeSegments();
    }

    public synchronized List<Seg> segmentsCopy() {
        return new ArrayList<>(segments);
    }

    private void writeSegments() {
        try (Writer w = utf8Writer(new File(dir, "segments.csv"), false)) {
            for (Seg g : segments) {
                w.write(String.format(Locale.US, "%.2f,%d,%s,%s,%s\n", g.ch, g.time,
                        Double.isNaN(g.width) ? "" : String.format(Locale.US, "%.2f", g.width), g.surface, g.condition));
            }
        } catch (IOException ignored) {
        }
        notifyListeners();
    }

    private static void loadSegments(File f, List<Seg> out) {
        out.clear();
        if (!f.exists()) return;
        try (BufferedReader r = new BufferedReader(utf8Reader(f))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] a = line.split(",", 5);
                if (a.length < 5) continue;
                try {
                    Seg g = new Seg();
                    g.ch = Double.parseDouble(a[0]);
                    g.time = Long.parseLong(a[1]);
                    g.width = a[2].isEmpty() ? Double.NaN : Double.parseDouble(a[2]);
                    g.surface = a[3];
                    g.condition = a[4];
                    out.add(g);
                } catch (NumberFormatException ignored) {
                }
            }
        } catch (IOException ignored) {
        }
    }

    // ---------- Videos ----------

    public synchronized void addVideo(long start, long end, String uri, String videoName) {
        VideoRec v = new VideoRec();
        v.start = start;
        v.end = end;
        v.uri = uri;
        v.name = clean(videoName);
        videos.add(v);
        append(new File(dir, "videos.csv"), v.start + "," + v.end + "," + v.uri.replace(",", "%2C") + "," + v.name);
        notifyListeners();
    }

    public synchronized List<VideoRec> videosCopy() {
        return new ArrayList<>(videos);
    }

    /** The video that was recording at time t, or null. */
    public synchronized VideoRec videoAt(long t) {
        for (VideoRec v : videos) if (t >= v.start && t <= v.end) return v;
        return null;
    }

    private static void loadVideos(File f, List<VideoRec> out) {
        out.clear();
        if (!f.exists()) return;
        try (BufferedReader r = new BufferedReader(utf8Reader(f))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] a = line.split(",", 4);
                if (a.length < 4) continue;
                try {
                    VideoRec v = new VideoRec();
                    v.start = Long.parseLong(a[0]);
                    v.end = Long.parseLong(a[1]);
                    v.uri = a[2].replace("%2C", ",");
                    v.name = a[3];
                    out.add(v);
                } catch (NumberFormatException ignored) {
                }
            }
        } catch (IOException ignored) {
        }
    }

    /** Index of the track point nearest to a location (or -1). */
    public synchronized int nearestIndex(double lat, double lon) {
        int best = -1;
        double bd = Double.MAX_VALUE;
        for (int i = 0; i < points.size(); i++) {
            Pt p = points.get(i);
            double d = distance(p.lat, p.lon, lat, lon);
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    /**
     * Position on the track at time t (interpolated between points).
     * Returns {lat, lon, rawChainage, speedKmh} or null if there is no track.
     */
    public static double[] positionAt(List<Pt> pts, long t) {
        if (pts.isEmpty()) return null;
        if (t <= pts.get(0).time) {
            Pt p = pts.get(0);
            return new double[]{p.lat, p.lon, p.ch, 0};
        }
        Pt last = pts.get(pts.size() - 1);
        if (t >= last.time) return new double[]{last.lat, last.lon, last.ch, 0};
        int lo = 0, hi = pts.size() - 1;
        while (hi - lo > 1) {
            int mid = (lo + hi) / 2;
            if (pts.get(mid).time <= t) lo = mid;
            else hi = mid;
        }
        Pt a = pts.get(lo), b = pts.get(hi);
        double span = Math.max(1, b.time - a.time);
        double f = (t - a.time) / span;
        double speed = (b.ch - a.ch) / (span / 1000.0) * 3.6;
        if (span > 30000) speed = 0; // a pause, not driving
        return new double[]{a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f, a.ch + (b.ch - a.ch) * f, speed};
    }

    public synchronized List<Pt> pointsCopy() {
        return new ArrayList<>(points);
    }

    public synchronized List<Mark> marksCopy() {
        List<Mark> out = new ArrayList<>();
        for (Mark m : marks) {
            Mark c = new Mark();
            c.name = m.name;
            c.photo = m.photo;
            c.lat = m.lat;
            c.lon = m.lon;
            c.alt = m.alt;
            c.ch = m.ch;
            c.time = m.time;
            out.add(c);
        }
        return out;
    }

    // ---------- Listeners ----------

    public void addListener(Listener l) {
        synchronized (listeners) {
            if (!listeners.contains(l)) listeners.add(l);
        }
    }

    public void removeListener(Listener l) {
        synchronized (listeners) {
            listeners.remove(l);
        }
    }

    public void notifyListeners() {
        main.post(() -> {
            List<Listener> copy;
            synchronized (listeners) {
                copy = new ArrayList<>(listeners);
            }
            for (Listener l : copy) l.onTrackChanged();
        });
    }

    // ---------- File helpers ----------

    private static String pointLine(Pt p) {
        return String.format(Locale.US, "%.7f,%.7f,%.1f,%.1f,%d,%.2f",
                p.lat, p.lon, p.alt, p.acc, p.time, p.ch);
    }

    /** lat,lon,alt,ch,time,photo,name  (name last, so it may contain commas). */
    private static String markLine(Mark m) {
        return String.format(Locale.US, "%.7f,%.7f,%.1f,%.2f,%d,%s,%s",
                m.lat, m.lon, m.alt, m.ch, m.time, m.photo.replace(",", "%2C"), m.name);
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\n', ' ').replace('\r', ' ').trim();
    }

    private static void loadPoints(File f, List<Pt> out) {
        out.clear();
        if (!f.exists()) return;
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] a = line.split(",", -1);
                if (a.length < 6) continue;
                try {
                    Pt p = new Pt();
                    p.lat = Double.parseDouble(a[0]);
                    p.lon = Double.parseDouble(a[1]);
                    p.alt = Double.parseDouble(a[2]);
                    p.acc = Float.parseFloat(a[3]);
                    p.time = Long.parseLong(a[4]);
                    p.ch = Double.parseDouble(a[5]);
                    out.add(p);
                } catch (NumberFormatException ignored) {
                }
            }
        } catch (IOException ignored) {
        }
    }

    private static void loadMarks(File f, List<Mark> out) {
        out.clear();
        if (!f.exists()) return;
        try (BufferedReader r = new BufferedReader(utf8Reader(f))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] a = line.split(",", 7);
                if (a.length < 7) continue;
                try {
                    Mark m = new Mark();
                    m.lat = Double.parseDouble(a[0]);
                    m.lon = Double.parseDouble(a[1]);
                    m.alt = Double.parseDouble(a[2]);
                    m.ch = Double.parseDouble(a[3]);
                    m.time = Long.parseLong(a[4]);
                    m.photo = a[5].replace("%2C", ",");
                    m.name = a[6];
                    out.add(m);
                } catch (NumberFormatException ignored) {
                }
            }
        } catch (IOException ignored) {
        }
    }

    /** Version 1 kept one survey directly in files/. Move it into its own survey folder. */
    private void migrateOldData() {
        File oldPoints = new File(app.getFilesDir(), "points.csv");
        File oldMarks = new File(app.getFilesDir(), "marks.csv");
        if (!oldPoints.exists() && !oldMarks.exists()) return;
        String newId = "s" + (oldPoints.exists() ? oldPoints.lastModified() : System.currentTimeMillis());
        File d = new File(root, newId);
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        Properties p = new Properties();
        p.setProperty("name", L.t("পুরনো সার্ভে", "Old survey"));
        p.setProperty("startCh", "0");
        p.setProperty("created", newId.substring(1));
        writeMeta(d, p);
        if (oldPoints.exists()) {
            //noinspection ResultOfMethodCallIgnored
            oldPoints.renameTo(new File(d, "points.csv"));
        }
        if (oldMarks.exists()) {
            // old format: lat,lon,alt,ch,time,name
            try (BufferedReader r = new BufferedReader(utf8Reader(oldMarks));
                 Writer w = utf8Writer(new File(d, "marks.csv"), false)) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] a = line.split(",", 6);
                    if (a.length < 6) continue;
                    w.write(a[0] + "," + a[1] + "," + a[2] + "," + a[3] + "," + a[4] + ",," + a[5] + "\n");
                }
            } catch (IOException ignored) {
            }
            //noinspection ResultOfMethodCallIgnored
            oldMarks.delete();
        }
        prefs.edit().putString("current", newId).apply();
    }

    private static Properties readMeta(File d) {
        Properties p = new Properties();
        File f = new File(d, "meta.properties");
        if (f.exists()) {
            try (Reader r = utf8Reader(f)) {
                p.load(r);
            } catch (IOException ignored) {
            }
        }
        return p;
    }

    private static void writeMeta(File d, Properties p) {
        try (Writer w = utf8Writer(new File(d, "meta.properties"), false)) {
            p.store(w, null);
        } catch (IOException ignored) {
        }
    }

    private static Reader utf8Reader(File f) throws IOException {
        return new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8);
    }

    private static Writer utf8Writer(File f, boolean append) throws IOException {
        return new OutputStreamWriter(new FileOutputStream(f, append), StandardCharsets.UTF_8);
    }

    private static void append(File f, String line) {
        try (Writer w = utf8Writer(f, true)) {
            w.write(line);
            w.write('\n');
        } catch (IOException ignored) {
        }
    }

    private static void deleteRecursive(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private static double parseD(String s, double def) {
        if (s == null) return def;
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    // ---------- Maths & formatting ----------

    /** Distance in metres between two lat/lon points (haversine). */
    public static double distance(double lat1, double lon1, double lat2, double lon2) {
        double r = 6371008.8;
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2 - lat1), dl = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2)
                + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * r * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    /** Road chainage style: 1250.4 m -> "1+250". */
    public static String fmtCh(double metres) {
        long m = Math.round(metres);
        String sign = m < 0 ? "-" : "";
        m = Math.abs(m);
        return String.format(Locale.US, "%s%d+%03d", sign, m / 1000, m % 1000);
    }

    /** Accepts "5+200" or "5200" (metres). Returns NaN if it cannot be read. */
    public static double parseCh(String s) {
        if (s == null) return Double.NaN;
        s = s.trim().replace(" ", "");
        if (s.isEmpty()) return 0;
        try {
            int plus = s.indexOf('+');
            if (plus >= 0) {
                String km = s.substring(0, plus);
                String m = s.substring(plus + 1);
                return (km.isEmpty() ? 0 : Double.parseDouble(km)) * 1000
                        + (m.isEmpty() ? 0 : Double.parseDouble(m));
            }
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }
}
