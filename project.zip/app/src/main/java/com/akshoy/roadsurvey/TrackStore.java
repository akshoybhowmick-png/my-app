package com.akshoy.roadsurvey;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Holds the surveyed track and marked points, saved to disk so nothing is lost if the app closes. */
public class TrackStore {

    public static class Pt {
        public double lat, lon, alt, ch;
        public float acc;
        public long time;
    }

    public static class Mark {
        public String name;
        public double lat, lon, alt, ch;
        public long time;
    }

    public interface Listener {
        void onTrackChanged();
    }

    private static TrackStore instance;

    public final List<Pt> points = new ArrayList<>();
    public final List<Mark> marks = new ArrayList<>();

    public volatile boolean tracking = false;
    public volatile float lastAcc = -1f;
    public volatile boolean hasFix = false;
    public volatile double fixLat, fixLon, fixAlt;

    private final File pointsFile;
    private final File marksFile;
    private final List<Listener> listeners = new ArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());

    public static synchronized TrackStore get(Context c) {
        if (instance == null) instance = new TrackStore(c.getApplicationContext());
        return instance;
    }

    private TrackStore(Context c) {
        pointsFile = new File(c.getFilesDir(), "points.csv");
        marksFile = new File(c.getFilesDir(), "marks.csv");
        load();
    }

    private void load() {
        points.clear();
        marks.clear();
        if (pointsFile.exists()) {
            try (BufferedReader r = new BufferedReader(new FileReader(pointsFile))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] f = line.split(",", -1);
                    if (f.length < 6) continue;
                    try {
                        Pt p = new Pt();
                        p.lat = Double.parseDouble(f[0]);
                        p.lon = Double.parseDouble(f[1]);
                        p.alt = Double.parseDouble(f[2]);
                        p.acc = Float.parseFloat(f[3]);
                        p.time = Long.parseLong(f[4]);
                        p.ch = Double.parseDouble(f[5]);
                        points.add(p);
                    } catch (NumberFormatException ignored) {
                    }
                }
            } catch (IOException ignored) {
            }
        }
        if (marksFile.exists()) {
            try (BufferedReader r = new BufferedReader(new FileReader(marksFile))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] f = line.split(",", 6);
                    if (f.length < 6) continue;
                    try {
                        Mark m = new Mark();
                        m.lat = Double.parseDouble(f[0]);
                        m.lon = Double.parseDouble(f[1]);
                        m.alt = Double.parseDouble(f[2]);
                        m.ch = Double.parseDouble(f[3]);
                        m.time = Long.parseLong(f[4]);
                        m.name = f[5];
                        marks.add(m);
                    } catch (NumberFormatException ignored) {
                    }
                }
            } catch (IOException ignored) {
            }
        }
    }

    private static void append(File f, String line) {
        try (FileWriter w = new FileWriter(f, true)) {
            w.write(line);
            w.write('\n');
        } catch (IOException ignored) {
        }
    }

    public synchronized void addPoint(double lat, double lon, double alt, float acc, long time) {
        Pt p = new Pt();
        p.lat = lat;
        p.lon = lon;
        p.alt = alt;
        p.acc = acc;
        p.time = time;
        if (points.isEmpty()) {
            p.ch = 0;
        } else {
            Pt last = points.get(points.size() - 1);
            p.ch = last.ch + distance(last.lat, last.lon, lat, lon);
        }
        points.add(p);
        append(pointsFile, String.format(Locale.US, "%.7f,%.7f,%.1f,%.1f,%d,%.2f",
                p.lat, p.lon, p.alt, p.acc, p.time, p.ch));
        notifyListeners();
    }

    public synchronized Pt lastPoint() {
        return points.isEmpty() ? null : points.get(points.size() - 1);
    }

    public synchronized double chainage() {
        return points.isEmpty() ? 0 : points.get(points.size() - 1).ch;
    }

    /** Chainage of a location = chainage of the nearest recorded track point. */
    public synchronized double chainageAt(double lat, double lon) {
        double best = Double.MAX_VALUE;
        double ch = 0;
        for (Pt p : points) {
            double d = distance(p.lat, p.lon, lat, lon);
            if (d < best) {
                best = d;
                ch = p.ch;
            }
        }
        return ch;
    }

    public synchronized Mark addMark(String name, double lat, double lon, double alt) {
        Mark m = new Mark();
        m.name = name.replace('\n', ' ').trim();
        m.lat = lat;
        m.lon = lon;
        m.alt = alt;
        m.ch = chainageAt(lat, lon);
        m.time = System.currentTimeMillis();
        marks.add(m);
        append(marksFile, String.format(Locale.US, "%.7f,%.7f,%.1f,%.2f,%d,%s",
                m.lat, m.lon, m.alt, m.ch, m.time, m.name));
        notifyListeners();
        return m;
    }

    public synchronized void clear() {
        points.clear();
        marks.clear();
        //noinspection ResultOfMethodCallIgnored
        pointsFile.delete();
        //noinspection ResultOfMethodCallIgnored
        marksFile.delete();
        notifyListeners();
    }

    public synchronized List<Pt> pointsCopy() {
        return new ArrayList<>(points);
    }

    public synchronized List<Mark> marksCopy() {
        return new ArrayList<>(marks);
    }

    public void addListener(Listener l) {
        synchronized (listeners) {
            if (!listeners.contains(l)) listeners.add(l);
        }
    }

    public void removeListener(Listener l) {
        synchronized (listeners) {
            listeners.remove(l);
        }
    }

    public void notifyListeners() {
        main.post(() -> {
            List<Listener> copy;
            synchronized (listeners) {
                copy = new ArrayList<>(listeners);
            }
            for (Listener l : copy) l.onTrackChanged();
        });
    }

    /** Distance in metres between two lat/lon points (haversine). */
    public static double distance(double lat1, double lon1, double lat2, double lon2) {
        double r = 6371008.8;
        double p1 = Math.toRadians(lat1), p2 = Math.toRadians(lat2);
        double dp = Math.toRadians(lat2 - lat1), dl = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2)
                + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * r * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    /** Road chainage style: 1250.4 m -> "1+250". */
    public static String fmtCh(double metres) {
        long m = Math.round(metres);
        return String.format(Locale.US, "%d+%03d", m / 1000, m % 1000);
    }
}
