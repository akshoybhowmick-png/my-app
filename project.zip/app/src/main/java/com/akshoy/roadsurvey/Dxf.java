package com.akshoy.roadsurvey;

import java.util.List;
import java.util.Locale;

/**
 * AutoCAD DXF (R12, ASCII) in UTM metres: 3D centre line, chainage ticks, marked points,
 * curves, road segments and the imported design. Opens in AutoCAD, BricsCAD, QGIS, etc.
 */
public class Dxf {

    private final StringBuilder sb = new StringBuilder();
    private int zone = -1;

    private void g(int code, String v) {
        sb.append(code).append('\n').append(v).append('\n');
    }

    private void g(int code, double v) {
        g(code, String.format(Locale.US, "%.4f", v));
    }

    /** Non-ASCII text (Bengali) as \U+XXXX so CAD programs can show it. */
    private static String txt(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 32 && c < 127) b.append(c);
            else if (c >= 127) b.append(String.format(Locale.US, "\\U+%04X", (int) c));
        }
        return b.toString();
    }

    private double[] xy(double lat, double lon) {
        Geo.Utm u = zone < 0 ? Geo.utm(lat, lon) : Geo.utm(lat, lon, zone);
        if (zone < 0) zone = u.zone;
        return new double[]{u.easting, u.northing};
    }

    private void text(String layer, double x, double y, double h, double rot, String s, int color) {
        g(0, "TEXT");
        g(8, layer);
        g(62, String.valueOf(color));
        g(10, x);
        g(20, y);
        g(30, 0);
        g(40, h);
        g(1, txt(s));
        g(50, rot);
    }

    private void point(String layer, double x, double y, double z, int color) {
        g(0, "POINT");
        g(8, layer);
        g(62, String.valueOf(color));
        g(10, x);
        g(20, y);
        g(30, z);
    }

    public static String build(List<TrackStore.Pt> pts, List<TrackStore.Mark> marks, List<TrackStore.Seg> segs,
                               RefLayer ref, String title, double startCh, double step) {
        Dxf d = new Dxf();
        if (!pts.isEmpty()) d.xy(pts.get(0).lat, pts.get(0).lon); // fixes the UTM zone
        d.g(0, "SECTION");
        d.g(2, "HEADER");
        d.g(9, "$ACADVER");
        d.g(1, "AC1009");
        d.g(0, "ENDSEC");
        d.g(0, "SECTION");
        d.g(2, "ENTITIES");

        // centre line (3D polyline, Z = smoothed elevation)
        if (pts.size() >= 2) {
            double[] h = Profile.smooth(pts);
            d.g(0, "POLYLINE");
            d.g(8, "ROAD_CENTRELINE");
            d.g(62, "1");
            d.g(66, "1");
            d.g(70, "8");
            d.g(10, 0);
            d.g(20, 0);
            d.g(30, 0);
            for (int i = 0; i < pts.size(); i++) {
                double[] p = d.xy(pts.get(i).lat, pts.get(i).lon);
                d.g(0, "VERTEX");
                d.g(8, "ROAD_CENTRELINE");
                d.g(10, p[0]);
                d.g(20, p[1]);
                d.g(30, h[i]);
                d.g(70, "32");
            }
            d.g(0, "SEQEND");
            d.g(8, "ROAD_CENTRELINE");

            // chainage ticks
            double len = pts.get(pts.size() - 1).ch;
            double next = Math.ceil(startCh / step) * step;
            for (int i = 1; i < pts.size(); i++) {
                TrackStore.Pt a = pts.get(i - 1), b = pts.get(i);
                double ca = startCh + a.ch, cb = startCh + b.ch;
                while (next <= cb) {
                    if (next >= ca) {
                        double f = cb - ca < 1e-6 ? 0 : (next - ca) / (cb - ca);
                        double[] p = d.xy(a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f);
                        double brg = Geo.bearing(a.lat, a.lon, b.lat, b.lon);
                        double rot = 90 - brg - 90; // text across the road
                        boolean km = Math.round(next) % 1000 == 0;
                        d.point("CHAINAGE", p[0], p[1], 0, km ? 5 : 7);
                        d.text("CHAINAGE", p[0] + 1.5, p[1] + 1.5, km ? 4 : 2.5, rot, TrackStore.fmtCh(next), km ? 5 : 7);
                    }
                    next += step;
                }
            }
            double[] s0 = d.xy(pts.get(0).lat, pts.get(0).lon);
            d.text("ROAD_CENTRELINE", s0[0] + 3, s0[1] - 6, 4, 0, title + "  START " + TrackStore.fmtCh(startCh), 1);
            TrackStore.Pt e = pts.get(pts.size() - 1);
            double[] e0 = d.xy(e.lat, e.lon);
            d.text("ROAD_CENTRELINE", e0[0] + 3, e0[1] - 6, 4, 0, "END " + TrackStore.fmtCh(startCh + len), 1);

            // curves
            int n = 1;
            for (Curves.Curve c : Curves.find(pts)) {
                double[] p = d.xy(c.midLat, c.midLon);
                d.text("CURVES", p[0] + 4, p[1] + 4, 3, 0, String.format(Locale.US, "C%d %s R=%.0fm D=%.1f L=%.0fm Ch %s-%s",
                        n++, c.right ? "RH" : "LH", c.radius, c.deflection, c.length,
                        TrackStore.fmtCh(startCh + c.startCh), TrackStore.fmtCh(startCh + c.endCh)), 3);
            }

            // road segments
            for (TrackStore.Seg sg : segs) {
                double[] pos = TrackStore.positionAt(pts, timeAtCh(pts, sg.ch));
                if (pos == null) continue;
                double[] p = d.xy(pos[0], pos[1]);
                d.text("SEGMENTS", p[0] - 4, p[1] - 8, 2.5, 0, TrackStore.fmtCh(startCh + sg.ch) + " " + sg.surface + " / "
                        + sg.condition + (Double.isNaN(sg.width) ? "" : String.format(Locale.US, " / %.1fm", sg.width)), 6);
            }
        }

        // marked points
        int n = 1;
        for (TrackStore.Mark m : marks) {
            double[] p = d.xy(m.lat, m.lon);
            d.point("POINTS", p[0], p[1], m.alt, 2);
            d.text("POINTS", p[0] + 1.5, p[1] - 1.5, 2.5, 0, n++ + ". " + m.name + "  " + TrackStore.fmtCh(startCh + m.ch), 2);
        }

        // imported design
        if (ref != null) {
            for (List<double[]> ln : ref.lines) {
                d.g(0, "POLYLINE");
                d.g(8, "DESIGN");
                d.g(62, "4");
                d.g(66, "1");
                d.g(70, "0");
                d.g(10, 0);
                d.g(20, 0);
                d.g(30, 0);
                for (double[] q : ln) {
                    double[] p = d.xy(q[0], q[1]);
                    d.g(0, "VERTEX");
                    d.g(8, "DESIGN");
                    d.g(10, p[0]);
                    d.g(20, p[1]);
                    d.g(30, 0);
                }
                d.g(0, "SEQEND");
                d.g(8, "DESIGN");
            }
            for (RefLayer.RefPoint rp : ref.points) {
                double[] p = d.xy(rp.lat, rp.lon);
                d.point("DESIGN", p[0], p[1], 0, 4);
                if (!rp.name.isEmpty()) d.text("DESIGN", p[0] + 1.5, p[1] + 1.5, 2, 0, rp.name, 4);
            }
        }

        d.g(0, "ENDSEC");
        d.g(0, "EOF");
        return d.sb.toString();
    }

    /** Time at which the recording passed a raw chainage (for placing labels). */
    private static long timeAtCh(List<TrackStore.Pt> pts, double ch) {
        for (int i = 1; i < pts.size(); i++) {
            TrackStore.Pt a = pts.get(i - 1), b = pts.get(i);
            if (b.ch >= ch) {
                double f = b.ch - a.ch < 1e-6 ? 0 : (ch - a.ch) / (b.ch - a.ch);
                return a.time + (long) ((b.time - a.time) * Math.max(0, Math.min(1, f)));
            }
        }
        return pts.isEmpty() ? 0 : pts.get(pts.size() - 1).time;
    }
}
