package com.akshoy.roadsurvey;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Subtitle file (.srt) that shows chainage & GPS over the video in VLC / MX Player. */
public class Srt {

    private static String ts(long ms) {
        long h = ms / 3600000, m = (ms / 60000) % 60, s = (ms / 1000) % 60, x = ms % 1000;
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, x);
    }

    public static String build(List<TrackStore.Pt> pts, long videoStart, long durationMs,
                               double startCh, String surveyName) {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat clock = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US);
        int n = 1;
        for (long t = 0; t < durationMs; t += 1000) {
            long end = Math.min(t + 1000, durationMs);
            double[] pos = TrackStore.positionAt(pts, videoStart + t);
            sb.append(n++).append('\n').append(ts(t)).append(" --> ").append(ts(end)).append('\n');
            if (pos == null) {
                sb.append(surveyName).append("  |  GPS নেই\n");
            } else {
                sb.append(String.format(Locale.US, "Ch %s  |  %.0f km/h  |  %s\n%.6f, %.6f  |  %s\n",
                        TrackStore.fmtCh(startCh + pos[2]), pos[3], surveyName,
                        pos[0], pos[1], clock.format(new Date(videoStart + t))));
            }
            sb.append('\n');
        }
        return sb.toString();
    }
}
