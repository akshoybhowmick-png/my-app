package com.akshoy.roadsurvey;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.MapTileIndex;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements TrackStore.Listener {

    private static final int REQ_LOCATION = 1;
    private static final int REQ_STORAGE = 2;

    private static final ITileSource SATELLITE = new XYTileSource("EsriWorldImagery", 0, 19, 256, ".jpg",
            new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"}) {
        @Override
        public String getTileURLString(long index) {
            return getBaseUrl() + MapTileIndex.getZoom(index) + "/"
                    + MapTileIndex.getY(index) + "/" + MapTileIndex.getX(index);
        }
    };

    private TrackStore store;
    private MapView map;
    private Polyline line;
    private MyLocationNewOverlay myLocation;
    private final List<Marker> markerOverlays = new ArrayList<>();
    private int shownMarks = -1;
    private boolean satellite = false;
    private boolean firstFix = true;
    private int pendingExport = -1;

    private TextView tvChainage, tvInfo;
    private Button btnStart, btnMap;

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", Context.MODE_PRIVATE));
        Configuration.getInstance().setUserAgentValue(getPackageName());
        File osmBase = new File(getFilesDir(), "osmdroid");
        Configuration.getInstance().setOsmdroidBasePath(osmBase);
        Configuration.getInstance().setOsmdroidTileCache(new File(osmBase, "tiles"));
        store = TrackStore.get(this);

        FrameLayout root = new FrameLayout(this);

        map = new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.getController().setZoom(8.0);
        map.getController().setCenter(new GeoPoint(23.0, 87.9));
        root.addView(map, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        line = new Polyline();
        line.getOutlinePaint().setColor(Color.rgb(229, 57, 53));
        line.getOutlinePaint().setStrokeWidth(dp(4));
        map.getOverlays().add(line);

        myLocation = new MyLocationNewOverlay(new GpsMyLocationProvider(this), map);
        map.getOverlays().add(myLocation);

        // Top info panel
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(14), dp(10), dp(14), dp(10));
        top.setBackground(card());
        tvChainage = new TextView(this);
        tvChainage.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        tvChainage.setTypeface(Typeface.DEFAULT_BOLD);
        tvChainage.setTextColor(Color.rgb(21, 101, 192));
        tvInfo = new TextView(this);
        tvInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tvInfo.setTextColor(Color.DKGRAY);
        top.addView(tvChainage);
        top.addView(tvInfo);
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        topLp.setMargins(dp(10), dp(30), dp(10), 0);
        root.addView(top, topLp);

        // Bottom buttons
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(8), dp(8), dp(8), dp(8));
        bottom.setBackground(card());

        LinearLayout row1 = new LinearLayout(this);
        btnStart = button("▶ রেকর্ড শুরু", Color.rgb(46, 125, 50));
        Button btnMark = button("📍 পয়েন্ট মার্ক", Color.rgb(239, 108, 0));
        row1.addView(btnStart, weight());
        row1.addView(btnMark, weight());

        LinearLayout row2 = new LinearLayout(this);
        Button btnExport = button("এক্সপোর্ট", Color.rgb(21, 101, 192));
        btnMap = button("স্যাটেলাইট", Color.rgb(84, 110, 122));
        Button btnLocate = button("আমি কোথায়", Color.rgb(84, 110, 122));
        Button btnNew = button("নতুন সার্ভে", Color.rgb(183, 28, 28));
        row2.addView(btnExport, weight());
        row2.addView(btnMap, weight());
        row2.addView(btnLocate, weight());
        row2.addView(btnNew, weight());

        bottom.addView(row1);
        bottom.addView(row2);
        FrameLayout.LayoutParams botLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        botLp.setMargins(dp(10), 0, dp(10), dp(20));
        root.addView(bottom, botLp);

        setContentView(root);

        btnStart.setOnClickListener(v -> {
            if (store.tracking) stopTracking();
            else startTracking();
        });
        btnMark.setOnClickListener(v -> markPoint());
        btnExport.setOnClickListener(v -> chooseExport());
        btnMap.setOnClickListener(v -> toggleMap());
        btnLocate.setOnClickListener(v -> locateMe());
        btnNew.setOnClickListener(v -> newSurvey());

        if (hasLocationPermission()) myLocation.enableMyLocation();

        List<TrackStore.Pt> pts = store.pointsCopy();
        if (!pts.isEmpty()) {
            map.getController().setZoom(17.0);
            TrackStore.Pt p = pts.get(pts.size() - 1);
            map.getController().setCenter(new GeoPoint(p.lat, p.lon));
            firstFix = false;
        }
    }

    private GradientDrawable card() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(235, 255, 255, 255));
        g.setCornerRadius(dp(14));
        return g;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        b.setPadding(dp(4), dp(6), dp(4), dp(6));
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        return lp;
    }

    // ---------- Lifecycle ----------

    @Override
    protected void onResume() {
        super.onResume();
        map.onResume();
        store.addListener(this);
        onTrackChanged();
    }

    @Override
    protected void onPause() {
        store.removeListener(this);
        map.onPause();
        super.onPause();
    }

    @Override
    public void onTrackChanged() {
        List<TrackStore.Pt> pts = store.pointsCopy();
        List<GeoPoint> geo = new ArrayList<>(pts.size());
        for (TrackStore.Pt p : pts) geo.add(new GeoPoint(p.lat, p.lon));
        line.setPoints(geo);

        List<TrackStore.Mark> marks = store.marksCopy();
        if (marks.size() != shownMarks) {
            map.getOverlays().removeAll(markerOverlays);
            markerOverlays.clear();
            for (TrackStore.Mark m : marks) {
                Marker mk = new Marker(map);
                mk.setPosition(new GeoPoint(m.lat, m.lon));
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
                mk.setTitle(m.name);
                mk.setSnippet("চেইনেজ " + TrackStore.fmtCh(m.ch));
                markerOverlays.add(mk);
            }
            map.getOverlays().addAll(markerOverlays);
            shownMarks = marks.size();
        }

        double ch = pts.isEmpty() ? 0 : pts.get(pts.size() - 1).ch;
        tvChainage.setText("চেইনেজ  " + TrackStore.fmtCh(ch));
        String acc = store.lastAcc < 0 ? "—" : String.format(Locale.US, "±%.0f মি", store.lastAcc);
        String status = store.tracking ? "● রেকর্ড চলছে" : "■ বন্ধ";
        tvInfo.setText(String.format(Locale.US, "%s   |   দূরত্ব %.1f মি   |   পয়েন্ট %d   |   মার্ক %d\nGPS নির্ভুলতা %s",
                status, ch, pts.size(), marks.size(), acc));
        tvInfo.setTextColor(store.tracking ? Color.rgb(46, 125, 50) : Color.DKGRAY);

        btnStart.setText(store.tracking ? "■ রেকর্ড বন্ধ" : "▶ রেকর্ড শুরু");
        ((GradientDrawable) btnStart.getBackground()).setColor(
                store.tracking ? Color.rgb(198, 40, 40) : Color.rgb(46, 125, 50));

        if (!pts.isEmpty()) {
            TrackStore.Pt last = pts.get(pts.size() - 1);
            GeoPoint gp = new GeoPoint(last.lat, last.lon);
            if (store.tracking && firstFix) {
                map.getController().setZoom(18.0);
                map.getController().setCenter(gp);
                firstFix = false;
            } else if (store.tracking && !map.getBoundingBox().contains(gp)) {
                map.getController().animateTo(gp);
            }
        }
        map.invalidate();
    }

    // ---------- Tracking ----------

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startTracking() {
        if (!hasLocationPermission()) {
            List<String> perms = new ArrayList<>();
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION);
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS);
            requestPermissions(perms.toArray(new String[0]), REQ_LOCATION);
            return;
        }
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            new AlertDialog.Builder(this)
                    .setTitle("GPS বন্ধ আছে")
                    .setMessage("রাস্তা রেকর্ড করতে ফোনের লোকেশন (GPS) চালু করুন।")
                    .setPositiveButton("চালু করুন", (d, w) ->
                            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton("বাতিল", null)
                    .show();
            return;
        }
        myLocation.enableMyLocation();
        firstFix = store.points.isEmpty();
        Intent i = new Intent(this, TrackingService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        Toast.makeText(this, "রেকর্ড শুরু হলো। GPS ঠিকমতো ধরতে কয়েক সেকেন্ড লাগতে পারে।", Toast.LENGTH_LONG).show();
    }

    private void stopTracking() {
        stopService(new Intent(this, TrackingService.class));
        Toast.makeText(this, "রেকর্ড বন্ধ হলো। ডেটা সেভ আছে।", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (hasLocationPermission()) myLocation.enableMyLocation();
        if (requestCode == REQ_LOCATION) {
            if (hasLocationPermission()) startTracking();
            else Toast.makeText(this, "লোকেশন অনুমতি ছাড়া রেকর্ড করা যাবে না।", Toast.LENGTH_LONG).show();
        } else if (requestCode == REQ_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && pendingExport >= 0) {
                doExport(pendingExport);
            } else {
                Toast.makeText(this, "ফাইল সেভের অনুমতি পাওয়া যায়নি।", Toast.LENGTH_LONG).show();
            }
            pendingExport = -1;
        }
    }

    // ---------- Marking points ----------

    private double[] currentLocation() {
        if (store.hasFix) return new double[]{store.fixLat, store.fixLon, store.fixAlt};
        if (myLocation.getMyLocation() != null) {
            GeoPoint g = myLocation.getMyLocation();
            return new double[]{g.getLatitude(), g.getLongitude(), g.getAltitude()};
        }
        if (hasLocationPermission()) {
            try {
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (l != null && System.currentTimeMillis() - l.getTime() < 60_000) {
                    return new double[]{l.getLatitude(), l.getLongitude(), l.getAltitude()};
                }
            } catch (SecurityException ignored) {
            }
        }
        return null;
    }

    private void markPoint() {
        final double[] loc = currentLocation();
        if (loc == null) {
            Toast.makeText(this, "এখনও GPS অবস্থান পাওয়া যায়নি। আগে রেকর্ড শুরু করে একটু অপেক্ষা করুন।",
                    Toast.LENGTH_LONG).show();
            return;
        }
        final String[] presets = {"কালভার্ট", "ব্রিজ", "বাঁক / মোড়", "জংশন / ক্রসিং",
                "স্কুল / বাজার / বসতি", "শুরু বিন্দু", "শেষ বিন্দু", "অন্য (নিজে লিখুন)"};
        new AlertDialog.Builder(this)
                .setTitle("কী চিহ্নিত করবেন?")
                .setItems(presets, (d, which) -> {
                    if (which == presets.length - 1) askName(loc);
                    else saveMark(presets[which], loc);
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void askName(final double[] loc) {
        final EditText et = new EditText(this);
        et.setHint("যেমন: পুকুর, মন্দির, বিদ্যুতের খুঁটি");
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(et);
        new AlertDialog.Builder(this)
                .setTitle("পয়েন্টের নাম")
                .setView(box)
                .setPositiveButton("সেভ", (d, w) -> {
                    String n = et.getText().toString().trim();
                    saveMark(n.isEmpty() ? "পয়েন্ট" : n, loc);
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void saveMark(String name, double[] loc) {
        TrackStore.Mark m = store.addMark(name, loc[0], loc[1], loc[2]);
        Toast.makeText(this, name + " মার্ক হলো, চেইনেজ " + TrackStore.fmtCh(m.ch), Toast.LENGTH_SHORT).show();
    }

    // ---------- Map ----------

    private void toggleMap() {
        satellite = !satellite;
        map.setTileSource(satellite ? SATELLITE : TileSourceFactory.MAPNIK);
        btnMap.setText(satellite ? "সাধারণ ম্যাপ" : "স্যাটেলাইট");
    }

    private void locateMe() {
        double[] loc = currentLocation();
        if (loc == null) {
            if (!hasLocationPermission()) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION + 100);
            } else {
                myLocation.enableMyLocation();
            }
            Toast.makeText(this, "অবস্থান খোঁজা হচ্ছে, একটু পরে আবার চাপুন।", Toast.LENGTH_SHORT).show();
            return;
        }
        if (map.getZoomLevelDouble() < 16) map.getController().setZoom(18.0);
        map.getController().animateTo(new GeoPoint(loc[0], loc[1]));
    }

    private void newSurvey() {
        if (store.tracking) {
            Toast.makeText(this, "আগে রেকর্ড বন্ধ করুন।", Toast.LENGTH_SHORT).show();
            return;
        }
        if (store.points.isEmpty() && store.marks.isEmpty()) {
            Toast.makeText(this, "কোনো ডেটা নেই, সরাসরি রেকর্ড শুরু করুন।", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("নতুন সার্ভে শুরু করবেন?")
                .setMessage("বর্তমান রেকর্ড মুছে যাবে। আগে এক্সপোর্ট করে নিয়েছেন তো?")
                .setPositiveButton("হ্যাঁ, মুছে দিন", (d, w) -> {
                    store.clear();
                    firstFix = true;
                })
                .setNegativeButton("না", null)
                .show();
    }

    // ---------- Export ----------

    private void chooseExport() {
        if (store.points.isEmpty() && store.marks.isEmpty()) {
            Toast.makeText(this, "এক্সপোর্ট করার মতো কোনো ডেটা নেই।", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] items = {"KML (Google Earth)", "CSV (Excel)", "GPX", "তিনটেই"};
        new AlertDialog.Builder(this)
                .setTitle("কোন ফাইলে এক্সপোর্ট করবেন?")
                .setItems(items, (d, which) -> {
                    if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(
                            Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        pendingExport = which;
                        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
                    } else {
                        doExport(which);
                    }
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void doExport(int which) {
        List<TrackStore.Pt> pts = store.pointsCopy();
        List<TrackStore.Mark> marks = store.marksCopy();
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String base = "road_" + stamp;
        String title = "Road survey " + stamp;
        ArrayList<Uri> uris = new ArrayList<>();
        List<String> names = new ArrayList<>();
        try {
            if (which == 0 || which == 3) {
                addUri(uris, Exporter.save(this, base + ".kml", "application/octet-stream",
                        Exporter.kml(pts, marks, title)));
                names.add(base + ".kml");
            }
            if (which == 1 || which == 3) {
                addUri(uris, Exporter.save(this, base + ".csv", "text/csv", Exporter.csv(pts, marks)));
                names.add(base + ".csv");
            }
            if (which == 2 || which == 3) {
                addUri(uris, Exporter.save(this, base + ".gpx", "application/octet-stream",
                        Exporter.gpx(pts, marks, title)));
                names.add(base + ".gpx");
            }
        } catch (Exception e) {
            new AlertDialog.Builder(this)
                    .setTitle("এক্সপোর্ট হয়নি")
                    .setMessage(String.valueOf(e.getMessage()))
                    .setPositiveButton("ঠিক আছে", null)
                    .show();
            return;
        }

        StringBuilder msg = new StringBuilder("ফোনের Download/" + Exporter.FOLDER + " ফোল্ডারে সেভ হয়েছে:\n\n");
        for (String n : names) msg.append("• ").append(n).append('\n');
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("এক্সপোর্ট সম্পূর্ণ")
                .setMessage(msg.toString())
                .setPositiveButton("ঠিক আছে", null);
        if (!uris.isEmpty()) {
            b.setNeutralButton("শেয়ার করুন", (d, w) -> share(uris));
        }
        b.show();
    }

    private static void addUri(List<Uri> list, Uri u) {
        if (u != null) list.add(u);
    }

    private void share(ArrayList<Uri> uris) {
        Intent send;
        if (uris.size() == 1) {
            send = new Intent(Intent.ACTION_SEND);
            send.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            send = new Intent(Intent.ACTION_SEND_MULTIPLE);
            send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        send.setType("*/*");
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, "শেয়ার করুন"));
    }
}
