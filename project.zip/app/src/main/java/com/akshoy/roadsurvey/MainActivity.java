package com.akshoy.roadsurvey;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.cachemanager.CacheManager;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.MapTileIndex;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements TrackStore.Listener {

    private static final int REQ_LOCATION = 1;
    private static final int REQ_STORAGE_EXPORT = 2;
    private static final int REQ_STORAGE_PHOTO = 3;
    private static final int REQ_LOCATE = 4;
    private static final int REQ_CAMERA = 10;
    private static final int REQ_CAMERA_PERM = 5;
    private static final int REQ_RESTORE = 11;

    private static final ITileSource SATELLITE = new XYTileSource("EsriWorldImagery", 0, 19, 256, ".jpg",
            new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"}) {
        @Override
        public String getTileURLString(long index) {
            return getBaseUrl() + MapTileIndex.getZoom(index) + "/"
                    + MapTileIndex.getY(index) + "/" + MapTileIndex.getX(index);
        }
    };

    private TrackStore store;
    private MapView map;
    private Polyline line;
    private ChainageOverlay chainageOverlay;
    private MyLocationNewOverlay myLocation;
    private final List<Marker> markerOverlays = new ArrayList<>();
    private String shownMarksKey = "";
    private boolean satellite = false;
    private boolean firstFix = true;

    private int pendingExport = -1;
    private int pendingPhotoIndex = -1;
    private Uri pendingPhotoUri;

    private TextView tvSurvey, tvChainage, tvInfo;
    private Button btnStart;

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLog.install(this);
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", Context.MODE_PRIVATE));
        Configuration.getInstance().setUserAgentValue(getPackageName());
        File osmBase = new File(getFilesDir(), "osmdroid");
        Configuration.getInstance().setOsmdroidBasePath(osmBase);
        Configuration.getInstance().setOsmdroidTileCache(new File(osmBase, "tiles"));
        Configuration.getInstance().setTileFileSystemCacheMaxBytes(1500L * 1024 * 1024);
        Configuration.getInstance().setTileFileSystemCacheTrimBytes(1200L * 1024 * 1024);
        store = TrackStore.get(this);

        if (savedInstanceState != null) {
            pendingPhotoIndex = savedInstanceState.getInt("photoIndex", -1);
            String u = savedInstanceState.getString("photoUri");
            if (u != null) pendingPhotoUri = Uri.parse(u);
        }

        FrameLayout root = new FrameLayout(this);

        map = new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.getController().setZoom(8.0);
        map.getController().setCenter(new GeoPoint(23.0, 87.9));
        root.addView(map, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        line = new Polyline();
        line.getOutlinePaint().setColor(Color.rgb(229, 57, 53));
        line.getOutlinePaint().setStrokeWidth(dp(4));
        map.getOverlays().add(line);

        chainageOverlay = new ChainageOverlay(getResources().getDisplayMetrics().density);
        map.getOverlays().add(chainageOverlay);

        myLocation = new MyLocationNewOverlay(new GpsMyLocationProvider(this), map);
        map.getOverlays().add(myLocation);

        // ----- Top info card -----
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(14), dp(8), dp(60), dp(10));
        top.setBackground(card());
        tvSurvey = new TextView(this);
        tvSurvey.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvSurvey.setTextColor(Color.rgb(90, 90, 90));
        tvChainage = new TextView(this);
        tvChainage.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        tvChainage.setTypeface(Typeface.DEFAULT_BOLD);
        tvChainage.setTextColor(Color.rgb(21, 101, 192));
        tvInfo = new TextView(this);
        tvInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        top.addView(tvSurvey);
        top.addView(tvChainage);
        top.addView(tvInfo);
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        topLp.setMargins(dp(10), dp(30), dp(10), 0);
        root.addView(top, topLp);

        // power / exit button in the top-right corner of the info card
        Button btnExit = button("⏻", Color.rgb(183, 28, 28));
        btnExit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        btnExit.setPadding(0, 0, 0, 0);
        FrameLayout.LayoutParams exitLp = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP | Gravity.END);
        exitLp.setMargins(0, dp(38), dp(18), 0);
        root.addView(btnExit, exitLp);
        btnExit.setOnClickListener(v -> exitApp());

        // ----- Bottom buttons -----
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(8), dp(8), dp(8), dp(8));
        bottom.setBackground(card());

        LinearLayout row1 = new LinearLayout(this);
        btnStart = button(L.t("▶ রেকর্ড শুরু", "▶ Start recording"), Color.rgb(46, 125, 50));
        Button btnMark = button(L.t("📍 মার্ক", "📍 Mark"), Color.rgb(239, 108, 0));
        Button btnVideo = button(L.t("🎥 ভিডিও", "🎥 Video"), Color.rgb(106, 27, 154));
        row1.addView(btnStart, weight());
        row1.addView(btnMark, weight());
        row1.addView(btnVideo, weight());

        LinearLayout row2 = new LinearLayout(this);
        int grey = Color.rgb(69, 90, 100);
        Button btnSurveys = button(L.t("সার্ভে", "Surveys"), grey);
        Button btnExport = button(L.t("এক্সপোর্ট", "Export"), Color.rgb(21, 101, 192));
        Button btnProfile = button(L.t("উচ্চতা", "Elevation"), grey);
        Button btnMapMenu = button(L.t("ম্যাপ", "Map"), grey);
        Button btnSettings = button("⚙", grey);
        row2.addView(btnSurveys, weight());
        row2.addView(btnExport, weight());
        row2.addView(btnProfile, weight());
        row2.addView(btnMapMenu, weight());
        LinearLayout.LayoutParams gearLp = new LinearLayout.LayoutParams(dp(50), dp(50));
        gearLp.setMargins(dp(3), dp(3), dp(3), dp(3));
        row2.addView(btnSettings, gearLp);

        TextView dev = new TextView(this);
        dev.setText(AppSettings.DEVELOPER);
        dev.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        dev.setTextColor(Color.rgb(21, 101, 192));
        dev.setGravity(Gravity.CENTER);
        dev.setPadding(0, dp(2), 0, 0);
        dev.setOnClickListener(v -> AppSettings.about(this));

        bottom.addView(row1);
        bottom.addView(row2);
        bottom.addView(dev);
        FrameLayout.LayoutParams botLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        botLp.setMargins(dp(10), 0, dp(10), dp(20));
        root.addView(bottom, botLp);

        setContentView(root);

        btnStart.setOnClickListener(v -> {
            if (store.tracking) pauseTracking();
            else startTracking();
        });
        btnMark.setOnClickListener(v -> markPoint());
        btnMark.setOnLongClickListener(v -> {
            averagedMark();
            return true;
        });
        btnSurveys.setOnClickListener(v -> surveyMenu());
        btnExport.setOnClickListener(v -> chooseExport());
        btnProfile.setOnClickListener(v -> showProfile());
        btnMapMenu.setOnClickListener(v -> mapMenu());
        btnVideo.setOnClickListener(v -> startActivity(new Intent(this, VideoActivity.class)));
        btnSettings.setOnClickListener(v -> AppSettings.show(this, () -> {
            shownMarksKey = "";
            onTrackChanged();
        }));

        line.setOnClickListener((poly, mapView, eventPos) -> {
            roadTapped(eventPos);
            return true;
        });
        if (AppSettings.satelliteDefault(this)) toggleMap();

        if (hasLocationPermission()) myLocation.enableMyLocation();

        CrashLog.showIfAny(this);

        TrackStore.Pt last = store.lastPoint();
        if (last != null) {
            map.getController().setZoom(17.0);
            map.getController().setCenter(new GeoPoint(last.lat, last.lon));
            firstFix = false;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("photoIndex", pendingPhotoIndex);
        if (pendingPhotoUri != null) out.putString("photoUri", pendingPhotoUri.toString());
    }

    // ---------- small UI helpers ----------

    private GradientDrawable card() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(235, 255, 255, 255));
        g.setCornerRadius(dp(14));
        return g;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        b.setPadding(dp(4), dp(6), dp(4), dp(6));
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        return lp;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private static String safeName(String s) {
        String t = s.trim().replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
        return t.isEmpty() ? "survey" : t;
    }

    private static String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    // ---------- Lifecycle ----------

    @Override
    protected void onResume() {
        super.onResume();
        map.onResume();
        store.addListener(this);
        onTrackChanged();
    }

    @Override
    protected void onPause() {
        store.removeListener(this);
        map.onPause();
        super.onPause();
    }

    @Override
    public void onTrackChanged() {
        List<TrackStore.Pt> pts = store.pointsCopy();
        List<GeoPoint> geo = new ArrayList<>(pts.size());
        for (TrackStore.Pt p : pts) geo.add(new GeoPoint(p.lat, p.lon));
        line.setPoints(geo);
        chainageOverlay.setTrack(pts, store.startCh, AppSettings.tickStep(this));

        List<TrackStore.Mark> marks = store.marksCopy();
        StringBuilder key = new StringBuilder(store.id).append('|').append(store.startCh);
        for (TrackStore.Mark m : marks) key.append('|').append(m.time).append(m.photo.isEmpty() ? '-' : '+');
        if (!key.toString().equals(shownMarksKey)) {
            map.getOverlays().removeAll(markerOverlays);
            markerOverlays.clear();
            for (int i = 0; i < marks.size(); i++) {
                TrackStore.Mark m = marks.get(i);
                Marker mk = new Marker(map);
                mk.setPosition(new GeoPoint(m.lat, m.lon));
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
                mk.setTitle((i + 1) + ". " + m.name);
                final int index = i;
                mk.setOnMarkerClickListener((marker, mapView) -> {
                    showMarkDialog(index);
                    return true;
                });
                markerOverlays.add(mk);
            }
            map.getOverlays().addAll(markerOverlays);
            shownMarksKey = key.toString();
        }

        double raw = pts.isEmpty() ? 0 : pts.get(pts.size() - 1).ch;
        tvSurvey.setText("📋 " + store.name + L.t("   (শুরু ", "   (start ") + TrackStore.fmtCh(store.startCh) + ")");
        tvChainage.setText(L.t("চেইনেজ  ", "Chainage  ") + TrackStore.fmtCh(store.disp(raw)));
        String acc = store.lastAcc < 0 ? "—" : String.format(Locale.US, L.t("±%.0f মি", "±%.0f m"), store.lastAcc);
        if (store.satUsed >= 0) acc += String.format(Locale.US, L.t("  •  স্যাটেলাইট %d/%d", "  •  Satellites %d/%d"), store.satUsed, store.satSeen);
        String status = store.tracking ? L.t("● রেকর্ড চলছে", "● Recording") : (pts.isEmpty() ? L.t("■ শুরু হয়নি", "■ Not started") : L.t("⏸ পজ করা আছে", "⏸ Paused"));
        tvInfo.setText(String.format(Locale.US, L.t("%s  |  দূরত্ব %.1f মি  |  মার্ক %d\nGPS নির্ভুলতা %s  |  পয়েন্ট %d", "%s  |  Distance %.1f m  |  Marks %d\nGPS accuracy %s  |  Points %d"),
                status, raw, marks.size(), acc, pts.size()));
        tvInfo.setTextColor(store.tracking ? Color.rgb(46, 125, 50) : Color.DKGRAY);

        if (store.tracking) btnStart.setText(L.t("⏸ পজ", "⏸ Pause"));
        else btnStart.setText(pts.isEmpty() ? L.t("▶ রেকর্ড শুরু", "▶ Start recording") : L.t("▶ আবার চালু", "▶ Resume"));
        ((GradientDrawable) btnStart.getBackground()).setColor(
                store.tracking ? Color.rgb(198, 40, 40) : Color.rgb(46, 125, 50));

        if (!pts.isEmpty()) {
            TrackStore.Pt last = pts.get(pts.size() - 1);
            GeoPoint gp = new GeoPoint(last.lat, last.lon);
            if (store.tracking && firstFix) {
                map.getController().setZoom(18.0);
                map.getController().setCenter(gp);
                firstFix = false;
            } else if (store.tracking && !map.getBoundingBox().contains(gp)) {
                map.getController().animateTo(gp);
            }
        }
        if (store.tracking && AppSettings.keepScreenOn(this)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        map.invalidate();
    }

    // ---------- Exit & track cleaning ----------

    private void exitApp() {
        new AlertDialog.Builder(this)
                .setTitle(L.t("অ্যাপ বন্ধ করবেন?", "Close the app?"))
                .setMessage(store.tracking
                        ? L.t("GPS রেকর্ড চলছে। বন্ধ করলে রেকর্ড থেমে যাবে (এ পর্যন্ত সব সেভ থাকবে)। পরে খুলে \"আবার চালু\" চাপলে একই চেইনেজ থেকে চলবে।", "GPS recording is running. Closing will stop it (everything so far is saved). Open again and tap \"Resume\" to continue from the same chainage.")
                        : L.t("সব রেকর্ড সেভ আছে।", "All recordings are saved."))
                .setPositiveButton(L.t("⏻ বন্ধ করুন", "⏻ Close"), (d, w) -> {
                    stopService(new Intent(this, TrackingService.class));
                    finishAndRemoveTask();
                })
                .setNegativeButton(L.t("না", "No"), null)
                .show();
    }

    private void cleanTrackDialog() {
        String[] items = {
                L.t("↩  শেষ মার্ক করা পয়েন্ট মুছুন", "↩  Undo last marked point"),
                L.t("↩  লাইনের শেষ ২০ মিটার মুছুন", "↩  Remove last 20 m of the line"),
                L.t("↩  লাইনের শেষ ১০০ মিটার মুছুন", "↩  Remove last 100 m of the line"),
                L.t("〰  লাইন মসৃণ করুন – হালকা", "〰  Smooth the line – light"),
                L.t("〰  লাইন মসৃণ করুন – বেশি", "〰  Smooth the line – strong"),
                L.t("🧹  দাঁড়ানোর জায়গার বাড়তি পয়েন্ট মুছুন (৫ মি)", "🧹  Remove extra points where you stood (5 m)"),
                L.t("🧹  দাঁড়ানোর জায়গার বাড়তি পয়েন্ট মুছুন (১০ মি)", "🧹  Remove extra points where you stood (10 m)")};
        new AlertDialog.Builder(this)
                .setTitle(L.t("সম্পাদনা – ", "Edit – ") + store.name)
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        String n = store.undoLastMark();
                        toast(n == null ? L.t("মোছার মতো কোনো মার্ক নেই।", "No marks to undo.")
                                : "\"" + n + "\"" + L.t(" মুছে ফেলা হলো।", " removed."));
                        return;
                    }
                    if (which <= 2) {
                        int r = store.undoLastMetres(which == 1 ? 20 : 100);
                        toast(r == 0 ? L.t("মোছার মতো লাইন নেই।", "Nothing to remove.")
                                : String.format(Locale.US, L.t("%dটা পয়েন্ট মোছা হলো। এখন চেইনেজ %s",
                                "%d points removed. Chainage now %s"), r, TrackStore.fmtCh(store.disp(store.length()))));
                        return;
                    }
                    if (store.tracking) {
                        toast(L.t("পরিষ্কার করার আগে রেকর্ড পজ করুন।", "Pause recording before cleaning."));
                        return;
                    }
                    double before = store.length();
                    String msg;
                    if (which <= 4) {
                        int n = store.smoothTrack(which == 3 ? 2 : 4);
                        msg = n == 0 ? L.t("মসৃণ করার মতো যথেষ্ট পয়েন্ট নেই।", "Not enough points to smooth.") : L.t("লাইন মসৃণ হলো।", "Line smoothed.");
                    } else {
                        int removed = store.cleanTrack(which == 5 ? 5 : 10);
                        msg = removed == 0 ? L.t("সরানোর মতো বাড়তি পয়েন্ট পাওয়া যায়নি।", "No extra points found to remove.") : removed + L.t("টা বাড়তি পয়েন্ট সরানো হলো।", " extra points removed.");
                    }
                    toast(msg + String.format(Locale.US, L.t("\nদৈর্ঘ্য: %.1f মি → %.1f মি", "\nLength: %.1f m → %.1f m"), before, store.length()));
                })
                .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                .show();
    }

    // ---------- Accurate (averaged) point ----------

    /** Long-press on "Mark": collect GPS readings for 30 s standing still and average them. */
    private void averagedMark() {
        if (!hasLocationPermission()) {
            startTracking(); // asks for permission
            return;
        }
        final LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        final double[] sum = new double[4]; // lat, lon, alt, count
        final float[] best = {Float.MAX_VALUE};
        final int maxAcc = AppSettings.maxAccuracy(this);
        final android.location.LocationListener ll = new android.location.LocationListener() {
            @Override
            public void onLocationChanged(Location l) {
                if (l.hasAccuracy() && l.getAccuracy() > maxAcc) return;
                sum[0] += l.getLatitude();
                sum[1] += l.getLongitude();
                sum[2] += store.hasFix ? store.fixAlt : l.getAltitude();
                sum[3] += 1;
                if (l.hasAccuracy()) best[0] = Math.min(best[0], l.getAccuracy());
            }

            @Override
            public void onStatusChanged(String p, int s, Bundle e) {
            }

            @Override
            public void onProviderEnabled(String p) {
            }

            @Override
            public void onProviderDisabled(String p) {
            }
        };
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, ll);
        } catch (SecurityException e) {
            return;
        }
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle(L.t("🎯 নির্ভুল পয়েন্ট", "🎯 Accurate point"));
        pd.setMessage(L.t("একদম স্থির হয়ে দাঁড়িয়ে থাকুন…", "Stand completely still…"));
        pd.setCancelable(false);
        final boolean[] cancelled = {false};
        pd.setButton(ProgressDialog.BUTTON_NEGATIVE, L.t("বাতিল", "Cancel"), (d, w) -> cancelled[0] = true);
        pd.show();
        final long start = System.currentTimeMillis();
        final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        h.post(new Runnable() {
            @Override
            public void run() {
                long left = 30 - (System.currentTimeMillis() - start) / 1000;
                if (!cancelled[0] && left > 0) {
                    pd.setMessage(String.format(Locale.US, L.t("একদম স্থির হয়ে দাঁড়িয়ে থাকুন…\n\nবাকি %d সেকেন্ড  •  রিডিং %d",
                            "Stand completely still…\n\n%d s left  •  readings %d"), left, (int) sum[3]));
                    h.postDelayed(this, 500);
                    return;
                }
                lm.removeUpdates(ll);
                try {
                    pd.dismiss();
                } catch (Exception ignored) {
                }
                if (cancelled[0] || isFinishing()) return;
                if (sum[3] < 5) {
                    toast(L.t("যথেষ্ট ভালো GPS রিডিং পাওয়া যায়নি। খোলা জায়গায় আবার চেষ্টা করুন।",
                            "Not enough good GPS readings. Try again in an open place."));
                    return;
                }
                final double[] loc = {sum[0] / sum[3], sum[1] / sum[3], sum[2] / sum[3]};
                toast(String.format(Locale.US, L.t("%dটা রিডিংয়ের গড় নেওয়া হলো", "Averaged %d readings"), (int) sum[3]));
                Tags.pick(MainActivity.this, tag -> saveMark(tag, loc));
            }
        });
    }

    // ---------- Tapping the road: chainage + video at that spot ----------

    private void roadTapped(GeoPoint at) {
        int idx = store.nearestIndex(at.getLatitude(), at.getLongitude());
        if (idx < 0) return;
        final TrackStore.Pt p = store.points.get(idx);
        final TrackStore.VideoRec v = store.videoAt(p.time);
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(L.t("চেইনেজ ", "Chainage ") + TrackStore.fmtCh(store.disp(p.ch)))
                .setMessage(String.format(Locale.US, L.t("অক্ষাংশ: %.6f\nদ্রাঘিমাংশ: %.6f\nউচ্চতা: %.1f মি\nসময়: %s%s", "Latitude: %.6f\nLongitude: %.6f\nElevation: %.1f m\nTime: %s%s"),
                        p.lat, p.lon, p.alt, Exporter.local(p.time) + "\nUTM " + Geo.utm(p.lat, p.lon),
                        v == null ? L.t("\n\nএই জায়গার কোনো ভিডিও নেই।", "\n\nNo video for this place.") : L.t("\n\nএই জায়গার ভিডিও আছে।", "\n\nThere is a video of this place.")))
                .setPositiveButton(L.t("ঠিক আছে", "OK"), null);
        if (v != null) {
            b.setNeutralButton(L.t("▶ এখান থেকে ভিডিও", "▶ Play video from here"), (d, w) -> PlayerActivity.open(this, v, p.time - v.start - 2000));
        }
        b.show();
    }

    private void videoList() {
        final List<TrackStore.VideoRec> vids = store.videosCopy();
        if (vids.isEmpty()) {
            toast(L.t("এই সার্ভেতে এখনও কোনো ভিডিও নেই। \"🎥 ভিডিও\" বোতাম দিয়ে তুলুন।", "No videos in this survey yet. Record one with the \"🎥 Video\" button."));
            return;
        }
        List<TrackStore.Pt> pts = store.pointsCopy();
        String[] items = new String[vids.size()];
        SimpleDateFormat df = new SimpleDateFormat("dd/MM HH:mm", Locale.US);
        for (int i = 0; i < vids.size(); i++) {
            TrackStore.VideoRec v = vids.get(i);
            double[] a = TrackStore.positionAt(pts, v.start), z = TrackStore.positionAt(pts, v.end);
            long sec = (v.end - v.start) / 1000;
            String range = a == null ? "" : "   Ch " + TrackStore.fmtCh(store.disp(a[2])) + " – " + TrackStore.fmtCh(store.disp(z[2]));
            items[i] = "🎬 " + df.format(new Date(v.start)) + String.format(Locale.US, "  (%d:%02d)", sec / 60, sec % 60) + range;
        }
        new AlertDialog.Builder(this)
                .setTitle(L.t("ভিডিও – ", "Videos – ") + store.name)
                .setItems(items, (d, which) -> PlayerActivity.open(this, vids.get(which), 0))
                .setNegativeButton(L.t("বন্ধ", "Close"), null)
                .show();
    }

    // ---------- Recording: start / pause / resume ----------

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startTracking() {
        if (!hasLocationPermission()) {
            List<String> perms = new ArrayList<>();
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION);
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS);
            requestPermissions(perms.toArray(new String[0]), REQ_LOCATION);
            return;
        }
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            new AlertDialog.Builder(this)
                    .setTitle(L.t("GPS বন্ধ আছে", "GPS is off"))
                    .setMessage(L.t("রাস্তা রেকর্ড করতে ফোনের লোকেশন (GPS) চালু করুন।", "Turn on the phone's location (GPS) to record the road."))
                    .setPositiveButton(L.t("চালু করুন", "Turn on"), (d, w) ->
                            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                    .show();
            return;
        }
        boolean resuming = !store.points.isEmpty();
        myLocation.enableMyLocation();
        firstFix = !resuming;
        Intent i = new Intent(this, TrackingService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        toast(resuming
                ? L.t("আবার রেকর্ড চালু হলো, চেইনেজ ", "Recording resumed from chainage ") + TrackStore.fmtCh(store.disp(store.length())) + L.t(" থেকে।", ".")
                : L.t("রেকর্ড শুরু হলো। GPS ঠিকমতো ধরতে কয়েক সেকেন্ড লাগতে পারে।", "Recording started. GPS may take a few seconds to lock."));
    }

    private void pauseTracking() {
        stopService(new Intent(this, TrackingService.class));
        toast(L.t("পজ হলো। \"আবার চালু\" চাপলে এই চেইনেজ থেকেই চলবে।", "Paused. Tap \"Resume\" to continue from this chainage."));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (hasLocationPermission()) myLocation.enableMyLocation();
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_LOCATION) {
            if (hasLocationPermission()) startTracking();
            else toast(L.t("লোকেশন অনুমতি ছাড়া রেকর্ড করা যাবে না।", "Recording is not possible without location permission."));
        } else if (requestCode == REQ_STORAGE_EXPORT) {
            if (granted && pendingExport >= 0) doExport(pendingExport);
            else toast(L.t("ফাইল সেভের অনুমতি পাওয়া যায়নি।", "Permission to save files was not given."));
            pendingExport = -1;
        } else if (requestCode == REQ_CAMERA_PERM) {
            if (granted && pendingPhotoIndex >= 0) takePhoto(pendingPhotoIndex);
            else toast(L.t("ক্যামেরার অনুমতি ছাড়া ছবি তোলা যাবে না।", "Photos need camera permission."));
        } else if (requestCode == REQ_STORAGE_PHOTO) {
            if (granted && pendingPhotoIndex >= 0) takePhoto(pendingPhotoIndex);
            else toast(L.t("ছবি সেভের অনুমতি পাওয়া যায়নি।", "Permission to save photos was not given."));
        }
    }

    // ---------- Surveys ----------

    private void surveyMenu() {
        final List<TrackStore.SurveyInfo> all = store.listSurveys();
        String[] items = new String[all.size() + 2];
        items[0] = L.t("➕  নতুন সার্ভে শুরু করুন", "➕  Start a new survey");
        items[all.size() + 1] = L.t("💾  ব্যাকআপ / রিস্টোর", "💾  Backup / restore");
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        for (int i = 0; i < all.size(); i++) {
            TrackStore.SurveyInfo s = all.get(i);
            items[i + 1] = (s.id.equals(store.id) ? "✔ " : "    ") + s.name + "\n      "
                    + TrackStore.fmtCh(s.startCh) + " – " + TrackStore.fmtCh(s.startCh + s.length)
                    + "   •   " + df.format(new Date(s.created));
        }
        new AlertDialog.Builder(this)
                .setTitle(L.t("সার্ভের তালিকা", "Surveys"))
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        if (store.tracking) toast(L.t("নতুন সার্ভের আগে বর্তমান রেকর্ড পজ করুন।", "Pause the current recording before a new survey."));
                        else surveyForm(null);
                    } else if (which == all.size() + 1) {
                        backupMenu();
                    } else {
                        surveyActions(all.get(which - 1));
                    }
                })
                .setNegativeButton(L.t("বন্ধ", "Close"), null)
                .show();
    }

    private void backupMenu() {
        String[] items = {L.t("💾  সব সার্ভের ব্যাকআপ নিন", "💾  Back up all surveys"),
                L.t("📂  ব্যাকআপ ফাইল থেকে ফেরত আনুন", "📂  Restore from a backup file")};
        new AlertDialog.Builder(this)
                .setTitle(L.t("ব্যাকআপ / রিস্টোর", "Backup / restore"))
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(
                                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE_EXPORT);
                            return;
                        }
                        try {
                            String fn = "RoadSurvey_backup_" + stamp() + ".zip";
                            Uri u = Exporter.save(this, fn, "application/zip", store.backupZip(Tags.list(this)));
                            AlertDialog.Builder b = new AlertDialog.Builder(this)
                                    .setTitle(L.t("ব্যাকআপ সম্পূর্ণ", "Backup complete"))
                                    .setMessage(L.t("ফোনের Download/", "Saved in the phone's Download/") + Exporter.FOLDER + "/" + fn
                                            + L.t("\n\nএই ফাইলটা Google Drive বা অন্য ফোনে রাখুন। দ্রষ্টব্য: ছবি আর ভিডিও এর মধ্যে নেই, সেগুলো গ্যালারি/Download ফোল্ডারে আছে।",
                                            "\n\nKeep this file on Google Drive or another phone. Note: photos and videos are not inside; they stay in the gallery / Download folder."))
                                    .setPositiveButton(L.t("ঠিক আছে", "OK"), null);
                            if (u != null) {
                                final ArrayList<Uri> one = new ArrayList<>();
                                one.add(u);
                                b.setNeutralButton(L.t("শেয়ার করুন", "Share"), (d2, w2) -> share(one));
                            }
                            b.show();
                        } catch (Exception e) {
                            toast(L.t("ব্যাকআপ হয়নি: ", "Backup failed: ") + e.getMessage());
                        }
                    } else {
                        if (store.tracking) {
                            toast(L.t("রিস্টোরের আগে রেকর্ড পজ করুন।", "Pause recording before restoring."));
                            return;
                        }
                        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        pick.addCategory(Intent.CATEGORY_OPENABLE);
                        pick.setType("*/*");
                        try {
                            startActivityForResult(pick, REQ_RESTORE);
                        } catch (Exception e) {
                            toast(String.valueOf(e.getMessage()));
                        }
                    }
                })
                .setNegativeButton(L.t("বন্ধ", "Close"), null)
                .show();
    }

    private void restoreFrom(Uri uri) {
        try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new java.io.IOException("no file");
            List<String> tags = new ArrayList<>();
            int n = store.restoreZip(in, tags);
            for (String t : tags) Tags.add(this, t);
            toast(n == 0 ? L.t("এই ফাইলে কোনো সার্ভে পাওয়া যায়নি। এটা কি রোড সার্ভের ব্যাকআপ ফাইল?",
                    "No surveys found in this file. Is it a Road Survey backup?")
                    : String.format(Locale.US, L.t("%dটা সার্ভে ফেরত আনা হলো। \"সার্ভে\" বোতামে দেখুন।",
                    "%d surveys restored. See the \"Surveys\" button."), n));
        } catch (Exception e) {
            toast(L.t("রিস্টোর হয়নি: ", "Restore failed: ") + e.getMessage());
        }
    }

    private void surveyActions(final TrackStore.SurveyInfo s) {
        boolean isCurrent = s.id.equals(store.id);
        String[] items = isCurrent
                ? new String[]{L.t("নাম / শুরুর চেইনেজ বদলান", "Change name / start chainage"), L.t("মুছে ফেলুন", "Delete"), L.t("✏ লাইন / পয়েন্ট সম্পাদনা (Undo, জিগজ্যাগ)", "✏ Edit line / points (undo, zig-zag)")}
                : new String[]{L.t("এই সার্ভে খুলুন", "Open this survey"), L.t("নাম / শুরুর চেইনেজ বদলান", "Change name / start chainage"), L.t("মুছে ফেলুন", "Delete")};
        new AlertDialog.Builder(this)
                .setTitle(s.name)
                .setItems(items, (d, which) -> {
                    int action = isCurrent ? which + 1 : which;
                    if (action == 0) {
                        if (store.tracking) {
                            toast(L.t("অন্য সার্ভে খোলার আগে বর্তমান রেকর্ড পজ করুন।", "Pause the current recording before opening another survey."));
                            return;
                        }
                        store.open(s.id);
                        afterSurveySwitch();
                    } else if (action == 1) {
                        surveyForm(s);
                    } else if (action == 3) {
                        cleanTrackDialog();
                    } else {
                        if (store.tracking && isCurrent) {
                            toast(L.t("রেকর্ড চলার সময় এই সার্ভে মোছা যাবে না।", "This survey can't be deleted while recording."));
                            return;
                        }
                        new AlertDialog.Builder(this)
                                .setTitle("\"" + s.name + L.t("\" মুছে ফেলবেন?", "\" — delete?"))
                                .setMessage(L.t("এই সার্ভের সব রেকর্ড মুছে যাবে (গ্যালারির ছবি থেকে যাবে)। আগে এক্সপোর্ট করে নিয়েছেন তো?", "All records of this survey will be deleted (gallery photos stay). Have you exported it?"))
                                .setPositiveButton(L.t("হ্যাঁ, মুছুন", "Yes, delete"), (d2, w2) -> {
                                    store.deleteSurvey(s.id);
                                    afterSurveySwitch();
                                })
                                .setNegativeButton(L.t("না", "No"), null)
                                .show();
                    }
                })
                .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                .show();
    }

    /** existing == null means "create a new survey". */
    private void surveyForm(final TrackStore.SurveyInfo existing) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        TextView l1 = new TextView(this);
        l1.setText(L.t("রাস্তার নাম", "Road name"));
        final EditText etName = new EditText(this);
        etName.setInputType(InputType.TYPE_CLASS_TEXT);
        etName.setHint(L.t("যেমন: রামপুর – শিবপুর রোড", "e.g. Rampur – Shibpur Road"));
        TextView l2 = new TextView(this);
        l2.setText(L.t("শুরুর চেইনেজ", "Start chainage"));
        l2.setPadding(0, dp(10), 0, 0);
        final EditText etCh = new EditText(this);
        etCh.setInputType(InputType.TYPE_CLASS_TEXT);
        etCh.setHint(L.t("যেমন 0+000 বা 5+200", "e.g. 0+000 or 5+200"));
        if (existing != null) {
            etName.setText(existing.name);
            etCh.setText(TrackStore.fmtCh(existing.startCh));
        } else {
            etName.setText(L.t("সার্ভে ", "Survey ") + (store.listSurveys().size() + 1));
            etCh.setText("0+000");
        }
        box.addView(l1);
        box.addView(etName);
        box.addView(l2);
        box.addView(etCh);
        new AlertDialog.Builder(this)
                .setTitle(existing == null ? L.t("নতুন সার্ভে", "New survey") : L.t("সার্ভে বদলান", "Edit survey"))
                .setView(box)
                .setPositiveButton(L.t("সেভ", "Save"), (d, w) -> {
                    String n = etName.getText().toString().trim();
                    if (n.isEmpty()) n = L.t("সার্ভে", "Surveys");
                    double ch = TrackStore.parseCh(etCh.getText().toString());
                    if (Double.isNaN(ch)) {
                        toast(L.t("চেইনেজ বোঝা যায়নি। এভাবে লিখুন: 5+200 বা 5200", "Chainage not understood. Write like: 5+200 or 5200"));
                        return;
                    }
                    if (existing == null) {
                        store.createSurvey(n, ch);
                        afterSurveySwitch();
                        toast(L.t("নতুন সার্ভে তৈরি হলো। \"রেকর্ড শুরু\" চাপুন।", "New survey created. Tap \"Start recording\"."));
                    } else {
                        store.updateSurvey(existing.id, n, ch);
                    }
                })
                .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                .show();
    }

    private void afterSurveySwitch() {
        firstFix = true;
        shownMarksKey = "";
        onTrackChanged();
        if (!store.points.isEmpty()) showWholeRoad();
    }

    // ---------- Marking points & photos ----------

    private double[] currentLocation() {
        if (store.hasFix) return new double[]{store.fixLat, store.fixLon, store.fixAlt};
        GeoPoint g = myLocation.getMyLocation();
        if (g != null) return new double[]{g.getLatitude(), g.getLongitude(), g.getAltitude()};
        if (hasLocationPermission()) {
            try {
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (l != null && System.currentTimeMillis() - l.getTime() < 60_000) {
                    return new double[]{l.getLatitude(), l.getLongitude(), l.getAltitude()};
                }
            } catch (SecurityException ignored) {
            }
        }
        return null;
    }

    private void markPoint() {
        final double[] loc = currentLocation();
        if (loc == null) {
            toast(L.t("এখনও GPS অবস্থান পাওয়া যায়নি। আগে রেকর্ড শুরু করে একটু অপেক্ষা করুন।", "No GPS position yet. Start recording and wait a moment."));
            return;
        }
        Tags.pick(this, tag -> saveMark(tag, loc));
    }

    private void saveMark(String name, double[] loc) {
        final int index = store.addMark(name, loc[0], loc[1], loc[2]);
        double ch = store.disp(store.marks.get(index).ch);
        if (!AppSettings.askPhoto(this)) {
            toast((index + 1) + ". " + name + L.t(" মার্ক হলো, চেইনেজ ", " marked, chainage ") + TrackStore.fmtCh(ch));
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle((index + 1) + ". " + name + L.t(" মার্ক হলো", " marked"))
                .setMessage(L.t("চেইনেজ ", "Chainage ") + TrackStore.fmtCh(ch) + L.t("\n\nএই জায়গার ছবি তুলবেন?", "\n\nTake a photo of this place?"))
                .setPositiveButton(L.t("📷 ছবি তুলুন", "📷 Take photo"), (d, w) -> takePhoto(index))
                .setNegativeButton(L.t("না", "No"), null)
                .show();
    }

    private void takePhoto(int index) {
        pendingPhotoIndex = index;
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE_PHOTO);
            return;
        }
        // The app declares the CAMERA permission (for video), so Android requires it to be granted
        // before another camera app may be opened – otherwise the app crashes.
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA_PERM);
            return;
        }
        Uri uri = Photos.newPhotoUri(this, safeName(store.name) + "_" + (index + 1) + "_" + stamp() + ".jpg");
        if (uri == null) {
            toast(L.t("ছবির জন্য জায়গা তৈরি করা যায়নি।", "Could not create space for the photo."));
            return;
        }
        pendingPhotoUri = uri;
        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cam.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(cam, REQ_CAMERA);
        } catch (ActivityNotFoundException | SecurityException e) {
            Photos.delete(this, uri);
            pendingPhotoUri = null;
            toast(L.t("ফোনে কোনো ক্যামেরা অ্যাপ পাওয়া যায়নি।", "No camera app found on the phone."));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_RESTORE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) restoreFrom(data.getData());
            return;
        }
        if (requestCode != REQ_CAMERA || pendingPhotoUri == null) return;
        if (resultCode == RESULT_OK) {
            TrackStore.Mark m = pendingPhotoIndex >= 0 && pendingPhotoIndex < store.marks.size()
                    ? store.marks.get(pendingPhotoIndex) : null;
            if (m != null && !m.photo.isEmpty()) {
                // replacing an older photo: keep the new one only
                Photos.delete(this, Uri.parse(m.photo));
            }
            final int idx = pendingPhotoIndex;
            final String uri = pendingPhotoUri.toString();
            store.setMarkPhoto(idx, uri);
            toast(L.t("ছবি সেভ হলো।", "Photo saved."));
            if (m != null && AppSettings.photoStamp(this)) {
                final String[] lines = Photos.stampLines(store.name, m.name,
                        TrackStore.fmtCh(store.disp(m.ch)), m.lat, m.lon, System.currentTimeMillis());
                final Context app = getApplicationContext();
                new Thread(() -> {
                    if (Photos.stampPhoto(app, uri, lines)) {
                        runOnUiThread(() -> {
                            shownMarksKey = "";
                            onTrackChanged();
                        });
                    }
                }).start();
            }
        } else {
            Photos.delete(this, pendingPhotoUri);
        }
        pendingPhotoUri = null;
        pendingPhotoIndex = -1;
    }

    private void showMarkDialog(final int index) {
        List<TrackStore.Mark> marks = store.marksCopy();
        if (index < 0 || index >= marks.size()) return;
        final TrackStore.Mark m = marks.get(index);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(8));
        TextView tv = new TextView(this);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        tv.setText(String.format(Locale.US, L.t("চেইনেজ: %s\nঅক্ষাংশ: %.6f\nদ্রাঘিমাংশ: %.6f\nউচ্চতা: %.1f মি\nসময়: %s", "Chainage: %s\nLatitude: %.6f\nLongitude: %.6f\nElevation: %.1f m\nTime: %s"),
                TrackStore.fmtCh(store.disp(m.ch)), m.lat, m.lon, m.alt, Exporter.local(m.time))
                + "\nUTM " + Geo.utm(m.lat, m.lon));
        box.addView(tv);
        if (!m.photo.isEmpty()) {
            Bitmap b = Photos.load(this, m.photo, 1000);
            if (b != null) {
                ImageView iv = new ImageView(this);
                iv.setImageBitmap(b);
                iv.setAdjustViewBounds(true);
                iv.setPadding(0, dp(10), 0, 0);
                iv.setOnClickListener(v -> {
                    try {
                        Intent view = new Intent(Intent.ACTION_VIEW);
                        view.setDataAndType(Uri.parse(m.photo), "image/*");
                        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(view);
                    } catch (Exception ignored) {
                    }
                });
                box.addView(iv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
            }
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(box);

        new AlertDialog.Builder(this)
                .setTitle((index + 1) + ". " + m.name)
                .setView(sv)
                .setPositiveButton(L.t("ঠিক আছে", "OK"), null)
                .setNeutralButton(m.photo.isEmpty() ? L.t("📷 ছবি তুলুন", "📷 Take photo") : L.t("📷 ছবি বদলান", "📷 Change photo"), (d, w) -> takePhoto(index))
                .setNegativeButton(L.t("মুছুন", "Delete"), (d, w) -> new AlertDialog.Builder(this)
                        .setTitle("\"" + m.name + L.t("\" মুছে ফেলবেন?", "\" — delete?"))
                        .setPositiveButton(L.t("হ্যাঁ", "Yes"), (d2, w2) -> store.deleteMark(index))
                        .setNegativeButton(L.t("না", "No"), null)
                        .show())
                .show();
    }

    // ---------- Elevation profile ----------

    private void showProfile() {
        List<TrackStore.Pt> pts = store.pointsCopy();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(8), dp(12), dp(4));
        Profile.ChartView chart = new Profile.ChartView(this, pts, store.startCh);
        box.addView(chart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(240)));
        TextView tv = new TextView(this);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv.setPadding(dp(4), dp(10), dp(4), 0);
        Profile.Stats s = Profile.stats(pts);
        if (s.valid) {
            tv.setText(String.format(Locale.US,
                    L.t("শুরু %.1f মি  →  শেষ %.1f মি\nসর্বনিম্ন %.1f মি  •  সর্বোচ্চ %.1f মি\n", "Start %.1f m  →  End %.1f m\nMin %.1f m  •  Max %.1f m\n")
                            + L.t("মোট চড়াই %.1f মি  •  উৎরাই %.1f মি\nগড় ঢাল %.2f%%  •  সবচেয়ে খাড়া %.1f%%\n\n", "Total climb %.1f m  •  descent %.1f m\nAverage grade %.2f%%  •  Steepest %.1f%%\n\n")
                            + L.t("ফোনের GPS-এর উচ্চতা আনুমানিক, কয়েক মিটার এদিক-ওদিক হতে পারে।", "Phone GPS elevation is approximate and may be off by a few metres."),
                    s.startAlt, s.endAlt, s.minAlt, s.maxAlt, s.rise, s.fall, s.avgGrade, s.maxGrade));
        } else {
            tv.setText(L.t("উচ্চতা দেখাতে আগে কিছুটা রাস্তা রেকর্ড করুন।", "Record some road first to see the elevation."));
        }
        box.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle(L.t("উচ্চতা প্রোফাইল – ", "Elevation profile – ") + store.name)
                .setView(box)
                .setPositiveButton(L.t("বন্ধ", "Close"), null)
                .show();
    }

    // ---------- Map menu ----------

    private void mapMenu() {
        String[] items = {
                satellite ? L.t("🗺  সাধারণ ম্যাপ দেখান", "🗺  Show normal map") : L.t("🛰  স্যাটেলাইট ম্যাপ দেখান", "🛰  Show satellite map"),
                L.t("📍  আমি কোথায়", "📍  Where am I"),
                L.t("↔  পুরো রাস্তা দেখান", "↔  Show whole road"),
                L.t("⬇  এই এলাকার ম্যাপ অফলাইনে রাখুন", "⬇  Keep this area's map offline"),
                L.t("🎬  এই সার্ভের ভিডিও", "🎬  Videos of this survey")};
        new AlertDialog.Builder(this)
                .setTitle(L.t("ম্যাপ", "Map"))
                .setItems(items, (d, which) -> {
                    if (which == 0) toggleMap();
                    else if (which == 1) locateMe();
                    else if (which == 2) showWholeRoad();
                    else if (which == 3) offlineDownload();
                    else videoList();
                })
                .setNegativeButton(L.t("বন্ধ", "Close"), null)
                .show();
    }

    private void toggleMap() {
        satellite = !satellite;
        map.setTileSource(satellite ? SATELLITE : TileSourceFactory.MAPNIK);
    }

    private void locateMe() {
        double[] loc = currentLocation();
        if (loc == null) {
            if (!hasLocationPermission()) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATE);
            } else {
                myLocation.enableMyLocation();
            }
            toast(L.t("অবস্থান খোঁজা হচ্ছে, একটু পরে আবার চাপুন।", "Finding location, tap again in a moment."));
            return;
        }
        if (map.getZoomLevelDouble() < 16) map.getController().setZoom(18.0);
        map.getController().animateTo(new GeoPoint(loc[0], loc[1]));
    }

    private void showWholeRoad() {
        List<TrackStore.Pt> pts = store.pointsCopy();
        if (pts.isEmpty()) {
            toast(L.t("এখনও কোনো রাস্তা রেকর্ড হয়নি।", "No road recorded yet."));
            return;
        }
        if (pts.size() == 1) {
            map.getController().setZoom(18.0);
            map.getController().setCenter(new GeoPoint(pts.get(0).lat, pts.get(0).lon));
            return;
        }
        double n = -90, s = 90, e = -180, w = 180;
        for (TrackStore.Pt p : pts) {
            n = Math.max(n, p.lat);
            s = Math.min(s, p.lat);
            e = Math.max(e, p.lon);
            w = Math.min(w, p.lon);
        }
        double padLat = Math.max((n - s) * 0.15, 0.0005), padLon = Math.max((e - w) * 0.15, 0.0005);
        final BoundingBox bb = new BoundingBox(n + padLat, e + padLon, s - padLat, w - padLon);
        map.post(() -> map.zoomToBoundingBox(bb, true, dp(40)));
    }

    /** Number of map tiles covering the box for zoom levels zMin..zMax. */
    private static long tileCount(BoundingBox bb, int zMin, int zMax) {
        long total = 0;
        for (int z = zMin; z <= zMax; z++) {
            int x1 = lonToTile(bb.getLonWest(), z), x2 = lonToTile(bb.getLonEast(), z);
            int y1 = latToTile(bb.getLatNorth(), z), y2 = latToTile(bb.getLatSouth(), z);
            total += (long) (Math.abs(x2 - x1) + 1) * (Math.abs(y2 - y1) + 1);
        }
        return total;
    }

    private static int lonToTile(double lon, int z) {
        return (int) Math.floor((lon + 180) / 360 * (1 << z));
    }

    private static int latToTile(double lat, int z) {
        double r = Math.toRadians(lat);
        return (int) Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * (1 << z));
    }

    private void offlineDownload() {
        if (!satellite) {
            new AlertDialog.Builder(this)
                    .setTitle(L.t("অফলাইন ম্যাপ", "Offline map"))
                    .setMessage(L.t("সাধারণ (OpenStreetMap) ম্যাপ একসাথে অনেকটা নামানো তাদের নিয়মে নিষেধ। ", "OpenStreetMap's rules don't allow bulk downloading of the normal map. ")
                            + L.t("তবে যে এলাকা একবার দেখেছেন, সেটা ফোনে নিজে থেকেই সেভ থাকে।\n\n", "But any area you have viewed is saved on the phone automatically.\n\n")
                            + L.t("পুরো এলাকা একসাথে নামাতে আগে স্যাটেলাইট ম্যাপে যান, তারপর আবার এটা চাপুন।", "To download a whole area, switch to the satellite map first, then tap this again."))
                    .setPositiveButton(L.t("স্যাটেলাইটে যান", "Go to satellite"), (d, w) -> toggleMap())
                    .setNegativeButton(L.t("বন্ধ", "Close"), null)
                    .show();
            return;
        }
        final int zMin = (int) Math.floor(map.getZoomLevelDouble());
        if (zMin < 12) {
            toast(L.t("আরও কাছে জুম করুন, যাতে শুধু কাজের এলাকাটুকু স্ক্রিনে থাকে।", "Zoom in closer so only the work area is on screen."));
            return;
        }
        final BoundingBox bb = map.getBoundingBox();
        int zMax = Math.min(zMin + 4, 19);
        while (zMax > zMin && tileCount(bb, zMin, zMax) > 8000) zMax--;
        final int fzMax = zMax;
        long tiles = tileCount(bb, zMin, fzMax);
        double mb = tiles * 0.02; // roughly 20 KB per satellite tile
        new AlertDialog.Builder(this)
                .setTitle(L.t("এই এলাকার ম্যাপ নামাবেন?", "Download this area's map?"))
                .setMessage(String.format(Locale.US,
                        L.t("স্ক্রিনে যতটুকু দেখা যাচ্ছে, সেই এলাকা জুম %d থেকে %d পর্যন্ত নামানো হবে।\n\n", "The area on screen will be downloaded from zoom %d to %d.\n\n")
                                + L.t("প্রায় %d টাইল, আনুমানিক %.0f MB। ওয়াই-ফাই ব্যবহার করা ভালো।", "About %d tiles, roughly %.0f MB. Wi-Fi is recommended."),
                        zMin, fzMax, tiles, mb))
                .setPositiveButton(L.t("নামান", "Download"), (d, w) -> {
                    try {
                        CacheManager cm = new CacheManager(map);
                        cm.downloadAreaAsync(this, bb, zMin, fzMax);
                    } catch (Exception e) {
                        toast(L.t("ম্যাপ নামানো গেল না: ", "Could not download the map: ") + e.getMessage());
                    }
                })
                .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                .show();
    }

    // ---------- Export ----------

    private void chooseExport() {
        if (store.points.isEmpty() && store.marks.isEmpty()) {
            toast(L.t("এক্সপোর্ট করার মতো কোনো ডেটা নেই।", "No data to export."));
            return;
        }
        String[] items = {L.t("KMZ (Google Earth, ছবিসহ)", "KMZ (Google Earth, with photos)"), "KML (Google Earth)", "CSV (Excel)", "GPX",
                L.t("PDF রিপোর্ট", "PDF report"), L.t("📊 চেইনেজ টেবিল (Excel, UTM সহ)", "📊 Chainage table (Excel, with UTM)"),
                L.t("সবগুলো", "All")};
        new AlertDialog.Builder(this)
                .setTitle("\"" + store.name + L.t("\" এক্সপোর্ট", "\" export"))
                .setItems(items, (d, which) -> {
                    if (which >= 5) {
                        final int[] steps = {10, 20, 25, 50, 100};
                        String[] labels = new String[steps.length];
                        for (int i = 0; i < steps.length; i++) labels[i] = steps[i] + L.t(" মি পরপর", " m interval");
                        new AlertDialog.Builder(this)
                                .setTitle(L.t("চেইনেজ টেবিলের ব্যবধান", "Chainage table interval"))
                                .setItems(labels, (d2, w2) -> {
                                    tableStep = steps[w2];
                                    exportWithPermission(which);
                                })
                                .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                                .show();
                    } else {
                        exportWithPermission(which);
                    }
                })
                .setNegativeButton(L.t("বাতিল", "Cancel"), null)
                .show();
    }

    private double tableStep = 50;

    private void exportWithPermission(int which) {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingExport = which;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE_EXPORT);
        } else {
            doExport(which);
        }
    }

    private void doExport(final int which) {
        final List<TrackStore.Pt> pts = store.pointsCopy();
        final List<TrackStore.Mark> marks = store.marksCopy();
        final String name = store.name;
        final double startCh = store.startCh;
        final String base = safeName(name) + "_" + stamp();
        final double step = tableStep;
        final Context app = getApplicationContext();

        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage(L.t("ফাইল তৈরি হচ্ছে…", "Creating files…"));
        pd.setCancelable(false);
        pd.show();

        new Thread(() -> {
            final ArrayList<Uri> uris = new ArrayList<>();
            final List<String> names = new ArrayList<>();
            String error = null;
            try {
                // For KML / CSV / GPX: show the photo's gallery file name instead of an internal number
                List<TrackStore.Mark> named = new ArrayList<>();
                for (TrackStore.Mark m : marks) {
                    TrackStore.Mark c = new TrackStore.Mark();
                    c.name = m.name;
                    c.lat = m.lat;
                    c.lon = m.lon;
                    c.alt = m.alt;
                    c.ch = m.ch;
                    c.time = m.time;
                    String dn = Photos.displayName(app, m.photo);
                    c.photo = m.photo.isEmpty() ? "" : (dn.isEmpty() ? m.photo : dn);
                    named.add(c);
                }
                boolean all = which == 6;
                if (which == 0 || all) {
                    addUri(uris, Exporter.save(app, base + ".kmz", "application/octet-stream",
                            Exporter.kmz(app, pts, marks, name, startCh)));
                    names.add(base + ".kmz");
                }
                if (which == 1 || all) {
                    addUri(uris, Exporter.save(app, base + ".kml", "application/octet-stream",
                            Exporter.kml(pts, named, name, startCh)));
                    names.add(base + ".kml");
                }
                if (which == 2 || all) {
                    addUri(uris, Exporter.save(app, base + ".csv", "text/csv",
                            Exporter.csv(pts, named, startCh)));
                    names.add(base + ".csv");
                }
                if (which == 3 || all) {
                    addUri(uris, Exporter.save(app, base + ".gpx", "application/octet-stream",
                            Exporter.gpx(pts, marks, name, startCh)));
                    names.add(base + ".gpx");
                }
                if (which == 5 || all) {
                    byte[] xl = Exporter.chainageXlsx(app, pts, marks, name, startCh, step);
                    addUri(uris, Exporter.save(app, base + "_chainage.xlsx",
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", xl));
                    names.add(base + "_chainage.xlsx");
                }
                if (which == 4 || all) {
                    byte[] pdf = Report.build(app, name, startCh, pts, marks);
                    addUri(uris, Exporter.save(app, base + ".pdf", "application/pdf", pdf));
                    names.add(base + ".pdf");
                }
            } catch (Throwable t) {
                error = String.valueOf(t.getMessage());
            }
            final String err = error;
            runOnUiThread(() -> {
                try {
                    pd.dismiss();
                } catch (Exception ignored) {
                }
                if (isFinishing()) return;
                if (err != null) {
                    new AlertDialog.Builder(this)
                            .setTitle(L.t("এক্সপোর্ট হয়নি", "Export failed"))
                            .setMessage(err)
                            .setPositiveButton(L.t("ঠিক আছে", "OK"), null)
                            .show();
                    return;
                }
                StringBuilder msg = new StringBuilder(L.t("ফোনের Download/", "Saved in the phone's Download/") + Exporter.FOLDER + L.t(" ফোল্ডারে সেভ হয়েছে:\n\n", " folder:\n\n"));
                for (String n : names) msg.append("• ").append(n).append('\n');
                AlertDialog.Builder b = new AlertDialog.Builder(this)
                        .setTitle(L.t("এক্সপোর্ট সম্পূর্ণ", "Export complete"))
                        .setMessage(msg.toString())
                        .setPositiveButton(L.t("ঠিক আছে", "OK"), null);
                if (!uris.isEmpty()) b.setNeutralButton(L.t("শেয়ার করুন", "Share"), (d, w) -> share(uris));
                b.show();
            });
        }).start();
    }

    private static void addUri(List<Uri> list, Uri u) {
        if (u != null) list.add(u);
    }

    private void share(ArrayList<Uri> uris) {
        Intent send;
        if (uris.size() == 1) {
            send = new Intent(Intent.ACTION_SEND);
            send.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            send = new Intent(Intent.ACTION_SEND_MULTIPLE);
            send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        send.setType("*/*");
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, L.t("শেয়ার করুন", "Share")));
    }
}
