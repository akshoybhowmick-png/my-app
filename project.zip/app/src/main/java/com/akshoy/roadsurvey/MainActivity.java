package com.akshoy.roadsurvey;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.cachemanager.CacheManager;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.MapTileIndex;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements TrackStore.Listener {

    private static final int REQ_LOCATION = 1;
    private static final int REQ_STORAGE_EXPORT = 2;
    private static final int REQ_STORAGE_PHOTO = 3;
    private static final int REQ_LOCATE = 4;
    private static final int REQ_CAMERA = 10;

    private static final ITileSource SATELLITE = new XYTileSource("EsriWorldImagery", 0, 19, 256, ".jpg",
            new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"}) {
        @Override
        public String getTileURLString(long index) {
            return getBaseUrl() + MapTileIndex.getZoom(index) + "/"
                    + MapTileIndex.getY(index) + "/" + MapTileIndex.getX(index);
        }
    };

    private TrackStore store;
    private MapView map;
    private Polyline line;
    private ChainageOverlay chainageOverlay;
    private MyLocationNewOverlay myLocation;
    private final List<Marker> markerOverlays = new ArrayList<>();
    private String shownMarksKey = "";
    private boolean satellite = false;
    private boolean firstFix = true;

    private int pendingExport = -1;
    private int pendingPhotoIndex = -1;
    private Uri pendingPhotoUri;

    private TextView tvSurvey, tvChainage, tvInfo;
    private Button btnStart;

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", Context.MODE_PRIVATE));
        Configuration.getInstance().setUserAgentValue(getPackageName());
        File osmBase = new File(getFilesDir(), "osmdroid");
        Configuration.getInstance().setOsmdroidBasePath(osmBase);
        Configuration.getInstance().setOsmdroidTileCache(new File(osmBase, "tiles"));
        Configuration.getInstance().setTileFileSystemCacheMaxBytes(1500L * 1024 * 1024);
        Configuration.getInstance().setTileFileSystemCacheTrimBytes(1200L * 1024 * 1024);
        store = TrackStore.get(this);

        if (savedInstanceState != null) {
            pendingPhotoIndex = savedInstanceState.getInt("photoIndex", -1);
            String u = savedInstanceState.getString("photoUri");
            if (u != null) pendingPhotoUri = Uri.parse(u);
        }

        FrameLayout root = new FrameLayout(this);

        map = new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.getController().setZoom(8.0);
        map.getController().setCenter(new GeoPoint(23.0, 87.9));
        root.addView(map, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        line = new Polyline();
        line.getOutlinePaint().setColor(Color.rgb(229, 57, 53));
        line.getOutlinePaint().setStrokeWidth(dp(4));
        map.getOverlays().add(line);

        chainageOverlay = new ChainageOverlay(getResources().getDisplayMetrics().density);
        map.getOverlays().add(chainageOverlay);

        myLocation = new MyLocationNewOverlay(new GpsMyLocationProvider(this), map);
        map.getOverlays().add(myLocation);

        // ----- Top info card -----
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(14), dp(8), dp(14), dp(10));
        top.setBackground(card());
        tvSurvey = new TextView(this);
        tvSurvey.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvSurvey.setTextColor(Color.rgb(90, 90, 90));
        tvChainage = new TextView(this);
        tvChainage.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        tvChainage.setTypeface(Typeface.DEFAULT_BOLD);
        tvChainage.setTextColor(Color.rgb(21, 101, 192));
        tvInfo = new TextView(this);
        tvInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        top.addView(tvSurvey);
        top.addView(tvChainage);
        top.addView(tvInfo);
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        topLp.setMargins(dp(10), dp(30), dp(10), 0);
        root.addView(top, topLp);

        // ----- Bottom buttons -----
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(8), dp(8), dp(8), dp(8));
        bottom.setBackground(card());

        LinearLayout row1 = new LinearLayout(this);
        btnStart = button("▶ রেকর্ড শুরু", Color.rgb(46, 125, 50));
        Button btnMark = button("📍 মার্ক", Color.rgb(239, 108, 0));
        Button btnVideo = button("🎥 ভিডিও", Color.rgb(106, 27, 154));
        row1.addView(btnStart, weight());
        row1.addView(btnMark, weight());
        row1.addView(btnVideo, weight());

        LinearLayout row2 = new LinearLayout(this);
        int grey = Color.rgb(69, 90, 100);
        Button btnSurveys = button("সার্ভে", grey);
        Button btnExport = button("এক্সপোর্ট", Color.rgb(21, 101, 192));
        Button btnProfile = button("উচ্চতা", grey);
        Button btnMapMenu = button("ম্যাপ", grey);
        Button btnSettings = button("⚙", grey);
        row2.addView(btnSurveys, weight());
        row2.addView(btnExport, weight());
        row2.addView(btnProfile, weight());
        row2.addView(btnMapMenu, weight());
        LinearLayout.LayoutParams gearLp = new LinearLayout.LayoutParams(dp(50), dp(50));
        gearLp.setMargins(dp(3), dp(3), dp(3), dp(3));
        row2.addView(btnSettings, gearLp);

        TextView dev = new TextView(this);
        dev.setText(AppSettings.DEVELOPER);
        dev.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        dev.setTextColor(Color.rgb(21, 101, 192));
        dev.setGravity(Gravity.CENTER);
        dev.setPadding(0, dp(2), 0, 0);
        dev.setOnClickListener(v -> AppSettings.about(this));

        bottom.addView(row1);
        bottom.addView(row2);
        bottom.addView(dev);
        FrameLayout.LayoutParams botLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        botLp.setMargins(dp(10), 0, dp(10), dp(20));
        root.addView(bottom, botLp);

        setContentView(root);

        btnStart.setOnClickListener(v -> {
            if (store.tracking) pauseTracking();
            else startTracking();
        });
        btnMark.setOnClickListener(v -> markPoint());
        btnSurveys.setOnClickListener(v -> surveyMenu());
        btnExport.setOnClickListener(v -> chooseExport());
        btnProfile.setOnClickListener(v -> showProfile());
        btnMapMenu.setOnClickListener(v -> mapMenu());
        btnVideo.setOnClickListener(v -> startActivity(new Intent(this, VideoActivity.class)));
        btnSettings.setOnClickListener(v -> AppSettings.show(this, () -> {
            shownMarksKey = "";
            onTrackChanged();
        }));

        line.setOnClickListener((poly, mapView, eventPos) -> {
            roadTapped(eventPos);
            return true;
        });
        if (AppSettings.satelliteDefault(this)) toggleMap();

        if (hasLocationPermission()) myLocation.enableMyLocation();

        TrackStore.Pt last = store.lastPoint();
        if (last != null) {
            map.getController().setZoom(17.0);
            map.getController().setCenter(new GeoPoint(last.lat, last.lon));
            firstFix = false;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("photoIndex", pendingPhotoIndex);
        if (pendingPhotoUri != null) out.putString("photoUri", pendingPhotoUri.toString());
    }

    // ---------- small UI helpers ----------

    private GradientDrawable card() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(235, 255, 255, 255));
        g.setCornerRadius(dp(14));
        return g;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        b.setPadding(dp(4), dp(6), dp(4), dp(6));
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        return lp;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private static String safeName(String s) {
        String t = s.trim().replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
        return t.isEmpty() ? "survey" : t;
    }

    private static String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    // ---------- Lifecycle ----------

    @Override
    protected void onResume() {
        super.onResume();
        map.onResume();
        store.addListener(this);
        onTrackChanged();
    }

    @Override
    protected void onPause() {
        store.removeListener(this);
        map.onPause();
        super.onPause();
    }

    @Override
    public void onTrackChanged() {
        List<TrackStore.Pt> pts = store.pointsCopy();
        List<GeoPoint> geo = new ArrayList<>(pts.size());
        for (TrackStore.Pt p : pts) geo.add(new GeoPoint(p.lat, p.lon));
        line.setPoints(geo);
        chainageOverlay.setTrack(pts, store.startCh, AppSettings.tickStep(this));

        List<TrackStore.Mark> marks = store.marksCopy();
        StringBuilder key = new StringBuilder(store.id).append('|').append(store.startCh);
        for (TrackStore.Mark m : marks) key.append('|').append(m.time).append(m.photo.isEmpty() ? '-' : '+');
        if (!key.toString().equals(shownMarksKey)) {
            map.getOverlays().removeAll(markerOverlays);
            markerOverlays.clear();
            for (int i = 0; i < marks.size(); i++) {
                TrackStore.Mark m = marks.get(i);
                Marker mk = new Marker(map);
                mk.setPosition(new GeoPoint(m.lat, m.lon));
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
                mk.setTitle((i + 1) + ". " + m.name);
                final int index = i;
                mk.setOnMarkerClickListener((marker, mapView) -> {
                    showMarkDialog(index);
                    return true;
                });
                markerOverlays.add(mk);
            }
            map.getOverlays().addAll(markerOverlays);
            shownMarksKey = key.toString();
        }

        double raw = pts.isEmpty() ? 0 : pts.get(pts.size() - 1).ch;
        tvSurvey.setText("📋 " + store.name + "   (শুরু " + TrackStore.fmtCh(store.startCh) + ")");
        tvChainage.setText("চেইনেজ  " + TrackStore.fmtCh(store.disp(raw)));
        String acc = store.lastAcc < 0 ? "—" : String.format(Locale.US, "±%.0f মি", store.lastAcc);
        String status = store.tracking ? "● রেকর্ড চলছে" : (pts.isEmpty() ? "■ শুরু হয়নি" : "⏸ পজ করা আছে");
        tvInfo.setText(String.format(Locale.US, "%s  |  দূরত্ব %.1f মি  |  মার্ক %d\nGPS নির্ভুলতা %s  |  পয়েন্ট %d",
                status, raw, marks.size(), acc, pts.size()));
        tvInfo.setTextColor(store.tracking ? Color.rgb(46, 125, 50) : Color.DKGRAY);

        if (store.tracking) btnStart.setText("⏸ পজ");
        else btnStart.setText(pts.isEmpty() ? "▶ রেকর্ড শুরু" : "▶ আবার চালু");
        ((GradientDrawable) btnStart.getBackground()).setColor(
                store.tracking ? Color.rgb(198, 40, 40) : Color.rgb(46, 125, 50));

        if (!pts.isEmpty()) {
            TrackStore.Pt last = pts.get(pts.size() - 1);
            GeoPoint gp = new GeoPoint(last.lat, last.lon);
            if (store.tracking && firstFix) {
                map.getController().setZoom(18.0);
                map.getController().setCenter(gp);
                firstFix = false;
            } else if (store.tracking && !map.getBoundingBox().contains(gp)) {
                map.getController().animateTo(gp);
            }
        }
        if (store.tracking && AppSettings.keepScreenOn(this)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        map.invalidate();
    }

    // ---------- Tapping the road: chainage + video at that spot ----------

    private void roadTapped(GeoPoint at) {
        int idx = store.nearestIndex(at.getLatitude(), at.getLongitude());
        if (idx < 0) return;
        final TrackStore.Pt p = store.points.get(idx);
        final TrackStore.VideoRec v = store.videoAt(p.time);
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("চেইনেজ " + TrackStore.fmtCh(store.disp(p.ch)))
                .setMessage(String.format(Locale.US, "অক্ষাংশ: %.6f\nদ্রাঘিমাংশ: %.6f\nউচ্চতা: %.1f মি\nসময়: %s%s",
                        p.lat, p.lon, p.alt, Exporter.local(p.time),
                        v == null ? "\n\nএই জায়গার কোনো ভিডিও নেই।" : "\n\nএই জায়গার ভিডিও আছে।"))
                .setPositiveButton("ঠিক আছে", null);
        if (v != null) {
            b.setNeutralButton("▶ এখান থেকে ভিডিও", (d, w) -> PlayerActivity.open(this, v, p.time - v.start - 2000));
        }
        b.show();
    }

    private void videoList() {
        final List<TrackStore.VideoRec> vids = store.videosCopy();
        if (vids.isEmpty()) {
            toast("এই সার্ভেতে এখনও কোনো ভিডিও নেই। \"🎥 ভিডিও\" বোতাম দিয়ে তুলুন।");
            return;
        }
        List<TrackStore.Pt> pts = store.pointsCopy();
        String[] items = new String[vids.size()];
        SimpleDateFormat df = new SimpleDateFormat("dd/MM HH:mm", Locale.US);
        for (int i = 0; i < vids.size(); i++) {
            TrackStore.VideoRec v = vids.get(i);
            double[] a = TrackStore.positionAt(pts, v.start), z = TrackStore.positionAt(pts, v.end);
            long sec = (v.end - v.start) / 1000;
            String range = a == null ? "" : "   Ch " + TrackStore.fmtCh(store.disp(a[2])) + " – " + TrackStore.fmtCh(store.disp(z[2]));
            items[i] = "🎬 " + df.format(new Date(v.start)) + String.format(Locale.US, "  (%d:%02d)", sec / 60, sec % 60) + range;
        }
        new AlertDialog.Builder(this)
                .setTitle("ভিডিও – " + store.name)
                .setItems(items, (d, which) -> PlayerActivity.open(this, vids.get(which), 0))
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    // ---------- Recording: start / pause / resume ----------

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startTracking() {
        if (!hasLocationPermission()) {
            List<String> perms = new ArrayList<>();
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION);
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION);
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS);
            requestPermissions(perms.toArray(new String[0]), REQ_LOCATION);
            return;
        }
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            new AlertDialog.Builder(this)
                    .setTitle("GPS বন্ধ আছে")
                    .setMessage("রাস্তা রেকর্ড করতে ফোনের লোকেশন (GPS) চালু করুন।")
                    .setPositiveButton("চালু করুন", (d, w) ->
                            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton("বাতিল", null)
                    .show();
            return;
        }
        boolean resuming = !store.points.isEmpty();
        myLocation.enableMyLocation();
        firstFix = !resuming;
        Intent i = new Intent(this, TrackingService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        toast(resuming
                ? "আবার রেকর্ড চালু হলো, চেইনেজ " + TrackStore.fmtCh(store.disp(store.length())) + " থেকে।"
                : "রেকর্ড শুরু হলো। GPS ঠিকমতো ধরতে কয়েক সেকেন্ড লাগতে পারে।");
    }

    private void pauseTracking() {
        stopService(new Intent(this, TrackingService.class));
        toast("পজ হলো। \"আবার চালু\" চাপলে এই চেইনেজ থেকেই চলবে।");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (hasLocationPermission()) myLocation.enableMyLocation();
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_LOCATION) {
            if (hasLocationPermission()) startTracking();
            else toast("লোকেশন অনুমতি ছাড়া রেকর্ড করা যাবে না।");
        } else if (requestCode == REQ_STORAGE_EXPORT) {
            if (granted && pendingExport >= 0) doExport(pendingExport);
            else toast("ফাইল সেভের অনুমতি পাওয়া যায়নি।");
            pendingExport = -1;
        } else if (requestCode == REQ_STORAGE_PHOTO) {
            if (granted && pendingPhotoIndex >= 0) takePhoto(pendingPhotoIndex);
            else toast("ছবি সেভের অনুমতি পাওয়া যায়নি।");
        }
    }

    // ---------- Surveys ----------

    private void surveyMenu() {
        final List<TrackStore.SurveyInfo> all = store.listSurveys();
        String[] items = new String[all.size() + 1];
        items[0] = "➕  নতুন সার্ভে শুরু করুন";
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        for (int i = 0; i < all.size(); i++) {
            TrackStore.SurveyInfo s = all.get(i);
            items[i + 1] = (s.id.equals(store.id) ? "✔ " : "    ") + s.name + "\n      "
                    + TrackStore.fmtCh(s.startCh) + " – " + TrackStore.fmtCh(s.startCh + s.length)
                    + "   •   " + df.format(new Date(s.created));
        }
        new AlertDialog.Builder(this)
                .setTitle("সার্ভের তালিকা")
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        if (store.tracking) toast("নতুন সার্ভের আগে বর্তমান রেকর্ড পজ করুন।");
                        else surveyForm(null);
                    } else {
                        surveyActions(all.get(which - 1));
                    }
                })
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    private void surveyActions(final TrackStore.SurveyInfo s) {
        boolean isCurrent = s.id.equals(store.id);
        String[] items = isCurrent
                ? new String[]{"নাম / শুরুর চেইনেজ বদলান", "মুছে ফেলুন"}
                : new String[]{"এই সার্ভে খুলুন", "নাম / শুরুর চেইনেজ বদলান", "মুছে ফেলুন"};
        new AlertDialog.Builder(this)
                .setTitle(s.name)
                .setItems(items, (d, which) -> {
                    int action = isCurrent ? which + 1 : which;
                    if (action == 0) {
                        if (store.tracking) {
                            toast("অন্য সার্ভে খোলার আগে বর্তমান রেকর্ড পজ করুন।");
                            return;
                        }
                        store.open(s.id);
                        afterSurveySwitch();
                    } else if (action == 1) {
                        surveyForm(s);
                    } else {
                        if (store.tracking && isCurrent) {
                            toast("রেকর্ড চলার সময় এই সার্ভে মোছা যাবে না।");
                            return;
                        }
                        new AlertDialog.Builder(this)
                                .setTitle("\"" + s.name + "\" মুছে ফেলবেন?")
                                .setMessage("এই সার্ভের সব রেকর্ড মুছে যাবে (গ্যালারির ছবি থেকে যাবে)। আগে এক্সপোর্ট করে নিয়েছেন তো?")
                                .setPositiveButton("হ্যাঁ, মুছুন", (d2, w2) -> {
                                    store.deleteSurvey(s.id);
                                    afterSurveySwitch();
                                })
                                .setNegativeButton("না", null)
                                .show();
                    }
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    /** existing == null means "create a new survey". */
    private void surveyForm(final TrackStore.SurveyInfo existing) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        TextView l1 = new TextView(this);
        l1.setText("রাস্তার নাম");
        final EditText etName = new EditText(this);
        etName.setInputType(InputType.TYPE_CLASS_TEXT);
        etName.setHint("যেমন: রামপুর – শিবপুর রোড");
        TextView l2 = new TextView(this);
        l2.setText("শুরুর চেইনেজ");
        l2.setPadding(0, dp(10), 0, 0);
        final EditText etCh = new EditText(this);
        etCh.setInputType(InputType.TYPE_CLASS_TEXT);
        etCh.setHint("যেমন 0+000 বা 5+200");
        if (existing != null) {
            etName.setText(existing.name);
            etCh.setText(TrackStore.fmtCh(existing.startCh));
        } else {
            etName.setText("সার্ভে " + (store.listSurveys().size() + 1));
            etCh.setText("0+000");
        }
        box.addView(l1);
        box.addView(etName);
        box.addView(l2);
        box.addView(etCh);
        new AlertDialog.Builder(this)
                .setTitle(existing == null ? "নতুন সার্ভে" : "সার্ভে বদলান")
                .setView(box)
                .setPositiveButton("সেভ", (d, w) -> {
                    String n = etName.getText().toString().trim();
                    if (n.isEmpty()) n = "সার্ভে";
                    double ch = TrackStore.parseCh(etCh.getText().toString());
                    if (Double.isNaN(ch)) {
                        toast("চেইনেজ বোঝা যায়নি। এভাবে লিখুন: 5+200 বা 5200");
                        return;
                    }
                    if (existing == null) {
                        store.createSurvey(n, ch);
                        afterSurveySwitch();
                        toast("নতুন সার্ভে তৈরি হলো। \"রেকর্ড শুরু\" চাপুন।");
                    } else {
                        store.updateSurvey(existing.id, n, ch);
                    }
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void afterSurveySwitch() {
        firstFix = true;
        shownMarksKey = "";
        onTrackChanged();
        if (!store.points.isEmpty()) showWholeRoad();
    }

    // ---------- Marking points & photos ----------

    private double[] currentLocation() {
        if (store.hasFix) return new double[]{store.fixLat, store.fixLon, store.fixAlt};
        GeoPoint g = myLocation.getMyLocation();
        if (g != null) return new double[]{g.getLatitude(), g.getLongitude(), g.getAltitude()};
        if (hasLocationPermission()) {
            try {
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (l != null && System.currentTimeMillis() - l.getTime() < 60_000) {
                    return new double[]{l.getLatitude(), l.getLongitude(), l.getAltitude()};
                }
            } catch (SecurityException ignored) {
            }
        }
        return null;
    }

    private void markPoint() {
        final double[] loc = currentLocation();
        if (loc == null) {
            toast("এখনও GPS অবস্থান পাওয়া যায়নি। আগে রেকর্ড শুরু করে একটু অপেক্ষা করুন।");
            return;
        }
        Tags.pick(this, tag -> saveMark(tag, loc));
    }

    private void saveMark(String name, double[] loc) {
        final int index = store.addMark(name, loc[0], loc[1], loc[2]);
        double ch = store.disp(store.marks.get(index).ch);
        if (!AppSettings.askPhoto(this)) {
            toast((index + 1) + ". " + name + " মার্ক হলো, চেইনেজ " + TrackStore.fmtCh(ch));
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle((index + 1) + ". " + name + " মার্ক হলো")
                .setMessage("চেইনেজ " + TrackStore.fmtCh(ch) + "\n\nএই জায়গার ছবি তুলবেন?")
                .setPositiveButton("📷 ছবি তুলুন", (d, w) -> takePhoto(index))
                .setNegativeButton("না", null)
                .show();
    }

    private void takePhoto(int index) {
        pendingPhotoIndex = index;
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE_PHOTO);
            return;
        }
        Uri uri = Photos.newPhotoUri(this, safeName(store.name) + "_" + (index + 1) + "_" + stamp() + ".jpg");
        if (uri == null) {
            toast("ছবির জন্য জায়গা তৈরি করা যায়নি।");
            return;
        }
        pendingPhotoUri = uri;
        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cam.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(cam, REQ_CAMERA);
        } catch (ActivityNotFoundException e) {
            Photos.delete(this, uri);
            pendingPhotoUri = null;
            toast("ফোনে কোনো ক্যামেরা অ্যাপ পাওয়া যায়নি।");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAMERA || pendingPhotoUri == null) return;
        if (resultCode == RESULT_OK) {
            TrackStore.Mark m = pendingPhotoIndex >= 0 && pendingPhotoIndex < store.marks.size()
                    ? store.marks.get(pendingPhotoIndex) : null;
            if (m != null && !m.photo.isEmpty()) {
                // replacing an older photo: keep the new one only
                Photos.delete(this, Uri.parse(m.photo));
            }
            store.setMarkPhoto(pendingPhotoIndex, pendingPhotoUri.toString());
            toast("ছবি সেভ হলো।");
        } else {
            Photos.delete(this, pendingPhotoUri);
        }
        pendingPhotoUri = null;
        pendingPhotoIndex = -1;
    }

    private void showMarkDialog(final int index) {
        List<TrackStore.Mark> marks = store.marksCopy();
        if (index < 0 || index >= marks.size()) return;
        final TrackStore.Mark m = marks.get(index);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(8));
        TextView tv = new TextView(this);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        tv.setText(String.format(Locale.US, "চেইনেজ: %s\nঅক্ষাংশ: %.6f\nদ্রাঘিমাংশ: %.6f\nউচ্চতা: %.1f মি\nসময়: %s",
                TrackStore.fmtCh(store.disp(m.ch)), m.lat, m.lon, m.alt, Exporter.local(m.time)));
        box.addView(tv);
        if (!m.photo.isEmpty()) {
            Bitmap b = Photos.load(this, m.photo, 1000);
            if (b != null) {
                ImageView iv = new ImageView(this);
                iv.setImageBitmap(b);
                iv.setAdjustViewBounds(true);
                iv.setPadding(0, dp(10), 0, 0);
                iv.setOnClickListener(v -> {
                    try {
                        Intent view = new Intent(Intent.ACTION_VIEW);
                        view.setDataAndType(Uri.parse(m.photo), "image/*");
                        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(view);
                    } catch (Exception ignored) {
                    }
                });
                box.addView(iv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
            }
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(box);

        new AlertDialog.Builder(this)
                .setTitle((index + 1) + ". " + m.name)
                .setView(sv)
                .setPositiveButton("ঠিক আছে", null)
                .setNeutralButton(m.photo.isEmpty() ? "📷 ছবি তুলুন" : "📷 ছবি বদলান", (d, w) -> takePhoto(index))
                .setNegativeButton("মুছুন", (d, w) -> new AlertDialog.Builder(this)
                        .setTitle("\"" + m.name + "\" মুছে ফেলবেন?")
                        .setPositiveButton("হ্যাঁ", (d2, w2) -> store.deleteMark(index))
                        .setNegativeButton("না", null)
                        .show())
                .show();
    }

    // ---------- Elevation profile ----------

    private void showProfile() {
        List<TrackStore.Pt> pts = store.pointsCopy();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(8), dp(12), dp(4));
        Profile.ChartView chart = new Profile.ChartView(this, pts, store.startCh);
        box.addView(chart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(240)));
        TextView tv = new TextView(this);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv.setPadding(dp(4), dp(10), dp(4), 0);
        Profile.Stats s = Profile.stats(pts);
        if (s.valid) {
            tv.setText(String.format(Locale.US,
                    "শুরু %.1f মি  →  শেষ %.1f মি\nসর্বনিম্ন %.1f মি  •  সর্বোচ্চ %.1f মি\n"
                            + "মোট চড়াই %.1f মি  •  উৎরাই %.1f মি\nগড় ঢাল %.2f%%  •  সবচেয়ে খাড়া %.1f%%\n\n"
                            + "ফোনের GPS-এর উচ্চতা আনুমানিক, কয়েক মিটার এদিক-ওদিক হতে পারে।",
                    s.startAlt, s.endAlt, s.minAlt, s.maxAlt, s.rise, s.fall, s.avgGrade, s.maxGrade));
        } else {
            tv.setText("উচ্চতা দেখাতে আগে কিছুটা রাস্তা রেকর্ড করুন।");
        }
        box.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("উচ্চতা প্রোফাইল – " + store.name)
                .setView(box)
                .setPositiveButton("বন্ধ", null)
                .show();
    }

    // ---------- Map menu ----------

    private void mapMenu() {
        String[] items = {
                satellite ? "🗺  সাধারণ ম্যাপ দেখান" : "🛰  স্যাটেলাইট ম্যাপ দেখান",
                "📍  আমি কোথায়",
                "↔  পুরো রাস্তা দেখান",
                "⬇  এই এলাকার ম্যাপ অফলাইনে রাখুন",
                "🎬  এই সার্ভের ভিডিও"};
        new AlertDialog.Builder(this)
                .setTitle("ম্যাপ")
                .setItems(items, (d, which) -> {
                    if (which == 0) toggleMap();
                    else if (which == 1) locateMe();
                    else if (which == 2) showWholeRoad();
                    else if (which == 3) offlineDownload();
                    else videoList();
                })
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    private void toggleMap() {
        satellite = !satellite;
        map.setTileSource(satellite ? SATELLITE : TileSourceFactory.MAPNIK);
    }

    private void locateMe() {
        double[] loc = currentLocation();
        if (loc == null) {
            if (!hasLocationPermission()) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATE);
            } else {
                myLocation.enableMyLocation();
            }
            toast("অবস্থান খোঁজা হচ্ছে, একটু পরে আবার চাপুন।");
            return;
        }
        if (map.getZoomLevelDouble() < 16) map.getController().setZoom(18.0);
        map.getController().animateTo(new GeoPoint(loc[0], loc[1]));
    }

    private void showWholeRoad() {
        List<TrackStore.Pt> pts = store.pointsCopy();
        if (pts.isEmpty()) {
            toast("এখনও কোনো রাস্তা রেকর্ড হয়নি।");
            return;
        }
        if (pts.size() == 1) {
            map.getController().setZoom(18.0);
            map.getController().setCenter(new GeoPoint(pts.get(0).lat, pts.get(0).lon));
            return;
        }
        double n = -90, s = 90, e = -180, w = 180;
        for (TrackStore.Pt p : pts) {
            n = Math.max(n, p.lat);
            s = Math.min(s, p.lat);
            e = Math.max(e, p.lon);
            w = Math.min(w, p.lon);
        }
        double padLat = Math.max((n - s) * 0.15, 0.0005), padLon = Math.max((e - w) * 0.15, 0.0005);
        final BoundingBox bb = new BoundingBox(n + padLat, e + padLon, s - padLat, w - padLon);
        map.post(() -> map.zoomToBoundingBox(bb, true, dp(40)));
    }

    /** Number of map tiles covering the box for zoom levels zMin..zMax. */
    private static long tileCount(BoundingBox bb, int zMin, int zMax) {
        long total = 0;
        for (int z = zMin; z <= zMax; z++) {
            int x1 = lonToTile(bb.getLonWest(), z), x2 = lonToTile(bb.getLonEast(), z);
            int y1 = latToTile(bb.getLatNorth(), z), y2 = latToTile(bb.getLatSouth(), z);
            total += (long) (Math.abs(x2 - x1) + 1) * (Math.abs(y2 - y1) + 1);
        }
        return total;
    }

    private static int lonToTile(double lon, int z) {
        return (int) Math.floor((lon + 180) / 360 * (1 << z));
    }

    private static int latToTile(double lat, int z) {
        double r = Math.toRadians(lat);
        return (int) Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * (1 << z));
    }

    private void offlineDownload() {
        if (!satellite) {
            new AlertDialog.Builder(this)
                    .setTitle("অফলাইন ম্যাপ")
                    .setMessage("সাধারণ (OpenStreetMap) ম্যাপ একসাথে অনেকটা নামানো তাদের নিয়মে নিষেধ। "
                            + "তবে যে এলাকা একবার দেখেছেন, সেটা ফোনে নিজে থেকেই সেভ থাকে।\n\n"
                            + "পুরো এলাকা একসাথে নামাতে আগে স্যাটেলাইট ম্যাপে যান, তারপর আবার এটা চাপুন।")
                    .setPositiveButton("স্যাটেলাইটে যান", (d, w) -> toggleMap())
                    .setNegativeButton("বন্ধ", null)
                    .show();
            return;
        }
        final int zMin = (int) Math.floor(map.getZoomLevelDouble());
        if (zMin < 12) {
            toast("আরও কাছে জুম করুন, যাতে শুধু কাজের এলাকাটুকু স্ক্রিনে থাকে।");
            return;
        }
        final BoundingBox bb = map.getBoundingBox();
        int zMax = Math.min(zMin + 4, 19);
        while (zMax > zMin && tileCount(bb, zMin, zMax) > 8000) zMax--;
        final int fzMax = zMax;
        long tiles = tileCount(bb, zMin, fzMax);
        double mb = tiles * 0.02; // roughly 20 KB per satellite tile
        new AlertDialog.Builder(this)
                .setTitle("এই এলাকার ম্যাপ নামাবেন?")
                .setMessage(String.format(Locale.US,
                        "স্ক্রিনে যতটুকু দেখা যাচ্ছে, সেই এলাকা জুম %d থেকে %d পর্যন্ত নামানো হবে।\n\n"
                                + "প্রায় %d টাইল, আনুমানিক %.0f MB। ওয়াই-ফাই ব্যবহার করা ভালো।",
                        zMin, fzMax, tiles, mb))
                .setPositiveButton("নামান", (d, w) -> {
                    try {
                        CacheManager cm = new CacheManager(map);
                        cm.downloadAreaAsync(this, bb, zMin, fzMax);
                    } catch (Exception e) {
                        toast("ম্যাপ নামানো গেল না: " + e.getMessage());
                    }
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    // ---------- Export ----------

    private void chooseExport() {
        if (store.points.isEmpty() && store.marks.isEmpty()) {
            toast("এক্সপোর্ট করার মতো কোনো ডেটা নেই।");
            return;
        }
        String[] items = {"KMZ (Google Earth, ছবিসহ)", "KML (Google Earth)", "CSV (Excel)", "GPX",
                "PDF রিপোর্ট", "সবগুলো"};
        new AlertDialog.Builder(this)
                .setTitle("\"" + store.name + "\" এক্সপোর্ট")
                .setItems(items, (d, which) -> {
                    if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(
                            Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        pendingExport = which;
                        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE_EXPORT);
                    } else {
                        doExport(which);
                    }
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void doExport(final int which) {
        final List<TrackStore.Pt> pts = store.pointsCopy();
        final List<TrackStore.Mark> marks = store.marksCopy();
        final String name = store.name;
        final double startCh = store.startCh;
        final String base = safeName(name) + "_" + stamp();
        final Context app = getApplicationContext();

        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("ফাইল তৈরি হচ্ছে…");
        pd.setCancelable(false);
        pd.show();

        new Thread(() -> {
            final ArrayList<Uri> uris = new ArrayList<>();
            final List<String> names = new ArrayList<>();
            String error = null;
            try {
                boolean all = which == 5;
                if (which == 0 || all) {
                    addUri(uris, Exporter.save(app, base + ".kmz", "application/octet-stream",
                            Exporter.kmz(app, pts, marks, name, startCh)));
                    names.add(base + ".kmz");
                }
                if (which == 1 || all) {
                    addUri(uris, Exporter.save(app, base + ".kml", "application/octet-stream",
                            Exporter.kml(pts, marks, name, startCh)));
                    names.add(base + ".kml");
                }
                if (which == 2 || all) {
                    addUri(uris, Exporter.save(app, base + ".csv", "text/csv",
                            Exporter.csv(pts, marks, startCh)));
                    names.add(base + ".csv");
                }
                if (which == 3 || all) {
                    addUri(uris, Exporter.save(app, base + ".gpx", "application/octet-stream",
                            Exporter.gpx(pts, marks, name, startCh)));
                    names.add(base + ".gpx");
                }
                if (which == 4 || all) {
                    byte[] pdf = Report.build(app, name, startCh, pts, marks);
                    addUri(uris, Exporter.save(app, base + ".pdf", "application/pdf", pdf));
                    names.add(base + ".pdf");
                }
            } catch (Throwable t) {
                error = String.valueOf(t.getMessage());
            }
            final String err = error;
            runOnUiThread(() -> {
                try {
                    pd.dismiss();
                } catch (Exception ignored) {
                }
                if (isFinishing()) return;
                if (err != null) {
                    new AlertDialog.Builder(this)
                            .setTitle("এক্সপোর্ট হয়নি")
                            .setMessage(err)
                            .setPositiveButton("ঠিক আছে", null)
                            .show();
                    return;
                }
                StringBuilder msg = new StringBuilder("ফোনের Download/" + Exporter.FOLDER + " ফোল্ডারে সেভ হয়েছে:\n\n");
                for (String n : names) msg.append("• ").append(n).append('\n');
                AlertDialog.Builder b = new AlertDialog.Builder(this)
                        .setTitle("এক্সপোর্ট সম্পূর্ণ")
                        .setMessage(msg.toString())
                        .setPositiveButton("ঠিক আছে", null);
                if (!uris.isEmpty()) b.setNeutralButton("শেয়ার করুন", (d, w) -> share(uris));
                b.show();
            });
        }).start();
    }

    private static void addUri(List<Uri> list, Uri u) {
        if (u != null) list.add(u);
    }

    private void share(ArrayList<Uri> uris) {
        Intent send;
        if (uris.size() == 1) {
            send = new Intent(Intent.ACTION_SEND);
            send.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            send = new Intent(Intent.ACTION_SEND_MULTIPLE);
            send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        send.setType("*/*");
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, "শেয়ার করুন"));
    }
}
